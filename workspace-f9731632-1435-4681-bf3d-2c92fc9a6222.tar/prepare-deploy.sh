#!/bin/bash
# اسکریپت deploy خودکار برای Render.com
# این اسکریپت همه چیز را خودکار انجام می‌دهد

set -e

echo "🚀 استقرار خودکار موسسه رویش‌های پیشران"
echo "========================================="

# بررسی پیش‌نیازها
if ! command -v git &> /dev/null; then
  echo "❌ Git نصب نیست. اول نصب کنید: https://git-scm.com"
  exit 1
fi

if ! command -v gh &> /dev/null; then
  echo "⚠️  GitHub CLI نصب نیست. ولی می‌توانید دستی Push کنید."
fi

# آماده‌سازی repo
PROJECT_DIR="/home/z/my-project"
TEMP_DIR="/tmp/rooyesh-deploy"

echo ""
echo "📦 آماده‌سازی فایل‌ها..."
rm -rf $TEMP_DIR
mkdir -p $TEMP_DIR
cd $TEMP_DIR

# کپی فایل‌ها (بدون node_modules)
cp -r $PROJECT_DIR/src .
cp -r $PROJECT_DIR/prisma .
cp -r $PROJECT_DIR/public .
cp -r $PROJECT_DIR/mini-services .
cp $PROJECT_DIR/package.json .
cp $PROJECT_DIR/tsconfig.json .
cp $PROJECT_DIR/next.config.ts .
cp $PROJECT_DIR/tailwind.config.ts .
cp $PROJECT_DIR/postcss.config.mjs .
cp $PROJECT_DIR/components.json .
cp $PROJECT_DIR/eslint.config.mjs .
cp $PROJECT_DIR/Dockerfile .
cp $PROJECT_DIR/render.yaml .
cp $PROJECT_DIR/prisma/seed.ts .

# ایجاد gitignore
cat > .gitignore << 'EOF'
node_modules/
.next/
db/*.db
db/*.db-journal
*.log
.env
EOF

# تغییر SQLite به PostgreSQL
sed -i 's/provider = "sqlite"/provider = "postgresql"/' prisma/schema.prisma
sed -i 's/@db.Text//g' prisma/schema.prisma

# ایجاد فایل .env.example
cat > .env.example << 'EOF'
DATABASE_URL=postgresql://user:pass@host:5432/dbname
NEXTAUTH_SECRET=your-32-char-random-secret
NEXTAUTH_URL=https://your-app.onrender.com
NODE_ENV=production
EOF

# init git
git init
git add .
git config user.email "deploy@rooyesh-pishran.ir"
git config user.name "Deploy Bot"
git commit -m "🚀 Initial commit - موسسه رویش‌های پیشران

- Next.js 16 full-stack app
- Socket.IO chat service
- AI meeting summaries
- Polls with charts
- Role-based auth (SUPER_ADMIN/COACH/MEMBER)
- Persian RTL UI
- Real institute logo from Eitaa channel"

echo ""
echo "✅ فایل‌ها آماده شدند در: $TEMP_DIR"
echo ""
echo "📋 مراحل بعدی:"
echo "1. در https://github.com یک repository جدید بسازید به نام 'rooyesh-pishran'"
echo "2. این دستورات را اجرا کنید:"
echo ""
echo "   cd $TEMP_DIR"
echo "   git remote add origin https://github.com/YOUR_USERNAME/rooyesh-pishran.git"
echo "   git branch -M main"
echo "   git push -u origin main"
echo ""
echo "3. به https://render.com بروید"
echo "4. New + → Blueprint → انتخاب repository"
echo "5. Render به‌طور خودکار render.yaml را می‌خواند و سرویس‌ها را می‌سازد"
echo "6. متغیر NEXTAUTH_SECRET را با یک رشته‌ی تصادفی پر کنید"
echo "7. چند دقیقه صبر کنید تا Deploy تمام شود"
echo ""
echo "🌐 سایت شما روی: https://rooyesh-pishran.onrender.com"
