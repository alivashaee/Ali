import { db } from '../src/lib/db'
import bcrypt from 'bcryptjs'

async function main() {
  const existing = await db.user.findFirst({
    where: { username: 'adminro' },
  })

  if (existing) {
    console.log('✓ Super admin already exists')
  } else {
    const hashed = await bcrypt.hash('rooyeshp', 10)
    await db.user.create({
      data: {
        name: 'مدیر اصلی',
        username: 'adminro',
        password: hashed,
        role: 'SUPER_ADMIN',
      },
    })
    console.log('✓ Created super admin: adminro / rooyeshp')
  }

  // Create a demo coach
  const coachExisting = await db.user.findFirst({ where: { username: 'coach1' } })
  if (!coachExisting) {
    const hashed = await bcrypt.hash('coach123', 10)
    await db.user.create({
      data: {
        name: 'مربی نمونه',
        username: 'coach1',
        password: hashed,
        role: 'COACH',
      },
    })
    console.log('✓ Created demo coach: coach1 / coach123')
  }

  // Seed site settings
  const settings = await db.siteSettings.findUnique({ where: { id: 'singleton' } })
  if (!settings) {
    await db.siteSettings.create({
      data: {
        id: 'singleton',
        siteName: 'موسسه رویش‌های پیشران',
        description:
          'موسسه تربیتی رویش‌های پیشران، وابسته به مسجد فاطمه معصومه(سلام الله علیها)، با همکاری طلاب و اساتید فارغ‌التحصیل دانشگاه و مدرسه علمیه معصومیه، فضایی برای رویش نوجوانان در سایه آموزه‌های دینی فراهم می‌آورد.',
        logo: '/institute-logo.png',
        introVideo: '',
        contactInfo: 'بلوار امین، حدفاصل بلوار جمهوری و خیابان گلستان، مدرسه علمیه معصومیه',
        heroTitle: 'رویش‌های پیشران',
        heroSubtitle: 'فضایی برای رویش نوجوانان در سایه آموزه‌های دینی',
      },
    })
    console.log('✓ Seeded site settings')
  }

  // Seed blog posts
  const postsCount = await db.blogPost.count()
  if (postsCount === 0) {
    await db.blogPost.createMany({
      data: [
        {
          title: 'آغاز دوره جدید رویش‌های پیشران',
          excerpt: 'فصل تازه‌ای از برنامه‌های تربیتی موسسه آغاز شد. در این دوره، نوجوانان با محوریت کاروان عهد و میثاق، آیین معارفه و لیگ لیزرتگ همراه ما خواهند بود.',
          content: '## آغاز دوره جدید\n\nبسم الله الرحمن الرحیم\n\nفصل تازه‌ای از برنامه‌های تربیتی موسسه رویش‌های پیشران آغاز شد. این دوره با محوریت سه برنامه محوری برگزار می‌شود:\n\n### ۱. کاروان عهد و میثاق\nزیارت مزار مطهر شهدا و تجدید عهد؛ بن‌مایه اصلی این برنامه، پیوند نسل تازه با خون شهیدان بالاخص امام شهیدمان و عهد جمعی به استقامت پای انقلاب اسلامی است.\n\n### ۲. آیین معارفه\nآشنایی رسمی اعضا با اهداف دوره، برنامه هفتگی؛ و عهد جمعی حضور در تمام دوره.\n\n### ۳. افتتاح لیگ پرهیجان لیزرتگ\nمعرفی لیگ و برگزاری نخستین بازی‌ها؛ این رشته با محوریت تقویت کار تیمی، نشاط و چابکی در طول دوره برگزار خواهد شد.\n\n### زمان برگزاری برنامه‌ها\n- پنجشنبه: ساعت ۱۳ الی ۲۱:۳۰\n- جمعه: ساعت ۷:۳۰ الی ۱۲\n\nمکان: مسجد فاطمه معصومه(سلام الله علیها)',
          image: '/blog-1.jpg',
        },
        {
          title: 'کاروان عهد و میثاق؛ پیوند نسل تازه با خون شهیدان',
          excerpt: 'برنامه کاروان عهد و میثاق، بن‌مایه اصلی آن پیوند نسل تازه با خون شهیدان و عهد جمعی به استقامت پای انقلاب اسلامی است.',
          content: '## کاروان عهد و میثاق\n\nزمان تجمع: پنجشنبه ۱۶ مهر ساعت ۱۳\nمکان تجمع: مسجد فاطمه معصومه سلام الله علیها\nمقصد: تهران، بهشت زهرا و خیابان شهید کشور دوست (مقتل امام شهید)\nزمان بازگشت: ساعت ۲۱:۳۰\n\n### نکات مهم\n۱. در صورت مانع (آب و هوا و...)، برنامه جایگزین: گلزار شهدا قم و حرم مطهر خواهد بود.\n۲. حتماً ناهار را در خانه میل کنید یا همراه خود بیاورید.\n\nای عزیز مردم، ای رهبر ایران تا ابد یاد توست\nدر کشور ایران این وداع ما نیست، آغاز دوباره‌ست\nنام تو می‌ماند در دفتر ایران...',
          image: '/hero-bg.jpg',
        },
        {
          title: 'دوره مثل شهید خامنه‌ای',
          excerpt: 'برنامه‌های دوره «مثل شهید خامنه‌ای» ویژه نوجوانان، با محوریت الگوسازی از شهیدان مقاومت.',
          content: '## دوره مثل شهید خامنه‌ای\n\nاین دوره با هدف الگوسازی از شهیدان مقاومت برگزار می‌شود و شامل برنامه‌های زیر است:\n\n- کاروان عهد و میثاق\n- آیین معارفه\n- برنامه‌های هفتگی متنوع\n\n### زمان برگزاری\n- پنجشنبه: ساعت ۱۳ الی ۲۱:۳۰\n- جمعه: ساعت ۸ الی ۱۰ صبح\n\nمکان: مسجد فاطمه معصومه(سلام الله علیها)',
          image: '/blog-1.jpg',
        },
      ],
    })
    console.log('✓ Seeded blog posts')
  }

  // Seed demo poll
  const pollCount = await db.poll.count()
  if (pollCount === 0) {
    const admin = await db.user.findFirst({ where: { username: 'adminro' } })
    if (admin) {
      const poll = await db.poll.create({
        data: {
          title: 'بهترین برنامه دور جدید کدام است؟',
          description: 'نظر شما درباره جذاب‌ترین برنامه دوره جدید رویش‌های پیشران چیست؟',
          isPublic: true,
          createdBy: admin.id,
          buttonColor: '#1f5130',
          buttonShape: 'rounded',
          buttonText: 'ثبت نظر',
          options: {
            create: [
              { text: 'کاروان عهد و میثاق' },
              { text: 'آیین معارفه' },
              { text: 'لیگ لیزرتگ' },
              { text: 'دوره مثل شهید خامنه‌ای' },
            ],
          },
        },
      })
      console.log('✓ Seeded demo poll')
    }
  }

  console.log('✓ Seed completed')
}

main()
  .catch((e) => {
    console.error('Seed error:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
