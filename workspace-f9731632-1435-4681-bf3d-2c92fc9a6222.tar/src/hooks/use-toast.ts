"use client"

// Inspired by react-hot-toast library
// Delegates to `sonner` for actual rendering (more reliable than radix toast in our setup)
import * as React from "react"
import { toast as sonnerToast } from "sonner"

import type {
  ToastActionElement,
  ToastProps,
} from "@/components/ui/toast"

type ToasterToast = ToastProps & {
  id: string
  title?: React.ReactNode
  description?: React.ReactNode
  action?: ToastActionElement
}

type Toast = Omit<ToasterToast, "id">

/**
 * Show a toast notification using Sonner under the hood.
 * Existing callers use `toast({ title, description, variant })` shape — kept compatible.
 */
function toast({ title, description, variant, action }: Toast) {
  const message = typeof title === "string" ? title : "اعلان"
  const desc =
    typeof description === "string"
      ? description
      : Array.isArray(description)
        ? description.join(" ")
        : undefined

  console.log("[use-toast] calling sonnerToast with:", { message, desc, variant })

  if (variant === "destructive") {
    return sonnerToast.error(message, {
      description: desc,
    })
  }

  return sonnerToast(message, {
    description: desc,
  })
}

/**
 * useToast — kept for backwards compatibility with existing callers.
 * Returns a stable object exposing `toast`, `dismiss`, and an empty `toasts` array
 * (state is now owned by Sonner, so we don't need to track toasts ourselves).
 */
function useToast() {
  return {
    toasts: [] as ToasterToast[],
    toast,
    dismiss: (_toastId?: string) => sonnerToast.dismiss(_toastId),
  }
}

// Expose for debugging
if (typeof window !== "undefined") {
  ;(window as any).customToast = toast
  ;(window as any).sonnerToastDirect = sonnerToast
}

export { useToast, toast }
