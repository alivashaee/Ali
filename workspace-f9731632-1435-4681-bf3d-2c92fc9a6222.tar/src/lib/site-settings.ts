import { db } from '@/lib/db'

export async function getSiteSettings() {
  let settings = await db.siteSettings.findUnique({ where: { id: 'singleton' } })
  if (!settings) {
    settings = await db.siteSettings.create({
      data: {
        id: 'singleton',
        siteName: 'موسسه رویش‌های پیشران',
        description: 'موسسه تربیتی وابسته به مسجد فاطمه معصومه(سلام الله علیها).',
        heroTitle: 'رویش‌های پیشران',
        heroSubtitle: 'فضایی برای رویش نوجوانان در سایه آموزه‌های دینی',
      },
    })
  }
  return settings
}
