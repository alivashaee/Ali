import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export type SessionUser = {
  id: string
  name: string
  username?: string
  role: 'SUPER_ADMIN' | 'COACH' | 'MEMBER'
}

export async function getSession(): Promise<SessionUser | null> {
  const session = await getServerSession(authOptions)
  if (!session?.user) return null
  return session.user as SessionUser
}

export async function requireAuth(): Promise<SessionUser> {
  const user = await getSession()
  if (!user) {
    throw new Response(JSON.stringify({ error: 'احراز هویت نشده' }), {
      status: 401,
      headers: { 'Content-Type': 'application/json' },
    })
  }
  return user
}

export async function requireRole(...roles: SessionUser['role'][]): Promise<SessionUser> {
  const user = await requireAuth()
  if (!roles.includes(user.role)) {
    throw new Response(JSON.stringify({ error: 'دسترسی غیرمجاز' }), {
      status: 403,
      headers: { 'Content-Type': 'application/json' },
    })
  }
  return user
}

export async function requireAdmin() {
  return requireRole('SUPER_ADMIN')
}

export async function requireCoachOrAdmin() {
  return requireRole('SUPER_ADMIN', 'COACH')
}

/** Returns the current user's full DB record */
export async function getCurrentUser() {
  const session = await getSession()
  if (!session?.id) return null
  return db.user.findUnique({ where: { id: session.id } })
}

/** Check that the user owns or is member of a group */
export async function canAccessGroup(userId: string, groupId: string): Promise<boolean> {
  const group = await db.group.findUnique({ where: { id: groupId } })
  if (!group) return false
  if (group.coachId === userId) return true
  const member = await db.groupMember.findUnique({
    where: { groupId_userId: { groupId, userId } },
  })
  return !!member
}

/** Check that the user is the coach of a group */
export async function isCoachOfGroup(userId: string, groupId: string): Promise<boolean> {
  const group = await db.group.findUnique({ where: { id: groupId } })
  return !!group && group.coachId === userId
}
