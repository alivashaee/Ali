import { Socket, io } from 'socket.io-client'

let socket: Socket | null = null

export function getSocket(token?: string): Socket {
  if (socket?.connected) return socket
  socket = io('/', {
    path: '/',
    query: { XTransformPort: '3003' },
    transports: ['websocket', 'polling'],
    auth: token ? { token } : undefined,
    reconnection: true,
    reconnectionAttempts: 5,
    reconnectionDelay: 1000,
  })
  return socket
}

export function disconnectSocket() {
  if (socket) {
    socket.disconnect()
    socket = null
  }
}

export type ChatMessage = {
  id: string
  groupId: string
  senderId: string
  senderName: string
  senderAvatar?: string | null
  content?: string | null
  fileUrl?: string | null
  fileType?: string | null
  fileName?: string | null
  reactions?: Record<string, string[]>
  createdAt: string
  isOwn?: boolean
}

export type TypingState = {
  userId: string
  userName: string
  groupId: string
}

export type PresenceState = {
  userId: string
  userName: string
  groupId: string
  online: boolean
}
