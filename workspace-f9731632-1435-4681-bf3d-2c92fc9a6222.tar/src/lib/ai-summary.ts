import { db } from '@/lib/db'
import fs from 'fs'
import path from 'path'
import ZAI from 'z-ai-web-dev-sdk'

/**
 * Generate a meeting summary for the given MeetingSummary record.
 * - Reads the audio file from `public/uploads/...`
 * - Transcribes it via z-ai-web-dev-sdk ASR (Whisper)
 * - Summarizes the transcript via z-ai LLM (chat completions)
 * - Updates the record with transcript + summary + status
 *
 * This function is invoked from `after()` of the Next.js route handler,
 * so it runs after the response has been sent and never blocks the request.
 */
export async function generateMeetingSummary(summaryId: string) {
  const record = await db.meetingSummary.findUnique({
    where: { id: summaryId },
    select: { id: true, audioUrl: true, groupId: true },
  })
  if (!record) {
    return
  }

  await db.meetingSummary.update({
    where: { id: summaryId },
    data: { status: 'processing' },
  })

  // Read audio file
  const audioPath = path.join(process.cwd(), 'public', record.audioUrl.replace(/^\//, ''))
  if (!fs.existsSync(audioPath)) {
    await db.meetingSummary.update({
      where: { id: summaryId },
      data: {
        status: 'failed',
        transcript:
          'خطا: فایل صوتی روی سرور یافت نشد. لطفاً دوباره فایل را آپلود کنید.',
      },
    })
    return
  }

  // Transcribe via z-ai ASR (Whisper)
  let transcript = ''
  try {
    const zai = await ZAI.create()
    const audioBuffer = fs.readFileSync(audioPath)
    const base64Audio = audioBuffer.toString('base64')

    try {
      // Preferred API shape: zai.audio.asr.create({ file_base64 })
      const asrResp: any = await (zai as any).audio.asr.create({
        file_base64: base64Audio,
      })
      transcript = asrResp?.text || ''
    } catch (asrErr) {
      // Fallback: try OpenAI-style transcription endpoint
      console.warn('ASR via audio.asr.create failed, trying fallback:', asrErr)
      try {
        const transcription: any = await (zai as any).audio.transcriptions.create({
          file: fs.createReadStream(audioPath),
          model: 'whisper-1',
        })
        transcript = transcription?.text || ''
      } catch (e2) {
        console.warn('ASR fallback failed:', e2)
        transcript = ''
      }
    }
  } catch (err) {
    console.error('Failed to initialize z-ai SDK:', err)
    transcript = ''
  }

  if (!transcript) {
    // No transcription available — provide a placeholder explaining the feature
    transcript =
      '[پیام سیستم: تبدیل گفتار به متن در محیط فعلی موفق نبود. این قابلیت نیازمند اتصال به سرویس Whisper است. لطفاً با مدیر سیستم تماس بگیرید.]'
  }

  await db.meetingSummary.update({
    where: { id: summaryId },
    data: { transcript },
  })

  // Summarize via z-ai LLM
  const systemPrompt =
    'You are an expert meeting summarizer. Read the following transcript of a Persian meeting from an Islamic educational institute. Provide a structured summary in Persian with: 1. نکات کلیدی بحث (key discussion points), 2. اقدامات لازم (action items), 3. تصمیمات گرفته شده (decisions made). Use markdown formatting.'

  let summary = ''
  try {
    const zai = await ZAI.create()
    const completion: any = await (zai as any).chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        { role: 'user', content: `ترانسکریپت جلسه:\n\n${transcript}` },
      ],
      thinking: { type: 'disabled' },
    })
    summary = completion?.choices?.[0]?.message?.content || ''
  } catch (err) {
    console.error('LLM summary failed:', err)
    summary =
      '## خطا در تولید خلاصه\n\nمتأسفانه هنگام تولید خلاصه هوش مصنوعی خطایی رخ داد. لطفاً ترانسکریپت زیر را مطالعه کنید.\n\n---\n\n' + transcript
  }

  if (!summary) {
    summary =
      '## خلاصه‌ای تولید نشد\n\nامکان تولید خلاصه از این جلسه وجود نداشت. لطفاً بعد از اطمینان از کیفیت فایل صوتی دوباره تلاش کنید.'
  }

  await db.meetingSummary.update({
    where: { id: summaryId },
    data: { summary, status: 'completed' },
  })
}
