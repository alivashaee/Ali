import type { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'

export const authOptions: NextAuthOptions = {
  session: {
    strategy: 'jwt',
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  trustHost: true,
  pages: {
    signIn: '/login',
  },
  providers: [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        username: { label: 'نام کاربری', type: 'text' },
        password: { label: 'رمز عبور', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.username || !credentials?.password) {
          return null
        }

        const user = await db.user.findFirst({
          where: {
            OR: [
              { username: credentials.username },
              { phone: credentials.username },
              { email: credentials.username },
            ],
          },
        })

        if (!user || !user.password) {
          return null
        }

        if (user.blocked) {
          throw new Error('حساب کاربری شما مسدود شده است')
        }

        const valid = await bcrypt.compare(credentials.password, user.password)
        if (!valid) {
          return null
        }

        return {
          id: user.id,
          name: user.name,
          role: user.role,
          username: user.username ?? undefined,
        } as any
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = (user as any).id
        token.role = (user as any).role
        token.username = (user as any).username
      }
      return token
    },
    async session({ session, token }) {
      if (session.user) {
        ;(session.user as any).id = token.id
        ;(session.user as any).role = token.role
        ;(session.user as any).username = token.username
      }
      return session
    },
  },
  secret: process.env.NEXTAUTH_SECRET || 'rooyesh-pishrun-secret-key-2024-very-long',
}

// Role-based type augmentation
declare module 'next-auth' {
  interface Session {
    user: {
      id: string
      name: string
      username?: string
      role: 'SUPER_ADMIN' | 'COACH' | 'MEMBER'
    }
  }
  interface User {
    role: 'SUPER_ADMIN' | 'COACH' | 'MEMBER'
    username?: string
  }
}
