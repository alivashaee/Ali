/**
 * Format a date as a Persian (Jalali) calendar string using Intl.
 * Falls back to a simple Gregorian format if Intl Persian calendar is unavailable.
 */
export function formatJalaliDate(date: Date | string | null | undefined, withTime = false): string {
  if (!date) return '—'
  const d = typeof date === 'string' ? new Date(date) : date
  if (isNaN(d.getTime())) return '—'

  try {
    const opts: Intl.DateTimeFormatOptions = withTime
      ? { dateStyle: 'long', timeStyle: 'short', calendar: 'persian', numberingSystem: 'latn' }
      : { dateStyle: 'long', calendar: 'persian', numberingSystem: 'latn' }
    // fa-IR with persian calendar may not be supported in all runtimes, fallback gracefully
    const formatter = new Intl.DateTimeFormat('fa-IR-u-ca-persian', opts)
    let s = formatter.format(d)
    // Convert latin digits to Persian digits
    s = toPersianDigits(s)
    return s
  } catch {
    try {
      const formatter = new Intl.DateTimeFormat('fa-IR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        ...(withTime ? { hour: '2-digit', minute: '2-digit' } : {}),
      })
      return toPersianDigits(formatter.format(d))
    } catch {
      return d.toLocaleDateString()
    }
  }
}

/** Convert any latin digits in a string to Persian digits. */
export function toPersianDigits(input: string | number): string {
  const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹']
  return String(input).replace(/\d/g, (d) => persian[parseInt(d, 10)])
}

/** Convert Persian/Arabic digits in a string to latin digits. */
export function fromPersianDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660))
}
