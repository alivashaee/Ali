'use client'

import { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { MessageCircle, Users, FileAudio } from 'lucide-react'
import { GroupChat } from '@/components/chat/group-chat'
import { GroupMembersManager } from '@/components/coach/group-members-manager'
import { GroupSummariesManager } from '@/components/coach/group-summaries-manager'

type TabValue = 'chat' | 'members' | 'summaries'

type Props = {
  groupId: string
  groupName: string
  defaultTab?: TabValue
}

/**
 * Consolidated coach dashboard for a single group.
 * Combines chat + members + summaries into one tabbed page.
 */
export function CoachDashboard({
  groupId,
  groupName,
  defaultTab = 'chat',
}: Props) {
  const [tab, setTab] = useState<TabValue>(defaultTab)

  return (
    <div className="space-y-5">
      <Tabs value={tab} onValueChange={(v) => setTab(v as TabValue)} className="w-full">
        <TabsList className="bg-accent/15 p-1 h-auto rounded-2xl flex-wrap w-full sm:w-auto">
          <TabsTrigger value="chat" className="rounded-xl gap-1.5 flex-1 sm:flex-none">
            <MessageCircle className="w-4 h-4" />
            چت گروهی
          </TabsTrigger>
          <TabsTrigger value="members" className="rounded-xl gap-1.5 flex-1 sm:flex-none">
            <Users className="w-4 h-4" />
            اعضا
          </TabsTrigger>
          <TabsTrigger value="summaries" className="rounded-xl gap-1.5 flex-1 sm:flex-none">
            <FileAudio className="w-4 h-4" />
            خلاصه جلسات
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="mt-4">
          <GroupChat groupId={groupId} />
        </TabsContent>

        <TabsContent value="members" className="mt-4">
          <GroupMembersManager groupId={groupId} />
        </TabsContent>

        <TabsContent value="summaries" className="mt-4">
          <GroupSummariesManager groupId={groupId} groupName={groupName} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
