'use client'

import { useState, useRef } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { useToast } from '@/hooks/use-toast'
import { Loader2, Upload, FileAudio, Trash2, Sparkles, CheckCircle2, AlertCircle, Clock } from 'lucide-react'
import { formatJalaliDate } from '@/lib/format-jalali'

type Summary = {
  id: string
  groupId: string
  audioUrl: string
  status: string
  createdAt: string
  updatedAt: string
  group?: { id: string; name: string }
}

export function GroupSummariesManager({ groupId, groupName }: { groupId: string; groupName: string }) {
  const qc = useQueryClient()
  const { toast } = useToast()
  const [open, setOpen] = useState(false)

  const { data, isLoading } = useQuery<{ summaries: Summary[] }>({
    queryKey: ['coach', 'summaries', { groupId }],
    queryFn: async () => {
      const r = await fetch(`/api/coach/summaries?groupId=${encodeURIComponent(groupId)}`)
      if (!r.ok) throw new Error('خطا در بارگذاری خلاصه‌ها')
      return r.json()
    },
  })

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const r = await fetch(`/api/coach/summaries/${id}`, { method: 'DELETE' })
      if (!r.ok) {
        const d = await r.json().catch(() => ({}))
        throw new Error(d.error || 'خطا در حذف خلاصه')
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['coach', 'summaries'] })
      toast({ title: 'خلاصه حذف شد' })
    },
    onError: (e: any) => {
      toast({ title: 'خطا', description: e.message, variant: 'destructive' })
    },
  })

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h3 className="font-bold text-base text-foreground">خلاصه جلسات این گروه</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            فایل صوتی را آپلود کنید تا با هوش مصنوعی، ترانسکریپت و خلاصه تولید شود.
          </p>
        </div>
        <UploadSummaryDialog
          groupId={groupId}
          groupName={groupName}
          open={open}
          onOpenChange={setOpen}
          onDone={() => {
            qc.invalidateQueries({ queryKey: ['coach', 'summaries'] })
            setOpen(false)
          }}
        />
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-8 text-muted-foreground">
          <Loader2 className="w-5 h-5 animate-spin ml-2" />
          در حال بارگذاری خلاصه‌ها...
        </div>
      ) : !data?.summaries?.length ? (
        <div className="flex flex-col items-center justify-center text-center py-10 gap-2 rounded-2xl border border-dashed border-border/50">
          <Sparkles className="w-8 h-8 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">هنوز خلاصه‌ای برای این گروه ساخته نشده است.</p>
          <p className="text-xs text-muted-foreground max-w-md">
            برای شروع، یک فایل صوتی از جلسه را آپلود کنید.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {data.summaries.map((s) => (
            <div key={s.id} className="rounded-2xl border border-border/40 p-4 bg-card/50">
              <div className="flex items-start justify-between gap-3 mb-3">
                <div>
                  <div className="text-sm font-medium">{formatJalaliDate(s.createdAt, true)}</div>
                  <StatusBadge status={s.status} />
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Button asChild size="sm" variant="outline" className="rounded-full">
                    <Link href={`/coach/summaries/${s.id}`}>
                      <FileAudio className="w-4 h-4" />
                      مشاهده
                    </Link>
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:bg-destructive/10">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>حذف خلاصه</AlertDialogTitle>
                        <AlertDialogDescription>
                          آیا از حذف این خلاصه و فایل صوتی آن مطمئن هستید؟
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>انصراف</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive text-white hover:bg-destructive/90"
                          onClick={() => deleteMutation.mutate(s.id)}
                        >
                          حذف
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
              <audio controls src={s.audioUrl} className="w-full h-10" />
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'completed':
      return (
        <Badge variant="outline" className="mt-1 text-sprout border-sprout/40 bg-sprout/10">
          <CheckCircle2 className="w-3 h-3 ml-1" />
          تکمیل شده
        </Badge>
      )
    case 'processing':
      return (
        <Badge variant="outline" className="mt-1 text-gold border-gold/40 bg-gold/10">
          <Loader2 className="w-3 h-3 ml-1 animate-spin" />
          در حال پردازش
        </Badge>
      )
    case 'pending':
      return (
        <Badge variant="outline" className="mt-1 text-gold border-gold/40 bg-gold/10">
          <Clock className="w-3 h-3 ml-1" />
          در انتظار
        </Badge>
      )
    case 'failed':
      return (
        <Badge variant="outline" className="mt-1 text-destructive border-destructive/40 bg-destructive/10">
          <AlertCircle className="w-3 h-3 ml-1" />
          ناموفق
        </Badge>
      )
    default:
      return null
  }
}

function UploadSummaryDialog({
  groupId,
  groupName,
  open,
  onOpenChange,
  onDone,
}: {
  groupId: string
  groupName: string
  open: boolean
  onOpenChange: (open: boolean) => void
  onDone: () => void
}) {
  const { toast } = useToast()
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  async function handleUpload() {
    if (!file) return
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const r = await fetch('/api/coach/upload', { method: 'POST', body: fd })
      const data = await r.json()
      if (!r.ok) throw new Error(data.error || 'خطا در آپلود فایل')
      // Now create the summary
      setSubmitting(true)
      const r2 = await fetch('/api/coach/summaries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ groupId, audioUrl: data.url }),
      })
      const d2 = await r2.json()
      if (!r2.ok) throw new Error(d2.error || 'خطا در ایجاد خلاصه')
      toast({
        title: 'خلاصه در صف پردازش قرار گرفت ✅',
        description: 'ظرف چند دقیقه خلاصه آماده می‌شود.',
      })
      setFile(null)
      if (fileInputRef.current) fileInputRef.current.value = ''
      onDone()
    } catch (e: any) {
      toast({
        title: 'خطا',
        description: e.message || 'خطایی رخ داد',
        variant: 'destructive',
      })
    } finally {
      setUploading(false)
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button size="sm" className="rounded-full">
          <Upload className="w-4 h-4" />
          آپلود فایل صوتی
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>آپلود فایل صوتی جلسه</DialogTitle>
          <DialogDescription>
            فایل صوتی جلسه گروه «{groupName}» را آپلود کنید. هوش مصنوعی به‌صورت خودکار ترانسکریپت و خلاصه آن را تولید می‌کند.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <label
              htmlFor="audio-file"
              className="flex flex-col items-center justify-center gap-2 py-8 border-2 border-dashed border-border/60 rounded-2xl cursor-pointer hover:bg-accent/10 transition-colors"
            >
              <FileAudio className="w-10 h-10 text-muted-foreground" />
              {file ? (
                <span className="text-sm font-medium">{file.name}</span>
              ) : (
                <>
                  <span className="text-sm font-medium">انتخاب فایل صوتی</span>
                  <span className="text-xs text-muted-foreground">
                    MP3, WAV, M4A, OGG — حداکثر ۵۰MB
                  </span>
                </>
              )}
            </label>
            <input
              id="audio-file"
              ref={fileInputRef}
              type="file"
              accept="audio/*,.mp3,.wav,.m4a,.ogg,.aac"
              className="sr-only"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
              disabled={uploading || submitting}
            />
          </div>
          {file && (
            <div className="text-xs text-muted-foreground bg-muted/30 rounded-lg p-2 text-center">
              حجم: {(file.size / 1024 / 1024).toFixed(2)} مگابایت
            </div>
          )}
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={uploading || submitting}>
            انصراف
          </Button>
          <Button
            type="button"
            onClick={handleUpload}
            disabled={!file || uploading || submitting}
            className="rounded-full"
          >
            {uploading || submitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                {uploading ? 'در حال آپلود...' : 'در حال ساخت...'}
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                آپلود و تولید خلاصه
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
