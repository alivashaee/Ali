'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useToast } from '@/hooks/use-toast'
import { Loader2, Users } from 'lucide-react'

/**
 * Inline form (not a dialog) for the coach's first/only group.
 * Used on /coach when they don't yet have a group.
 */
export function CreateGroupForm() {
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('/api/coach/groups', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), description: description.trim() || null }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'خطا در ایجاد گروه')
      toast({ title: 'گروه ساخته شد ✅', description: name })
      setName('')
      setDescription('')
      router.refresh()
    } catch (e: any) {
      toast({
        title: 'خطا',
        description: e.message || 'خطایی رخ داد',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="border-accent/30 max-w-xl mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto w-14 h-14 rounded-full bg-accent/15 flex items-center justify-center mb-2">
          <Users className="w-7 h-7 text-primary" />
        </div>
        <CardTitle className="text-xl">ساخت گروه تربیتی شما</CardTitle>
        <CardDescription>
          هر مربی فقط یک گروه می‌تواند داشته باشد. پس از ساخت گروه، می‌توانید اعضا را اضافه کنید،
          چت گروهی را مدیریت کنید و خلاصه جلسات را با هوش مصنوعی بسازید.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">نام گروه</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثلاً: گروه نوجوانان - دوره پاییز"
              required
              disabled={loading}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">توضیحات (اختیاری)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="توضیح مختصری درباره این گروه"
              rows={3}
              disabled={loading}
            />
          </div>
          <Button
            type="submit"
            disabled={loading || !name.trim()}
            className="rounded-full w-full"
            size="lg"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                در حال ساخت...
              </>
            ) : (
              'ساخت گروه'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
