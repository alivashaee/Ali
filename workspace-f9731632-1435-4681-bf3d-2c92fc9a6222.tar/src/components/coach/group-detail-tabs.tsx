'use client'

import { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { MessageCircle, Users, FileAudio } from 'lucide-react'
import { GroupChatLoader } from '@/components/coach/group-chat-loader'
import { GroupMembersManager } from '@/components/coach/group-members-manager'
import { GroupSummariesManager } from '@/components/coach/group-summaries-manager'

type TabValue = 'chat' | 'members' | 'summaries'

type Props = {
  groupId: string
  groupName: string
  defaultTab?: TabValue
}

export function GroupDetailTabs({ groupId, groupName, defaultTab = 'chat' }: Props) {
  const [tab, setTab] = useState<TabValue>(defaultTab)

  return (
    <Tabs value={tab} onValueChange={(v) => setTab(v as TabValue)} className="w-full">
      <TabsList className="bg-accent/15 p-1 h-auto rounded-2xl flex-wrap">
        <TabsTrigger value="chat" className="rounded-xl gap-1.5">
          <MessageCircle className="w-4 h-4" />
          چت
        </TabsTrigger>
        <TabsTrigger value="members" className="rounded-xl gap-1.5">
          <Users className="w-4 h-4" />
          اعضا
        </TabsTrigger>
        <TabsTrigger value="summaries" className="rounded-xl gap-1.5">
          <FileAudio className="w-4 h-4" />
          خلاصه‌ها
        </TabsTrigger>
      </TabsList>
      <TabsContent value="chat" className="mt-4">
        <GroupChatLoader groupId={groupId} />
      </TabsContent>
      <TabsContent value="members" className="mt-4">
        <GroupMembersManager groupId={groupId} />
      </TabsContent>
      <TabsContent value="summaries" className="mt-4">
        <GroupSummariesManager groupId={groupId} groupName={groupName} />
      </TabsContent>
    </Tabs>
  )
}
