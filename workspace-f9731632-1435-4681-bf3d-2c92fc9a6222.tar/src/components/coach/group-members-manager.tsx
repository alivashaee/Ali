'use client'

import { useEffect, useState, useTransition } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { useToast } from '@/hooks/use-toast'
import { Plus, UserMinus, Loader2, Users, UserCheck, UserPlus } from 'lucide-react'

type Member = {
  id: string
  joinedAt: string
  user: {
    id: string
    name: string
    username: string | null
    role: string
    avatar: string | null
  }
}

export function GroupMembersManager({ groupId }: { groupId: string }) {
  const qc = useQueryClient()
  const { toast } = useToast()
  const [open, setOpen] = useState(false)

  const { data, isLoading } = useQuery<{ members: Member[] }>({
    queryKey: ['coach', 'groups', groupId, 'members'],
    queryFn: async () => {
      const r = await fetch(`/api/coach/groups/${groupId}/members`)
      if (!r.ok) throw new Error('خطا در بارگذاری اعضا')
      return r.json()
    },
  })

  const removeMutation = useMutation({
    mutationFn: async (userId: string) => {
      const r = await fetch(`/api/coach/groups/${groupId}/members/${userId}`, {
        method: 'DELETE',
      })
      if (!r.ok) {
        const data = await r.json().catch(() => ({}))
        throw new Error(data.error || 'خطا در حذف عضو')
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['coach', 'groups', groupId, 'members'] })
      toast({ title: 'عضو حذف شد' })
    },
    onError: (e: any) => {
      toast({ title: 'خطا', description: e.message, variant: 'destructive' })
    },
  })

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h3 className="font-bold text-base text-foreground">اعضای گروه</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            {data?.members?.length ? data.members.length.toLocaleString('fa-IR') : 0} عضو
          </p>
        </div>
        <AddMemberDialog
          groupId={groupId}
          open={open}
          onOpenChange={setOpen}
          onAdded={() => {
            qc.invalidateQueries({ queryKey: ['coach', 'groups', groupId, 'members'] })
            setOpen(false)
          }}
        />
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-8 text-muted-foreground">
          <Loader2 className="w-5 h-5 animate-spin ml-2" />
          در حال بارگذاری اعضا...
        </div>
      ) : !data?.members?.length ? (
        <div className="flex flex-col items-center justify-center text-center py-10 gap-2 rounded-2xl border border-dashed border-border/50">
          <Users className="w-8 h-8 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">هنوز عضوی به این گروه اضافه نشده است.</p>
        </div>
      ) : (
        <div className="rounded-2xl border border-border/40 overflow-hidden divide-y divide-border/30">
          {data.members.map((m) => (
            <div key={m.id} className="flex items-center justify-between gap-3 p-3 hover:bg-accent/10 transition-colors">
              <div className="flex items-center gap-3 min-w-0">
                <Avatar className="w-9 h-9 ring-2 ring-accent/30">
                  <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                    {m.user.name?.charAt(0) || 'ع'}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <div className="font-medium text-sm truncate">{m.user.name}</div>
                  <div className="text-xs text-muted-foreground truncate" dir="ltr">
                    @{m.user.username || '—'}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {m.user.role === 'COACH' && (
                  <Badge variant="secondary" className="text-xs">مربی</Badge>
                )}
                {m.user.role === 'SUPER_ADMIN' && (
                  <Badge variant="secondary" className="text-xs">مدیر</Badge>
                )}
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:bg-destructive/10">
                      <UserMinus className="w-4 h-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>حذف عضو</AlertDialogTitle>
                      <AlertDialogDescription>
                        آیا از حذف «{m.user.name}» از این گروه مطمئن هستید؟
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>انصراف</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-white hover:bg-destructive/90"
                        onClick={() => removeMutation.mutate(m.user.id)}
                      >
                        حذف عضو
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function AddMemberDialog({
  groupId,
  open,
  onOpenChange,
  onAdded,
}: {
  groupId: string
  open: boolean
  onOpenChange: (open: boolean) => void
  onAdded: () => void
}) {
  const { toast } = useToast()
  const [mode, setMode] = useState<'create' | 'existing'>('create')
  const [name, setName] = useState('')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch(`/api/coach/groups/${groupId}/members`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode,
          name: name.trim(),
          username: username.trim(),
          password,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'خطا در افزودن عضو')
      toast({
        title: mode === 'create' ? 'عضو جدید ساخته شد ✅' : 'عضو به گروه اضافه شد ✅',
        description: name || username,
      })
      setName('')
      setUsername('')
      setPassword('')
      setMode('create')
      onAdded()
    } catch (e: any) {
      toast({
        title: 'خطا',
        description: e.message || 'خطایی رخ داد',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button size="sm" className="rounded-full">
          <Plus className="w-4 h-4" />
          افزودن عضو
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>افزودن عضو به گروه</DialogTitle>
          <DialogDescription>
            می‌توانید یک کاربر جدید بسازید یا یک کاربر موجود را با نام کاربری به گروه اضافه کنید.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setMode('create')}
              className={`flex flex-col items-center gap-1 p-3 rounded-xl border transition-colors ${
                mode === 'create'
                  ? 'border-primary bg-primary/10'
                  : 'border-border hover:bg-accent/15'
              }`}
            >
              <UserPlus className="w-5 h-5" />
              <span className="text-xs font-medium">کاربر جدید</span>
            </button>
            <button
              type="button"
              onClick={() => setMode('existing')}
              className={`flex flex-col items-center gap-1 p-3 rounded-xl border transition-colors ${
                mode === 'existing'
                  ? 'border-primary bg-primary/10'
                  : 'border-border hover:bg-accent/15'
              }`}
            >
              <UserCheck className="w-5 h-5" />
              <span className="text-xs font-medium">کاربر موجود</span>
            </button>
          </div>

          {mode === 'create' && (
            <div className="space-y-2">
              <Label htmlFor="name">نام کامل</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="نام عضو"
                required
                disabled={loading}
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="username">نام کاربری</Label>
            <Input
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="مثلاً: member1"
              required
              disabled={loading}
              dir="ltr"
              className="text-right"
            />
            {mode === 'existing' && (
              <p className="text-xs text-muted-foreground">
                کاربری با این نام کاربری به گروه اضافه خواهد شد.
              </p>
            )}
          </div>

          {mode === 'create' && (
            <div className="space-y-2">
              <Label htmlFor="password">رمز عبور اولیه</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="حداقل ۶ کاراکتر"
                required
                disabled={loading}
                dir="ltr"
                className="text-right"
              />
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
              انصراف
            </Button>
            <Button type="submit" disabled={loading} className="rounded-full">
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  در حال افزودن...
                </>
              ) : (
                'افزودن عضو'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
