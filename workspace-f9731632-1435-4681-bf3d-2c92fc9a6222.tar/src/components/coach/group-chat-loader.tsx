'use client'

import { useEffect, useState, type ComponentType } from 'react'
import { Loader2, MessageCircle } from 'lucide-react'

type Props = { groupId: string }

type GroupChatType = ComponentType<{ groupId: string }>

/**
 * Loads the GroupChat component dynamically.
 *
 * The real implementation is being built in parallel in
 * `src/components/chat/group-chat.tsx`. If that file does not exist yet,
 * we gracefully fall back to a placeholder so the page still renders.
 */
export function GroupChatLoader({ groupId }: Props) {
  const [Comp, setComp] = useState<GroupChatType | null>(null)
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    let mounted = true
    import('@/components/chat/group-chat')
      .then((mod) => {
        if (!mounted) return
        const C = (mod.GroupChat || mod.default) as GroupChatType | undefined
        if (C) setComp(() => C)
        else setFailed(true)
      })
      .catch(() => {
        if (mounted) setFailed(true)
      })
    return () => {
      mounted = false
    }
  }, [])

  if (Comp) {
    return <Comp groupId={groupId} />
  }

  if (failed) {
    return (
      <div className="flex flex-col items-center justify-center text-center py-12 gap-3">
        <div className="w-14 h-14 rounded-full bg-accent/15 flex items-center justify-center">
          <MessageCircle className="w-7 h-7 text-accent-foreground" />
        </div>
        <h3 className="font-semibold text-base">چت گروهی به زودی</h3>
        <p className="text-sm text-muted-foreground max-w-md">
          بخش پیام‌رسان گروهی در حال توسعه است و به‌زودی فعال خواهد شد. می‌توانید
          فعلاً تب اعضا و خلاصه‌ها را ببینید.
        </p>
      </div>
    )
  }

  return (
    <div className="flex flex-col items-center justify-center py-12 gap-2 text-muted-foreground">
      <Loader2 className="w-6 h-6 animate-spin" />
      <span className="text-sm">در حال بارگذاری چت...</span>
    </div>
  )
}
