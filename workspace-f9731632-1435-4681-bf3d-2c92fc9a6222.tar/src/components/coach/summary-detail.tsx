'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useQuery } from '@tanstack/react-query'
import ReactMarkdown from 'react-markdown'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import {
  Download,
  FileText,
  FileAudio,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  RefreshCw,
} from 'lucide-react'
import { formatJalaliDate } from '@/lib/format-jalali'

type Summary = {
  id: string
  audioUrl: string
  transcript: string | null
  summary: string | null
  status: string
  createdAt: string
  updatedAt: string
  group: { id: string; name: string }
}

export function SummaryDetail({ summaryId, initial }: { summaryId: string; initial: Summary }) {
  const router = useRouter()
  const { toast } = useToast()
  const [polling, setPolling] = useState(
    initial.status === 'pending' || initial.status === 'processing'
  )

  const { data, refetch } = useQuery<{ summary: Summary }>({
    queryKey: ['coach', 'summaries', summaryId],
    queryFn: async () => {
      const r = await fetch(`/api/coach/summaries/${summaryId}`)
      if (!r.ok) throw new Error('خطا در بارگذاری خلاصه')
      return r.json()
    },
    initialData: { summary: initial },
    refetchInterval: polling ? 5000 : false,
    enabled: true,
  })

  const summary = data?.summary || initial

  useEffect(() => {
    if (summary.status === 'completed' || summary.status === 'failed') {
      if (polling) {
        setPolling(false)
        if (summary.status === 'completed') {
          toast({ title: 'خلاصه آماده شد ✅' })
        }
      }
    }
  }, [summary.status, polling, toast])

  async function handleDownload(format: 'pdf' | 'markdown') {
    try {
      const r = await fetch(`/api/coach/summaries/${summaryId}/download?format=${format}`)
      if (!r.ok) throw new Error('خطا در دانلود')
      const blob = await r.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `summary-${summaryId}.${format === 'pdf' ? 'html' : 'md'}`
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
    } catch (e: any) {
      toast({
        title: 'خطا',
        description: e.message || 'خطایی رخ داد',
        variant: 'destructive',
      })
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-primary">{summary.group.name}</h1>
          <p className="text-sm text-muted-foreground mt-1">
            خلاصه جلسه مورخ {formatJalaliDate(summary.createdAt, true)}
          </p>
          <div className="mt-2">
            <StatusBadge status={summary.status} />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => refetch()}
            disabled={!polling}
          >
            <RefreshCw className={`w-4 h-4 ${polling ? 'animate-spin' : ''}`} />
            به‌روزرسانی
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => handleDownload('markdown')}
            disabled={summary.status !== 'completed'}
          >
            <FileText className="w-4 h-4" />
            دانلود Markdown
          </Button>
          <Button
            variant="default"
            size="sm"
            className="rounded-full"
            onClick={() => handleDownload('pdf')}
            disabled={summary.status !== 'completed'}
          >
            <Download className="w-4 h-4" />
            دانلود PDF
          </Button>
        </div>
      </div>

      <Card className="border-accent/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <FileAudio className="w-5 h-5 text-primary" />
            فایل صوتی جلسه
          </CardTitle>
          <CardDescription>پخش فایل اصلی جلسه</CardDescription>
        </CardHeader>
        <CardContent>
          <audio controls src={summary.audioUrl} className="w-full" />
        </CardContent>
      </Card>

      {(summary.status === 'pending' || summary.status === 'processing') && (
        <Card className="border-gold/40 bg-gold/5">
          <CardContent className="py-8 flex flex-col items-center text-center gap-2">
            <Loader2 className="w-8 h-8 animate-spin text-gold" />
            <h3 className="font-bold text-base">در حال پردازش هوش مصنوعی...</h3>
            <p className="text-sm text-muted-foreground max-w-md">
              فایل صوتی در حال تبدیل به متن و تولید خلاصه است. این مرحله ممکن است چند دقیقه طول بکشد.
              این صفحه به‌صورت خودکار به‌روز می‌شود.
            </p>
          </CardContent>
        </Card>
      )}

      {summary.status === 'completed' && (
        <>
          {summary.summary && (
            <Card className="border-accent/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Sparkles className="w-5 h-5 text-primary" />
                  خلاصه جلسه
                </CardTitle>
                <CardDescription>تولید شده توسط هوش مصنوعی</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none rtl:prose-headings:text-primary rtl:prose-headings:font-bold rtl:prose-strong:text-foreground">
                  <ReactMarkdown>{summary.summary}</ReactMarkdown>
                </div>
              </CardContent>
            </Card>
          )}

          {summary.transcript && (
            <Card className="border-accent/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <FileText className="w-5 h-5 text-primary" />
                  ترانسکریپت کامل
                </CardTitle>
                <CardDescription>متن کامل تبدیل شده از فایل صوتی</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="max-h-96 overflow-y-auto custom-scroll rounded-xl bg-muted/30 p-4">
                  <div className="prose prose-sm max-w-none whitespace-pre-wrap">
                    {summary.transcript}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {summary.status === 'failed' && (
        <Card className="border-destructive/40 bg-destructive/5">
          <CardContent className="py-8 flex flex-col items-center text-center gap-2">
            <AlertCircle className="w-8 h-8 text-destructive" />
            <h3 className="font-bold text-base">پردازش ناموفق بود</h3>
            <p className="text-sm text-muted-foreground max-w-md">
              متأسفانه در پردازش فایل صوتی خطایی رخ داد. لطفاً مطمئن شوید فایل قابل پخش است و دوباره تلاش کنید.
            </p>
            <Button variant="outline" size="sm" className="rounded-full" onClick={() => router.refresh()}>
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'completed':
      return (
        <Badge variant="outline" className="text-sprout border-sprout/40 bg-sprout/10">
          <CheckCircle2 className="w-3 h-3 ml-1" />
          تکمیل شده
        </Badge>
      )
    case 'processing':
      return (
        <Badge variant="outline" className="text-gold border-gold/40 bg-gold/10">
          <Loader2 className="w-3 h-3 ml-1 animate-spin" />
          در حال پردازش
        </Badge>
      )
    case 'pending':
      return (
        <Badge variant="outline" className="text-gold border-gold/40 bg-gold/10">
          <Clock className="w-3 h-3 ml-1" />
          در انتظار
        </Badge>
      )
    case 'failed':
      return (
        <Badge variant="outline" className="text-destructive border-destructive/40 bg-destructive/10">
          <AlertCircle className="w-3 h-3 ml-1" />
          ناموفق
        </Badge>
      )
    default:
      return null
  }
}
