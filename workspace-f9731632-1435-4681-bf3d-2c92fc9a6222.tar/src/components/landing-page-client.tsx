'use client'

import { motion } from 'framer-motion'
import Image from 'next/image'
import Link from 'next/link'
import { ArrowLeft, BookOpen, Calendar, MapPin, Users, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardContent, CardFooter, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

type BlogPost = {
  id: string
  title: string
  excerpt: string | null
  image: string | null
  createdAt: string
}

type Settings = {
  siteName: string
  description: string
  heroTitle: string
  heroSubtitle: string
  introVideo: string | null
  logo: string | null
  contactInfo: string | null
}

export function LandingPageClient({
  settings,
  blogPosts,
  session,
}: {
  settings: Settings
  blogPosts: BlogPost[]
  session: any
}) {
  const dashboardHref = session?.user?.role === 'SUPER_ADMIN'
    ? '/admin'
    : session?.user?.role === 'COACH'
    ? '/coach'
    : session?.user?.role === 'MEMBER'
    ? '/member'
    : '/login'

  return (
    <>
      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden gradient-hero">
        {/* Background image */}
        <div className="absolute inset-0 z-0">
          <Image
            src="/hero-bg.jpg"
            alt="پس‌زمینه هیرو"
            fill
            className="object-cover opacity-15"
            priority
            sizes="100vw"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/30 to-background" />
        </div>

        {/* Decorative orbs */}
        <motion.div
          className="absolute top-20 right-10 w-32 h-32 md:w-64 md:h-64 rounded-full bg-accent/20 blur-3xl"
          animate={{ y: [0, -20, 0], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-32 left-10 w-40 h-40 md:w-80 md:h-80 rounded-full bg-sprout/20 blur-3xl"
          animate={{ y: [0, 20, 0], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 10, repeat: Infinity }}
        />

        <div className="relative z-10 max-w-4xl mx-auto px-4 py-32 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="inline-flex items-center justify-center mb-6"
          >
            <Image
              src={settings.logo || '/institute-logo-final.png'}
              alt={settings.siteName}
              width={240}
              height={160}
              className="shadow-2xl drop-shadow-2xl"
            />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.7 }}
            className="text-3xl md:text-6xl font-bold text-primary mb-3 leading-tight"
          >
            {settings.heroTitle || 'رویش‌های پیشران'}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.7 }}
            className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto"
          >
            {settings.heroSubtitle || 'فضایی برای رویش نوجوانان در سایه آموزه‌های دینی'}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.7 }}
            className="flex flex-col sm:flex-row gap-3 justify-center items-center"
          >
            <Button asChild size="lg" className="rounded-full shadow-xl min-w-[180px]">
              <Link href={dashboardHref}>
                {session?.user ? 'ورود به پیشخان' : 'ورود به حساب'}
                <ArrowLeft className="w-4 h-4 mr-2" />
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="rounded-full min-w-[180px] bg-background/70 backdrop-blur-sm"
            >
              <Link href="#about">درباره ما</Link>
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 0.7 }}
            className="mt-12 grid grid-cols-3 gap-4 max-w-2xl mx-auto"
          >
            <div className="flex flex-col items-center">
              <Users className="w-5 h-5 md:w-7 md:h-7 text-accent-foreground mb-1" />
              <span className="text-xl md:text-2xl font-bold text-primary">۶۵۸+</span>
              <span className="text-xs md:text-sm text-muted-foreground">دنبال‌کننده</span>
            </div>
            <div className="flex flex-col items-center">
              <BookOpen className="w-5 h-5 md:w-7 md:h-7 text-accent-foreground mb-1" />
              <span className="text-xl md:text-2xl font-bold text-primary">۴.۶هزار</span>
              <span className="text-xs md:text-sm text-muted-foreground">محتوا</span>
            </div>
            <div className="flex flex-col items-center">
              <Sparkles className="w-5 h-5 md:w-7 md:h-7 text-accent-foreground mb-1" />
              <span className="text-xl md:text-2xl font-bold text-primary">۴۴+</span>
              <span className="text-xs md:text-sm text-muted-foreground">فایل آموزشی</span>
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-6 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <div className="w-6 h-10 rounded-full border-2 border-primary/40 flex items-start justify-center pt-2">
            <div className="w-1 h-2 rounded-full bg-primary/60" />
          </div>
        </motion.div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 gradient-spiritual">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7 }}
            className="text-center mb-12"
          >
            <Badge variant="secondary" className="mb-3">معرفی موسسه</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-primary">درباره‌ی موسسه</h2>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-10 items-center">
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="space-y-4"
            >
              <p className="text-base md:text-lg leading-relaxed text-foreground/85">
                {settings.description}
              </p>
              <div className="flex items-start gap-3 text-sm text-muted-foreground bg-card/50 p-4 rounded-xl border border-border/40">
                <MapPin className="w-5 h-5 text-accent-foreground shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-foreground block mb-1">آدرس موسسه:</span>
                  {settings.contactInfo ||
                    'بلوار امین، حدفاصل بلوار جمهوری و خیابان گلستان، مدرسه علمیه معصومیه'}
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="relative aspect-square max-w-sm mx-auto"
            >
              <Image
                src="/hero-bg.jpg"
                alt="تصویر موسسه"
                fill
                className="object-cover rounded-3xl shadow-2xl ring-4 ring-accent/20"
                sizes="(max-width: 768px) 100vw, 384px"
              />
            </motion.div>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
            {[
              {
                title: 'برنامه‌های تربیتی',
                desc: 'دوره‌های متنوع تربیتی برای نوجوانان مقطع ششم تا کنکور با محوریت ارزش‌های دینی و انقلابی.',
                icon: Users,
              },
              {
                title: 'کاروان عهد و میثاق',
                desc: 'پیوند نسل تازه با خون شهیدان و عهد جمعی به استقامت پای انقلاب اسلامی.',
                icon: Sparkles,
              },
              {
                title: 'فعالیت‌های گروهی',
                desc: 'لیگ لیزرتگ، نشاط و کار تیمی برای تقویت روحیه جمعی و چابکی نوجوانان.',
                icon: BookOpen,
              },
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15, duration: 0.6 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow border-accent/20 bg-card/70 backdrop-blur">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-2xl bg-accent/20 flex items-center justify-center mb-2">
                      <feature.icon className="w-6 h-6 text-accent-foreground" />
                    </div>
                    <CardTitle className="text-primary text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground leading-relaxed">{feature.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Intro Video Section */}
      {settings.introVideo && (
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="text-center mb-8"
            >
              <Badge variant="secondary" className="mb-3">فیلم معرفی</Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-primary">معرفی موسسه</h2>
            </motion.div>
            <div className="aspect-video rounded-3xl overflow-hidden shadow-2xl ring-4 ring-accent/20">
              <video
                src={settings.introVideo}
                controls
                className="w-full h-full bg-black"
                poster="/hero-bg.jpg"
              />
            </div>
          </div>
        </section>
      )}

      {/* Blog Section */}
      <section id="blog" className="py-20 px-4 pattern-islamic">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-center mb-12"
          >
            <Badge variant="secondary" className="mb-3">وبلاگ موسسه</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-primary">آخرین مطالب</h2>
            <p className="mt-3 text-muted-foreground max-w-2xl mx-auto">
              آخرین اخبار و گزارش برنامه‌های موسسه رویش‌های پیشران
            </p>
          </motion.div>

          {blogPosts.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <Calendar className="w-12 h-12 mx-auto mb-3 opacity-40" />
              هنوز مطلبی منتشر نشده است.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {blogPosts.map((post, i) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-50px' }}
                  transition={{ delay: i * 0.1, duration: 0.6 }}
                >
                  <Card className="h-full overflow-hidden hover:shadow-xl transition-all border-accent/20 bg-card/70 backdrop-blur group">
                    {post.image && (
                      <div className="relative aspect-video overflow-hidden">
                        <Image
                          src={post.image}
                          alt={post.title}
                          fill
                          className="object-cover group-hover:scale-105 transition-transform duration-700"
                        />
                      </div>
                    )}
                    <CardHeader>
                      <CardDescription className="text-xs">
                        {new Date(post.createdAt).toLocaleDateString('fa-IR')}
                      </CardDescription>
                      <CardTitle className="text-primary text-base line-clamp-2">{post.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {post.excerpt && (
                        <p className="text-sm text-muted-foreground line-clamp-3 leading-relaxed">
                          {post.excerpt}
                        </p>
                      )}
                    </CardContent>
                    <CardFooter>
                      <Button variant="ghost" size="sm" asChild className="text-primary">
                        <Link href={`/blog/${post.id}`}>
                          ادامه مطلب
                          <ArrowLeft className="w-4 h-4 mr-1" />
                        </Link>
                      </Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="py-20 px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="max-w-4xl mx-auto text-center rounded-3xl p-10 md:p-16 bg-gradient-to-br from-primary to-sprout text-primary-foreground shadow-2xl"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">به خانواده‌ی رویش‌های پیشران بپیوندید</h2>
          <p className="text-base md:text-lg opacity-90 mb-8 max-w-2xl mx-auto">
            برای شرکت در دوره‌ها و برنامه‌های موسسه، وارد حساب کاربری خود شوید یا با مربی گروه خود تماس بگیرید.
          </p>
          <Button
            asChild
            size="lg"
            variant="secondary"
            className="rounded-full bg-background text-primary hover:bg-background/90 shadow-xl min-w-[180px]"
          >
            <Link href={dashboardHref}>شروع کنید</Link>
          </Button>
        </motion.div>
      </section>
    </>
  )
}
