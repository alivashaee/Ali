"use client"

import { Toaster as Sonner, ToasterProps } from "sonner"

// Lightweight wrapper around Sonner that doesn't depend on next-themes
// (so it works even without a ThemeProvider in the tree).
const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      theme="light"
      className="toaster group"
      style={
        {
          "--normal-bg": "var(--popover)",
          "--normal-text": "var(--popover-foreground)",
          "--normal-border": "var(--border)",
        } as React.CSSProperties
      }
      {...props}
    />
  )
}

export { Toaster }
