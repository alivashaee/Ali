'use client'

import { useState, useRef } from 'react'
import { Upload, Loader2, X, ImageIcon } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useToast } from '@/hooks/use-toast'

type Props = {
  value?: string | null
  onChange: (url: string | null) => void
  accept?: string
  label?: string
  /** Show a thumbnail if the URL is an image */
  preview?: boolean
  /** Upload endpoint: /api/admin/upload, /api/coach/upload, /api/member/upload */
  endpoint?: string
}

export function FileUpload({
  value,
  onChange,
  accept = 'image/*',
  label = 'بارگذاری فایل',
  preview = true,
  endpoint = '/api/admin/upload',
}: Props) {
  const [uploading, setUploading] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const isImage = (url?: string | null) =>
    !!url && /\.(jpg|jpeg|png|gif|webp|svg)$/i.test(url)

  async function handleFile(file?: File) {
    if (!file) return
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const res = await fetch(endpoint, {
        method: 'POST',
        body: fd,
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'خطا در بارگذاری')
      onChange(data.url)
      toast({ title: 'فایل بارگذاری شد ✅' })
    } catch (e: any) {
      toast({
        title: 'خطا',
        description: e?.message || 'بارگذاری ناموفق بود',
        variant: 'destructive',
      })
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="space-y-2">
      {/* Native file input - visually hidden but clickable */}
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        className="sr-only"
        onChange={(e) => {
          handleFile(e.target.files?.[0])
          // Reset input so same file can be selected again
          e.target.value = ''
        }}
      />
      <div className="flex items-center gap-2 flex-wrap">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          className="rounded-full"
        >
          {uploading ? (
            <>
              <Loader2 className="w-4 h-4 ml-2 animate-spin" />
              در حال بارگذاری...
            </>
          ) : (
            <>
              <Upload className="w-4 h-4 ml-2" />
              {label}
            </>
          )}
        </Button>
        {value && (
          <Button
            type="button"
            size="icon"
            variant="ghost"
            onClick={() => onChange(null)}
            title="حذف فایل"
            className="rounded-full"
          >
            <X className="w-4 h-4" />
          </Button>
        )}
      </div>
      {value && preview && isImage(value) && (
        <div className="relative w-32 h-24 rounded-lg overflow-hidden border border-border bg-muted">
          <img
            src={value}
            alt={label}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      {value && !preview && (
        <a
          href={value}
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs text-primary hover:underline block max-w-full truncate"
        >
          {value}
        </a>
      )}
      {value && preview && !isImage(value) && (
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <ImageIcon className="w-3.5 h-3.5" />
          <a href={value} target="_blank" rel="noopener noreferrer" className="hover:underline truncate max-w-[200px]">
            {value.split('/').pop()}
          </a>
        </div>
      )}
    </div>
  )
}
