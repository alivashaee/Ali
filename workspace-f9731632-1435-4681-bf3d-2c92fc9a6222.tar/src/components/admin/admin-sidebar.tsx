'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard,
  Users,
  FileText,
  Users2,
  BarChart3,
  Settings,
} from 'lucide-react'

const navItems = [
  { href: '/admin', label: 'داشبورد', icon: LayoutDashboard },
  { href: '/admin/users', label: 'کاربران', icon: Users },
  { href: '/admin/content', label: 'محتوا', icon: FileText },
  { href: '/admin/groups', label: 'گروه‌ها', icon: Users2 },
  { href: '/admin/polls', label: 'نظرسنجی‌ها', icon: BarChart3 },
  { href: '/admin/settings', label: 'تنظیمات', icon: Settings },
]

export function AdminSidebar() {
  const pathname = usePathname()

  return (
    <aside className="hidden md:flex md:w-60 md:flex-col md:fixed md:inset-y-0 md:right-0 border-l bg-sidebar/80 backdrop-blur-sm z-30 pt-20">
      <div className="flex flex-col gap-1 p-3 overflow-y-auto custom-scroll">
        <p className="text-xs font-semibold text-muted-foreground px-3 pt-2 pb-2">
          مدیریت سامانه
        </p>
        {navItems.map((item) => {
          const isActive =
            pathname === item.href ||
            (item.href !== '/admin' && pathname.startsWith(item.href))
          const Icon = item.icon
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
                isActive
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
              )}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{item.label}</span>
            </Link>
          )
        })}
      </div>
    </aside>
  )
}

export function AdminMobileNav() {
  const pathname = usePathname()
  return (
    <nav className="md:hidden sticky top-20 z-30 -mx-4 px-4 mb-4 bg-background/80 backdrop-blur-sm border-b pb-2">
      <div className="flex gap-1 overflow-x-auto custom-scroll">
        {navItems.map((item) => {
          const isActive =
            pathname === item.href ||
            (item.href !== '/admin' && pathname.startsWith(item.href))
          const Icon = item.icon
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors',
                isActive
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground'
              )}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span>{item.label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
