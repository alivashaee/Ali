import Link from 'next/link'
import { Mail, MapPin, Phone } from 'lucide-react'

type Props = {
  siteName?: string
  contactInfo?: string | null
}

export function SiteFooter({ siteName, contactInfo }: Props) {
  return (
    <footer className="mt-auto bg-gradient-to-t from-primary/5 to-transparent border-t border-border/50">
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About */}
          <div>
            <h3 className="font-bold text-primary mb-3 text-base">
              {siteName || 'موسسه رویش‌های پیشران'}
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              موسسه تربیتی وابسته به مسجد فاطمه معصومه(سلام الله علیها)، با همکاری طلاب و
              اساتید فارغ‌التحصیل دانشگاه و مدرسه علمیه معصومیه.
            </p>
          </div>

          {/* Links */}
          <div>
            <h3 className="font-bold text-primary mb-3 text-base">دسترسی سریع</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/#home" className="text-muted-foreground hover:text-primary transition-colors">
                  خانه
                </Link>
              </li>
              <li>
                <Link href="/#about" className="text-muted-foreground hover:text-primary transition-colors">
                  درباره ما
                </Link>
              </li>
              <li>
                <Link href="/#blog" className="text-muted-foreground hover:text-primary transition-colors">
                  وبلاگ
                </Link>
              </li>
              <li>
                <Link href="/login" className="text-muted-foreground hover:text-primary transition-colors">
                  ورود به حساب
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-bold text-primary mb-3 text-base">اطلاعات تماس</h3>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-accent-foreground mt-0.5 shrink-0" />
                <span>
                  {contactInfo ||
                    'بلوار امین، حدفاصل بلوار جمهوری و خیابان گلستان، مدرسه علمیه معصومیه'}
                </span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-accent-foreground shrink-0" />
                <a href="https://eitaa.org/rooyesh_pishrun" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
                  کانال ایتا: @rooyesh_pishrun
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-accent-foreground shrink-0" />
                <a href="mailto:info@rooyesh-pishrun.ir" className="hover:text-primary transition-colors">
                  info@rooyesh-pishrun.ir
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-border/50 text-center text-xs text-muted-foreground">
          <p>
            © {new Date().getFullYear()} {siteName || 'موسسه رویش‌های پیشران'} — تمامی حقوق محفوظ است.
          </p>
        </div>
      </div>
    </footer>
  )
}
