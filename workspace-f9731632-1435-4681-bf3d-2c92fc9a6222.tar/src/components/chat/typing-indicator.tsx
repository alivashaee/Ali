'use client'

import { motion } from 'framer-motion'

interface TypingIndicatorProps {
  /** Names of users currently typing. If empty, render nothing. */
  users?: string[]
  className?: string
}

export function TypingIndicator({ users, className }: TypingIndicatorProps) {
  if (!users || users.length === 0) return null

  const label =
    users.length === 1
      ? `${users[0]} در حال نوشتن است...`
      : `${users.slice(0, 2).join(' و ')} در حال نوشتن هستند...`

  return (
    <motion.div
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -4 }}
      transition={{ duration: 0.18 }}
      className={`flex items-center gap-2 text-xs text-muted-foreground ${className ?? ''}`}
      dir="rtl"
    >
      <span className="inline-flex items-center gap-1 rounded-full bg-muted/70 px-3 py-1.5">
        <span className="flex items-end gap-0.5">
          {[0, 1, 2].map((i) => (
            <motion.span
              key={i}
              className="size-1.5 rounded-full bg-foreground/60"
              animate={{ y: [0, -3, 0], opacity: [0.4, 1, 0.4] }}
              transition={{
                duration: 0.9,
                repeat: Infinity,
                delay: i * 0.15,
                ease: 'easeInOut',
              }}
            />
          ))}
        </span>
        <span className="ms-1">{label}</span>
      </span>
    </motion.div>
  )
}

export default TypingIndicator
