'use client'

import * as React from 'react'
import { useState } from 'react'
import { Loader2, Paperclip } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export interface UploadedFile {
  url: string
  fileName: string
  fileType: string
  size: number
}

interface FileUploadButtonProps {
  /** Endpoint that handles the upload (e.g. '/api/coach/upload' or '/api/member/upload'). */
  endpoint: string
  /** Called when upload completes successfully. */
  onUploaded: (file: UploadedFile) => void
  /** Called when an error occurs. */
  onError?: (message: string) => void
  /** Disabled state (e.g. when not connected yet). */
  disabled?: boolean
  className?: string
  /** Label text shown in the button (used as aria-label too). */
  label?: string
}

const ACCEPT =
  'image/*,application/pdf,audio/*,video/*,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt'

export function FileUploadButton({
  endpoint,
  onUploaded,
  onError,
  disabled,
  className,
  label = 'پیوست فایل',
}: FileUploadButtonProps) {
  const inputRef = React.useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)

  function openPicker() {
    if (uploading || disabled) return
    inputRef.current?.click()
  }

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return

    setUploading(true)
    setProgress(0)
    try {
      const fd = new FormData()
      fd.append('file', file)

      const res = await new Promise<Response>((resolve, reject) => {
        const xhr = new XMLHttpRequest()
        xhr.open('POST', endpoint, true)
        xhr.upload.onprogress = (ev) => {
          if (ev.lengthComputable) {
            setProgress(Math.round((ev.loaded / ev.total) * 100))
          }
        }
        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            resolve(
              new Response(xhr.responseText, {
                status: xhr.status,
                headers: xhr.getAllResponseHeaders(),
              }),
            )
          } else {
            try {
              const j = JSON.parse(xhr.responseText)
              reject(new Error(j.error || 'آپلود ناموفق بود'))
            } catch {
              reject(new Error('آپلود ناموفق بود'))
            }
          }
        }
        xhr.onerror = () => reject(new Error('خطای شبکه هنگام آپلود'))
        xhr.send(fd)
      })

      const data = await res.json()
      if (!res.ok) {
        throw new Error(data.error || 'آپلود ناموفق بود')
      }
      onUploaded({
        url: data.url,
        fileName: data.fileName ?? file.name,
        fileType: data.fileType ?? file.type,
        size: data.size ?? file.size,
      })
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'خطا در آپلود فایل'
      onError?.(msg)
    } finally {
      setUploading(false)
      setProgress(0)
    }
  }

  return (
    <div className="relative">
      <input
        ref={inputRef}
        type="file"
        accept={ACCEPT}
        className="sr-only"
        onChange={handleFile}
        disabled={uploading || disabled}
      />
      <Button
        type="button"
        size="icon"
        variant="ghost"
        onClick={openPicker}
        disabled={uploading || disabled}
        aria-label={label}
        title={label}
        className={cn('size-9 rounded-full', className)}
      >
        {uploading ? (
          <>
            <Loader2 className="size-4 animate-spin" />
            <span className="sr-only">{`در حال آپلود... ${progress}%`}</span>
          </>
        ) : (
          <Paperclip className="size-4" />
        )}
      </Button>
      {uploading && (
        <div className="absolute bottom-full left-0 mb-1 w-40 rounded-md border bg-popover p-2 text-[10px] shadow-sm">
          <div className="mb-1 flex items-center justify-between">
            <span className="text-muted-foreground">آپلود...</span>
            <span className="font-mono">{progress}%</span>
          </div>
          <div className="h-1 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full bg-primary transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}
    </div>
  )
}

export default FileUploadButton
