'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  CheckCheck,
  Download,
  FileText,
  Smile,
} from 'lucide-react'
import ReactMarkdown from 'react-markdown'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import { cn } from '@/lib/utils'
import type { ChatMessage } from '@/lib/socket-client'

const QUICK_EMOJIS = ['👍', '❤️', '😂', '🙏', '🔥'] as const

interface MessageBubbleProps {
  message: ChatMessage
  isOwn: boolean
  onReact: (messageId: string, emoji: string) => void
  currentUserId?: string
  showAvatar?: boolean
  showName?: boolean
  className?: string
}

function formatTime(iso: string): string {
  try {
    const d = new Date(iso)
    return d.toLocaleTimeString('fa-IR', {
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return ''
  }
}

function initials(name: string): string {
  const parts = name.trim().split(/\s+/)
  if (parts.length === 0) return '?'
  if (parts.length === 1) return parts[0].slice(0, 2)
  return (parts[0][0] || '') + (parts[1][0] || '')
}

function isImageType(type?: string | null, url?: string | null): boolean {
  if (type && type.startsWith('image/')) return true
  if (url && /\.(png|jpe?g|webp|gif|bmp|svg)(\?|$)/i.test(url)) return true
  return false
}

function isVideoType(type?: string | null, url?: string | null): boolean {
  if (type && type.startsWith('video/')) return true
  if (url && /\.(mp4|webm|mov|avi|mkv)(\?|$)/i.test(url)) return true
  return false
}

function isAudioType(type?: string | null, url?: string | null): boolean {
  if (type && type.startsWith('audio/')) return true
  if (url && /\.(mp3|wav|ogg|weba|m4a|aac)(\?|$)/i.test(url)) return true
  return false
}

export function MessageBubble({
  message,
  isOwn,
  onReact,
  currentUserId,
  showAvatar = true,
  showName = true,
  className,
}: MessageBubbleProps) {
  const [pickerOpen, setPickerOpen] = React.useState(false)

  const reactions = message.reactions ?? {}
  const reactionEntries = Object.entries(reactions).filter(
    ([, users]) => Array.isArray(users) && users.length > 0,
  )

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.2, ease: 'easeOut' }}
      className={cn(
        'group flex w-full gap-2',
        isOwn ? 'justify-start' : 'justify-end',
        className,
      )}
      dir="rtl"
    >
      {/* Avatar for non-own messages (on the "start" side = right in RTL) */}
      {!isOwn && showAvatar && (
        <Avatar className="mt-auto size-8 shrink-0 rounded-full">
          {message.senderAvatar ? (
            <AvatarImage src={message.senderAvatar} alt={message.senderName} />
          ) : null}
          <AvatarFallback className="bg-secondary text-secondary-foreground text-xs">
            {initials(message.senderName)}
          </AvatarFallback>
        </Avatar>
      )}

      <div
        className={cn(
          'flex max-w-[78%] flex-col gap-1',
          isOwn ? 'items-start' : 'items-end',
        )}
      >
        {!isOwn && showName && (
          <span className="px-1 text-[11px] font-medium text-muted-foreground">
            {message.senderName}
          </span>
        )}

        <div
          className={cn(
            'relative inline-block rounded-2xl px-3.5 py-2 text-sm leading-relaxed shadow-sm',
            isOwn
              ? 'rounded-tr-md bg-primary text-primary-foreground'
              : 'rounded-tl-md border bg-card text-card-foreground',
          )}
        >
          {message.content && (
            <div className="prose prose-sm max-w-none break-words [&>*]:my-0.5 [&_a]:text-current [&_a]:underline [&_p]:my-0.5">
              <ReactMarkdown
                components={{
                  h1: ({ children }) => <strong>{children}</strong>,
                  h2: ({ children }) => <strong>{children}</strong>,
                  h3: ({ children }) => <strong>{children}</strong>,
                  img: ({ src, alt }) =>
                    src ? (
                      <img
                        src={typeof src === 'string' ? src : ''}
                        alt={alt ?? ''}
                        className="my-1 max-h-60 rounded-md"
                      />
                    ) : null,
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
          )}

          {/* File preview */}
          {message.fileUrl && (
            <div className="mt-1.5">
              {isImageType(message.fileType, message.fileUrl) ? (
                <a
                  href={message.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block"
                >
                  <img
                    src={message.fileUrl}
                    alt={message.fileName ?? 'فایل'}
                    className="max-h-60 max-w-full rounded-md object-cover"
                  />
                </a>
              ) : isVideoType(message.fileType, message.fileUrl) ? (
                <video
                  src={message.fileUrl}
                  controls
                  className="max-h-60 max-w-full rounded-md"
                />
              ) : isAudioType(message.fileType, message.fileUrl) ? (
                <audio src={message.fileUrl} controls className="w-full" />
              ) : (
                <a
                  href={message.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  download={message.fileName ?? undefined}
                  className={cn(
                    'flex items-center gap-2 rounded-md border p-2 transition-colors',
                    isOwn
                      ? 'border-primary-foreground/30 bg-primary-foreground/10 hover:bg-primary-foreground/20'
                      : 'border-border bg-muted/40 hover:bg-muted',
                  )}
                >
                  <FileText className="size-5 shrink-0" />
                  <div className="flex flex-col">
                    <span className="max-w-[180px] truncate text-xs font-medium">
                      {message.fileName ?? 'فایل'}
                    </span>
                    <span className="text-[10px] opacity-70">دانلود</span>
                  </div>
                  <Download className="ms-auto size-4" />
                </a>
              )}
            </div>
          )}

          {/* Time + read marker */}
          <div
            className={cn(
              'mt-1 flex items-center gap-1 text-[10px]',
              isOwn ? 'text-primary-foreground/70' : 'text-muted-foreground',
            )}
          >
            <span>{formatTime(message.createdAt)}</span>
            {isOwn && <CheckCheck className="size-3" />}
          </div>

          {/* Reaction trigger */}
          <Popover open={pickerOpen} onOpenChange={setPickerOpen}>
            <PopoverTrigger asChild>
              <button
                type="button"
                className={cn(
                  'absolute -bottom-2 rounded-full border bg-background p-1 opacity-0 shadow-sm transition-opacity hover:bg-accent focus-visible:opacity-100 group-hover:opacity-100',
                  isOwn ? '-left-1' : '-right-1',
                )}
                aria-label="افزودن واکنش"
              >
                <Smile className="size-3.5 text-muted-foreground" />
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-auto rounded-full p-1" sideOffset={4}>
              <div className="flex items-center gap-0.5">
                {QUICK_EMOJIS.map((e) => (
                  <button
                    key={e}
                    type="button"
                    onClick={() => {
                      onReact(message.id, e)
                      setPickerOpen(false)
                    }}
                    className="rounded-full p-1.5 text-base transition-transform hover:scale-125 hover:bg-accent"
                  >
                    {e}
                  </button>
                ))}
              </div>
            </PopoverContent>
          </Popover>
        </div>

        {/* Reactions row */}
        {reactionEntries.length > 0 && (
          <div
            className={cn(
              'flex flex-wrap gap-1',
              isOwn ? 'justify-start' : 'justify-end',
            )}
          >
            <AnimatePresence>
              {reactionEntries.map(([emoji, users]) => {
                const userIds = users as string[]
                const reactedByMe = currentUserId
                  ? userIds.includes(currentUserId)
                  : false
                return (
                  <motion.button
                    key={emoji}
                    layout
                    initial={{ opacity: 0, scale: 0.6 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.6 }}
                    transition={{ duration: 0.15 }}
                    type="button"
                    onClick={() => onReact(message.id, emoji)}
                    className={cn(
                      'inline-flex items-center gap-1 rounded-full border bg-background px-2 py-0.5 text-xs shadow-sm transition-colors hover:bg-accent',
                      reactedByMe
                        ? 'border-primary/40 bg-primary/10'
                        : 'border-border',
                    )}
                  >
                    <span className="text-sm">{emoji}</span>
                    <span className="text-[10px] font-medium text-muted-foreground">
                      {userIds.length}
                    </span>
                  </motion.button>
                )
              })}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Spacer where avatar would be for own messages — keep symmetry */}
      {isOwn && showAvatar && (
        <Avatar className="mt-auto size-8 shrink-0 rounded-full opacity-0">
          <AvatarFallback className="bg-muted text-xs">.</AvatarFallback>
        </Avatar>
      )}
    </motion.div>
  )
}

export default MessageBubble
