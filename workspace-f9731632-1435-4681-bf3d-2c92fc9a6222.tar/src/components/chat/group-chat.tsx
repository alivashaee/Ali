'use client'

import * as React from 'react'
import { useSession } from 'next-auth/react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  AlertCircle,
  ImagePlus,
  Loader2,
  Paperclip,
  Send,
  Users,
  X,
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { getSocket, type ChatMessage } from '@/lib/socket-client'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { cn } from '@/lib/utils'
import { MessageBubble } from './message-bubble'
import { TypingIndicator } from './typing-indicator'
import { FileUploadButton, type UploadedFile } from './file-upload-button'

interface GroupChatProps {
  groupId: string
  className?: string
  /** Override the upload endpoint (default based on role). */
  uploadEndpoint?: string
  /** Optional title to show in header (defaults to "گفتگوی گروه"). */
  title?: string
  /** Max height of the chat window. */
  maxHeight?: string
}

export function GroupChat({
  groupId,
  className,
  uploadEndpoint,
  title = 'گفتگوی گروه',
  maxHeight = '70vh',
}: GroupChatProps) {
  const { data: session, status } = useSession()
  const { toast } = useToast()

  const [messages, setMessages] = React.useState<ChatMessage[]>([])
  const [draft, setDraft] = React.useState('')
  const [connected, setConnected] = React.useState(false)
  const [joining, setJoining] = React.useState(false)
  const [onlineUsers, setOnlineUsers] = React.useState<
    Array<{ userId: string; userName: string; avatar: string | null }>
  >([])
  const [typingUsers, setTypingUsers] = React.useState<
    Record<string, { userName: string; ts: number }>
  >({})
  const [pendingFile, setPendingFile] = React.useState<UploadedFile | null>(null)
  const [error, setError] = React.useState<string | null>(null)
  const [showJump, setShowJump] = React.useState(false)

  const scrollRef = React.useRef<HTMLDivElement>(null)
  const socketRef = React.useRef<ReturnType<typeof getSocket> | null>(null)
  const typingTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)
  const lastTypingEmitRef = React.useRef<number>(0)

  const user = session?.user
  const uploadUrl =
    uploadEndpoint ??
    (user?.role === 'COACH' || user?.role === 'SUPER_ADMIN'
      ? '/api/coach/upload'
      : '/api/member/upload')

  // Join group when session is ready
  React.useEffect(() => {
    if (status !== 'authenticated' || !user?.id) return
    if (!groupId) return

    setJoining(true)
    setError(null)
    setMessages([])
    setOnlineUsers([])
    setTypingUsers({})

    const socket = getSocket()
    socketRef.current = socket

    const onConnect = () => {
      setConnected(true)
      socket.emit(
        'join-group',
        {
          groupId,
          userId: user.id,
          userName: user.name,
        },
        (ack: { ok?: boolean; error?: string } | undefined) => {
          setJoining(false)
          if (!ack?.ok) {
            const msg =
              ack?.error === 'forbidden'
                ? 'شما به این گروه دسترسی ندارید'
                : 'اتصال به گروه ناموفق بود'
            setError(msg)
          } else {
            setError(null)
          }
        },
      )
    }

    const onDisconnect = () => {
      setConnected(false)
      setJoining(false)
    }

    const onMessageHistory = (data: {
      groupId: string
      messages: ChatMessage[]
    }) => {
      if (data.groupId !== groupId) return
      setMessages(
        data.messages.map((m) => ({
          ...m,
          isOwn: m.senderId === user.id,
        })),
      )
      requestAnimationFrame(() => {
        if (scrollRef.current) {
          scrollRef.current.scrollTop = scrollRef.current.scrollHeight
        }
      })
    }

    const onNewMessage = (m: ChatMessage) => {
      if (m.groupId !== groupId) return
      setMessages((prev) => [
        ...prev,
        { ...m, isOwn: m.senderId === user.id },
      ])
      if (scrollRef.current) {
        const el = scrollRef.current
        const nearBottom =
          el.scrollHeight - el.scrollTop - el.clientHeight < 240
        if (nearBottom) {
          requestAnimationFrame(() => {
            el.scrollTop = el.scrollHeight
          })
        } else {
          setShowJump(true)
        }
      }
    }

    const onMessageReaction = (data: {
      messageId: string
      reactions: Record<string, string[]>
    }) => {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === data.messageId ? { ...m, reactions: data.reactions } : m,
        ),
      )
    }

    const onUserTyping = (data: {
      userId: string
      userName: string
      groupId: string
      isTyping: boolean
    }) => {
      if (data.groupId !== groupId || data.userId === user.id) return
      setTypingUsers((prev) => {
        const next = { ...prev }
        if (data.isTyping) {
          next[data.userId] = { userName: data.userName, ts: Date.now() }
        } else {
          delete next[data.userId]
        }
        return next
      })
    }

    const onUserOnline = (data: {
      userId: string
      userName: string
      avatar: string | null
      groupId: string
    }) => {
      if (data.groupId !== groupId) return
      setOnlineUsers((prev) => {
        if (prev.some((u) => u.userId === data.userId)) return prev
        return [
          ...prev,
          {
            userId: data.userId,
            userName: data.userName,
            avatar: data.avatar,
          },
        ]
      })
    }

    const onUserOffline = (data: { userId: string; groupId: string }) => {
      if (data.groupId !== groupId) return
      setOnlineUsers((prev) => prev.filter((u) => u.userId !== data.userId))
      setTypingUsers((prev) => {
        const next = { ...prev }
        delete next[data.userId]
        return next
      })
    }

    const onOnlineUsers = (data: {
      groupId: string
      users: Array<{ userId: string; userName: string; avatar: string | null }>
    }) => {
      if (data.groupId !== groupId) return
      setOnlineUsers(data.users)
    }

    const onChatError = (data: { message: string }) => {
      setError(data.message)
      setJoining(false)
      toast({
        title: 'خطا',
        description: data.message,
        variant: 'destructive',
      })
    }

    const onConnectError = () => {
      setConnected(false)
      setJoining(false)
      setError('اتصال به سرور گفتگو ناموفق بود')
    }

    socket.on('connect', onConnect)
    socket.on('disconnect', onDisconnect)
    socket.on('connect_error', onConnectError)
    socket.on('message-history', onMessageHistory)
    socket.on('new-message', onNewMessage)
    socket.on('message-reaction', onMessageReaction)
    socket.on('user-typing', onUserTyping)
    socket.on('user-online', onUserOnline)
    socket.on('user-offline', onUserOffline)
    socket.on('online-users', onOnlineUsers)
    socket.on('chat-error', onChatError)

    if (socket.connected) onConnect()

    return () => {
      socket.off('connect', onConnect)
      socket.off('disconnect', onDisconnect)
      socket.off('connect_error', onConnectError)
      socket.off('message-history', onMessageHistory)
      socket.off('new-message', onNewMessage)
      socket.off('message-reaction', onMessageReaction)
      socket.off('user-typing', onUserTyping)
      socket.off('user-online', onUserOnline)
      socket.off('user-offline', onUserOffline)
      socket.off('online-users', onOnlineUsers)
      socket.off('chat-error', onChatError)
      // Try to leave the room
      socket.emit('leave-group', { groupId })
    }
  }, [status, user?.id, user?.name, groupId, toast])

  // Clean up stale typing indicators
  React.useEffect(() => {
    const id = setInterval(() => {
      setTypingUsers((prev) => {
        const now = Date.now()
        const next: typeof prev = {}
        let changed = false
        for (const [k, v] of Object.entries(prev)) {
          if (now - v.ts < 4000) {
            next[k] = v
          } else {
            changed = true
          }
        }
        return changed ? next : prev
      })
    }, 2000)
    return () => clearInterval(id)
  }, [])

  function emitTyping(isTyping: boolean) {
    if (!socketRef.current || !connected) return
    const now = Date.now()
    if (isTyping && now - lastTypingEmitRef.current < 1500) return
    lastTypingEmitRef.current = now
    socketRef.current.emit('typing', { groupId, isTyping })

    if (isTyping) {
      if (typingTimerRef.current) clearTimeout(typingTimerRef.current)
      typingTimerRef.current = setTimeout(() => {
        socketRef.current?.emit('typing', { groupId, isTyping: false })
      }, 3000)
    } else if (typingTimerRef.current) {
      clearTimeout(typingTimerRef.current)
    }
  }

  function handleSend() {
    const text = draft.trim()
    if (!text && !pendingFile) return
    if (!socketRef.current || !connected) return

    socketRef.current.emit(
      'send-message',
      {
        groupId,
        content: text || null,
        fileUrl: pendingFile?.url ?? null,
        fileType: pendingFile?.fileType ?? null,
        fileName: pendingFile?.fileName ?? null,
      },
      (ack: { ok?: boolean; error?: string } | undefined) => {
        if (!ack?.ok) {
          toast({
            title: 'خطا',
            description: 'ارسال پیام ناموفق بود',
            variant: 'destructive',
          })
        }
      },
    )

    setDraft('')
    setPendingFile(null)
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current)
    socketRef.current?.emit('typing', { groupId, isTyping: false })
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  function handleDraftChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setDraft(e.target.value)
    if (e.target.value.trim()) emitTyping(true)
    else emitTyping(false)
  }

  function handleReact(messageId: string, emoji: string) {
    if (!socketRef.current || !connected) return
    socketRef.current.emit('reaction', { messageId, emoji })
  }

  function handleFileUploaded(file: UploadedFile) {
    setPendingFile(file)
    toast({
      title: 'فایل آماده ارسال',
      description: file.fileName,
    })
  }

  function handleScrollToBottom() {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth',
      })
      setShowJump(false)
    }
  }

  function handleScrollCheck() {
    if (!scrollRef.current) return
    const el = scrollRef.current
    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 120
    if (nearBottom) setShowJump(false)
  }

  const typingNames = Object.values(typingUsers).map((u) => u.userName)
  const onlineCount = onlineUsers.length

  if (status === 'loading') {
    return (
      <div className="flex h-full min-h-[200px] items-center justify-center p-8">
        <Loader2 className="size-6 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (status !== 'authenticated' || !user) {
    return (
      <div className="flex h-full min-h-[200px] flex-col items-center justify-center gap-3 p-8 text-center">
        <AlertCircle className="size-10 text-muted-foreground" />
        <p className="text-sm text-muted-foreground">
          برای ورود به گفتگو ابتدا وارد حساب کاربری خود شوید.
        </p>
      </div>
    )
  }

  return (
    <div
      className={cn(
        'flex flex-col overflow-hidden rounded-2xl border bg-card shadow-sm',
        className,
      )}
      style={{ maxHeight }}
      dir="rtl"
    >
      {/* Header */}
      <div className="flex items-center justify-between gap-2 border-b bg-gradient-to-l from-primary/5 to-transparent px-4 py-3">
        <div className="flex items-center gap-2.5">
          <Avatar className="size-10 rounded-full bg-primary/10">
            <AvatarFallback className="bg-primary/10 text-primary">
              {title.slice(0, 1)}
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-col">
            <span className="text-sm font-semibold">{title}</span>
            <span className="text-[11px] text-muted-foreground flex items-center gap-1">
              <Users className="size-3" />
              {onlineCount} نفر آنلاین
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {connected ? (
            <span className="flex items-center gap-1 text-[11px] text-green-600 dark:text-green-400">
              <span className="size-2 rounded-full bg-green-500" />
              متصل
            </span>
          ) : (
            <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
              <Loader2 className="size-3 animate-spin" />
              در حال اتصال...
            </span>
          )}
        </div>
      </div>

      {/* Messages area */}
      <div className="relative flex-1 overflow-hidden">
        <div
          ref={scrollRef}
          onScroll={handleScrollCheck}
          className="custom-scroll absolute inset-0 overflow-y-auto px-3 py-4"
        >
          {error && (
            <div className="mx-auto mb-4 max-w-sm rounded-lg border border-destructive/30 bg-destructive/10 px-4 py-3 text-center text-sm text-destructive">
              {error}
            </div>
          )}
          {joining && messages.length === 0 && (
            <div className="flex items-center justify-center gap-2 p-8 text-sm text-muted-foreground">
              <Loader2 className="size-4 animate-spin" />
              در حال اتصال به گفتگو...
            </div>
          )}
          {!joining && messages.length === 0 && !error && (
            <div className="flex flex-col items-center justify-center gap-2 p-8 text-center text-sm text-muted-foreground">
              <Paperclip className="size-6 opacity-50" />
              <p>هنوز پیامی ارسال نشده است. اولین پیام را شما ارسال کنید!</p>
            </div>
          )}
          <AnimatePresence initial={false}>
            {messages.map((m, i) => {
              const prev = messages[i - 1]
              const showName =
                !prev || prev.senderId !== m.senderId
              return (
                <MessageBubble
                  key={m.id}
                  message={m}
                  isOwn={!!m.isOwn}
                  currentUserId={user.id}
                  onReact={handleReact}
                  showName={showName}
                  showAvatar={showName}
                />
              )
            })}
          </AnimatePresence>
          <TypingIndicator users={typingNames} className="mt-2 mb-2 ps-10" />
        </div>

        {/* Jump to bottom button */}
        {showJump && (
          <button
            type="button"
            onClick={handleScrollToBottom}
            className="absolute bottom-3 left-3 z-10 flex size-9 items-center justify-center rounded-full border bg-background shadow-md transition-colors hover:bg-accent"
            aria-label="رفتن به آخرین پیام"
          >
            <svg
              className="size-4"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2.5}
              strokeLinecap="round"
              strokeLinejoin="round"
              style={{ transform: 'scaleX(-1)' }}
            >
              <path d="M7 13l5 5 5-5M7 6l5 5 5-5" />
            </svg>
          </button>
        )}
      </div>

      {/* Input area */}
      <div className="border-t bg-card/80 p-3 backdrop-blur">
        {pendingFile && (
          <div className="mb-2 flex items-center gap-2 rounded-md border bg-muted/30 p-2">
            <ImagePlus className="size-4 shrink-0 text-primary" />
            <span className="flex-1 truncate text-xs">
              {pendingFile.fileName}
            </span>
            <button
              type="button"
              onClick={() => setPendingFile(null)}
              className="text-muted-foreground transition-colors hover:text-destructive"
              aria-label="حذف فایل"
            >
              <X className="size-4" />
            </button>
          </div>
        )}
        <div className="flex items-end gap-2">
          <FileUploadButton
            endpoint={uploadUrl}
            onUploaded={handleFileUploaded}
            onError={(m) =>
              toast({
                title: 'خطا',
                description: m,
                variant: 'destructive',
              })
            }
            disabled={!connected}
          />
          <Textarea
            value={draft}
            onChange={handleDraftChange}
            onKeyDown={handleKeyDown}
            placeholder="پیام خود را بنویسید... (Enter برای ارسال)"
            rows={1}
            className="custom-scroll max-h-32 min-h-[40px] flex-1 resize-none rounded-2xl bg-muted/30"
            disabled={!connected}
          />
          <Button
            type="button"
            size="icon"
            onClick={handleSend}
            disabled={(!draft.trim() && !pendingFile) || !connected}
            className="size-10 shrink-0 rounded-full"
            aria-label="ارسال پیام"
          >
            <Send className="size-4" style={{ transform: 'scaleX(-1)' }} />
          </Button>
        </div>
      </div>
    </div>
  )
}

export default GroupChat
