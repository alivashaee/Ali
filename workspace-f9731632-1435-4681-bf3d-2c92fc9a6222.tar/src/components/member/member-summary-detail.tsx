'use client'

import { useQuery } from '@tanstack/react-query'
import ReactMarkdown from 'react-markdown'
import { notFound, useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import {
  Download,
  FileText,
  FileAudio,
  Loader2,
  CheckCircle2,
  AlertCircle,
  ChevronRight,
} from 'lucide-react'
import Link from 'next/link'
import { formatJalaliDate } from '@/lib/format-jalali'

type Summary = {
  id: string
  audioUrl: string
  transcript: string | null
  summary: string | null
  status: string
  createdAt: string
  group: { id: string; name: string }
}

export function MemberSummaryDetail({ summaryId }: { summaryId: string }) {
  const { toast } = useToast()

  const { data, isLoading, error } = useQuery<{ summary: Summary }>({
    queryKey: ['member', 'summaries', summaryId],
    queryFn: async () => {
      const r = await fetch(`/api/member/summaries/${summaryId}`)
      if (r.status === 404) notFound()
      if (!r.ok) throw new Error('خطا در بارگذاری')
      return r.json()
    },
    retry: false,
  })

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-2">
        <Loader2 className="w-6 h-6 animate-spin" />
        <span className="text-sm">در حال بارگذاری...</span>
      </div>
    )
  }

  if (error || !data) {
    return (
      <Card className="border-destructive/40 bg-destructive/5">
        <CardContent className="py-8 flex flex-col items-center text-center gap-2">
          <AlertCircle className="w-8 h-8 text-destructive" />
          <h3 className="font-bold text-base">خطا در بارگذاری</h3>
          <p className="text-sm text-muted-foreground">
            امکان دسترسی به این خلاصه وجود ندارد. ممکن است گروه شما به این جلسه دسترسی نداشته باشید.
          </p>
          <Button asChild size="sm" variant="outline" className="rounded-full">
            <Link href="/member/summaries">بازگشت</Link>
          </Button>
        </CardContent>
      </Card>
    )
  }

  const summary = data.summary

  async function handleDownloadMarkdown() {
    try {
      // Members download via coach endpoint is not allowed; produce local file instead
      const blob = new Blob([buildMarkdown(summary)], { type: 'text/markdown;charset=utf-8' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `summary-${summaryId}.md`
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
    } catch (e: any) {
      toast({
        title: 'خطا',
        description: e.message,
        variant: 'destructive',
      })
    }
  }

  return (
    <div className="space-y-5">
      <nav className="flex items-center gap-1 text-sm text-muted-foreground">
        <Link href="/member" className="hover:text-primary transition-colors">پنل عضو</Link>
        <ChevronRight className="w-4 h-4" />
        <Link href="/member/summaries" className="hover:text-primary transition-colors">خلاصه‌ها</Link>
        <ChevronRight className="w-4 h-4" />
        <span className="text-foreground truncate">{summary.group.name}</span>
      </nav>

      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-primary">{summary.group.name}</h1>
          <p className="text-sm text-muted-foreground mt-1">
            خلاصه جلسه مورخ {formatJalaliDate(summary.createdAt, true)}
          </p>
          <div className="mt-2">
            <StatusBadge status={summary.status} />
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="rounded-full"
          onClick={handleDownloadMarkdown}
          disabled={summary.status !== 'completed'}
        >
          <Download className="w-4 h-4" />
          دانلود Markdown
        </Button>
      </div>

      <Card className="border-accent/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <FileAudio className="w-5 h-5 text-primary" />
            فایل صوتی جلسه
          </CardTitle>
          <CardDescription>پخش فایل اصلی جلسه</CardDescription>
        </CardHeader>
        <CardContent>
          <audio controls src={summary.audioUrl} className="w-full" />
        </CardContent>
      </Card>

      {summary.status === 'completed' && (
        <>
          {summary.summary && (
            <Card className="border-accent/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <FileText className="w-5 h-5 text-primary" />
                  خلاصه جلسه
                </CardTitle>
                <CardDescription>تولید شده توسط هوش مصنوعی</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none rtl:prose-headings:text-primary rtl:prose-headings:font-bold rtl:prose-strong:text-foreground">
                  <ReactMarkdown>{summary.summary}</ReactMarkdown>
                </div>
              </CardContent>
            </Card>
          )}

          {summary.transcript && (
            <Card className="border-accent/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <FileText className="w-5 h-5 text-primary" />
                  ترانسکریپت کامل
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="max-h-96 overflow-y-auto custom-scroll rounded-xl bg-muted/30 p-4">
                  <div className="prose prose-sm max-w-none whitespace-pre-wrap">
                    {summary.transcript}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  )
}

function buildMarkdown(summary: Summary): string {
  let md = `# ${summary.group.name} — خلاصه جلسه\n\n`
  md += `**تاریخ:** ${formatJalaliDate(summary.createdAt)}\n\n---\n\n`
  if (summary.summary) md += `## خلاصه\n\n${summary.summary}\n\n---\n\n`
  if (summary.transcript) md += `## ترانسکریپت کامل\n\n${summary.transcript}\n`
  return md
}

function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'completed':
      return (
        <Badge variant="outline" className="text-sprout border-sprout/40 bg-sprout/10">
          <CheckCircle2 className="w-3 h-3 ml-1" />
          تکمیل شده
        </Badge>
      )
    case 'failed':
      return (
        <Badge variant="outline" className="text-destructive border-destructive/40 bg-destructive/10">
          <AlertCircle className="w-3 h-3 ml-1" />
          ناموفق
        </Badge>
      )
    default:
      return null
  }
}
