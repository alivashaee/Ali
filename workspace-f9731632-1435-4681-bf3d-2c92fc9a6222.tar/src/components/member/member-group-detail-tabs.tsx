'use client'

import { useQuery } from '@tanstack/react-query'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { MessageCircle, FileAudio, Loader2, Clock, ChevronLeft } from 'lucide-react'
import { GroupChatLoader } from '@/components/coach/group-chat-loader'
import { formatJalaliDate } from '@/lib/format-jalali'

type Summary = {
  id: string
  audioUrl: string
  status: string
  createdAt: string
  summary: string | null
}

type Props = {
  groupId: string
  groupName: string
  defaultTab?: 'chat' | 'summaries'
}

export function MemberGroupDetailTabs({ groupId, groupName, defaultTab = 'chat' }: Props) {
  const { data, isLoading } = useQuery<{ summaries: Summary[] }>({
    queryKey: ['member', 'summaries', { groupId }],
    queryFn: async () => {
      const r = await fetch(`/api/member/summaries?groupId=${encodeURIComponent(groupId)}`)
      if (!r.ok) throw new Error('خطا در بارگذاری')
      return r.json()
    },
  })

  return (
    <Tabs defaultValue={defaultTab} dir="rtl" className="w-full">
      <TabsList className="bg-accent/15 p-1 h-auto rounded-2xl flex-wrap">
        <TabsTrigger value="chat" className="rounded-xl gap-1.5">
          <MessageCircle className="w-4 h-4" />
          چت گروهی
        </TabsTrigger>
        <TabsTrigger value="summaries" className="rounded-xl gap-1.5">
          <FileAudio className="w-4 h-4" />
          خلاصه جلسات
        </TabsTrigger>
      </TabsList>
      <TabsContent value="chat" className="mt-4">
        <GroupChatLoader groupId={groupId} />
      </TabsContent>
      <TabsContent value="summaries" className="mt-4">
        <div className="space-y-4">
          <div>
            <h3 className="font-bold text-base text-foreground">خلاصه جلسات</h3>
            <p className="text-xs text-muted-foreground mt-0.5">
              خلاصه‌های آماده شده از جلسات گروه «{groupName}».
            </p>
          </div>
          {isLoading ? (
            <div className="flex items-center justify-center py-8 text-muted-foreground">
              <Loader2 className="w-5 h-5 animate-spin ml-2" />
              در حال بارگذاری...
            </div>
          ) : !data?.summaries?.length ? (
            <Card className="border-dashed border-accent/30">
              <CardContent className="py-8 text-center text-sm text-muted-foreground">
                هنوز خلاصه‌ای برای این گروه آماده نشده است.
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {data.summaries.map((s) => (
                <Card key={s.id} className="border-accent/20">
                  <CardContent className="pt-4 pb-4 px-4 flex flex-col gap-2">
                    <div className="flex items-center justify-between gap-2">
                      <div className="text-sm font-medium">
                        {formatJalaliDate(s.createdAt, true)}
                      </div>
                      <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-sprout/15 text-sprout">
                        <Clock className="w-3 h-3" />
                        آماده
                      </span>
                    </div>
                    <audio controls src={s.audioUrl} className="w-full h-10" />
                    {s.summary && (
                      <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
                        {s.summary.replace(/[#*>`]/g, '').slice(0, 180)}
                      </p>
                    )}
                    <Button asChild size="sm" variant="outline" className="rounded-full self-end">
                      <Link href={`/member/summaries/${s.id}`}>
                        مشاهده کامل
                        <ChevronLeft className="w-4 h-4" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </TabsContent>
    </Tabs>
  )
}
