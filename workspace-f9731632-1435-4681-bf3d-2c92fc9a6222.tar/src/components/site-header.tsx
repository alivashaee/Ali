'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { Session } from 'next-auth'
import Link from 'next/link'
import { useSyncExternalStore, useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  Menu,
  X,
  LogOut,
  LayoutDashboard,
  User as UserIcon,
  Home,
  Info,
  BookOpen,
  Phone,
  ChevronLeft,
} from 'lucide-react'
import { signOut } from 'next-auth/react'

// Hydration-safe mount detection: false on server, true on client after mount.
// Using useSyncExternalStore avoids setState-in-effect lint error and
// prevents hydration mismatch.
function useMounted() {
  return useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  )
}

type Props = {
  session: Session | null
  logo?: string | null
  siteName?: string
}

export function SiteHeader({ session, logo, siteName }: Props) {
  const mounted = useMounted()
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const navLinks = [
    { href: '/#home', label: 'خانه', icon: Home },
    { href: '/#about', label: 'درباره ما', icon: Info },
    { href: '/#blog', label: 'وبلاگ', icon: BookOpen },
    { href: '/#contact', label: 'تماس', icon: Phone },
  ]

  const role = (session?.user as any)?.role as string | undefined
  const dashboardHref =
    role === 'SUPER_ADMIN'
      ? '/admin'
      : role === 'COACH'
        ? '/coach'
        : role === 'MEMBER'
          ? '/member'
          : '/login'

  const handleLogout = () => {
    setOpen(false)
    const origin = typeof window !== 'undefined' ? window.location.origin : '/'
    signOut({ callbackUrl: origin + '/', redirect: true })
  }

  // Computed header styles (no useTransform needed)
  const headerWidth = mounted && scrolled ? '92%' : '100%'
  const headerPadding = mounted && scrolled ? '0.5rem' : '1rem'

  return (
    <>
      <header
        style={{
          width: headerWidth,
          paddingTop: headerPadding,
          paddingBottom: headerPadding,
        }}
        className="fixed top-3 left-1/2 -translate-x-1/2 z-50 mx-auto bubble glass-strong transition-all duration-300"
      >
        <div className="flex items-center justify-between px-3 md:px-5 py-2 gap-2">
          {/* Logo + Name */}
          <Link href="/" className="flex items-center gap-2 shrink-0" onClick={() => setOpen(false)}>
            {logo ? (
              <img
                src={logo}
                alt={siteName || 'لوگو'}
                className="h-10 md:h-12 w-auto object-contain drop-shadow-md"
              />
            ) : (
              <div className="w-11 h-11 md:w-12 md:h-12 rounded-full bg-gradient-to-br from-primary to-accent" />
            )}
            <span className="hidden sm:block font-bold text-primary text-sm md:text-base">
              {siteName || 'رویش‌های پیشران'}
            </span>
          </Link>

          {/* Hamburger Menu Button - always visible */}
          <button
            className="rounded-full p-2.5 hover:bg-accent/20 transition-colors active:scale-95"
            onClick={() => setOpen(true)}
            aria-label="باز کردن منو"
          >
            <Menu className="w-6 h-6 text-primary" />
          </button>
        </div>
      </header>

      {/* Slide-in Drawer Menu */}
      <AnimatePresence>
        {open && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm"
              onClick={() => setOpen(false)}
            />

            {/* Drawer (slides from left since RTL) */}
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 280 }}
              className="fixed top-0 left-0 z-[70] h-full w-[85vw] max-w-sm glass-strong shadow-2xl flex flex-col"
              dir="rtl"
            >
              {/* Drawer Header */}
              <div className="flex items-center justify-between p-4 border-b border-border/40">
                <div className="flex items-center gap-2.5">
                  {logo ? (
                    <img src={logo} alt="لوگو" className="h-10 w-auto object-contain" />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent" />
                  )}
                  <span className="font-bold text-primary text-sm">{siteName || 'رویش‌های پیشران'}</span>
                </div>
                <button
                  className="rounded-full p-2 hover:bg-accent/20 transition-colors"
                  onClick={() => setOpen(false)}
                  aria-label="بستن منو"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* User Info (if logged in) */}
              {session?.user && (
                <div className="p-4 border-b border-border/40 bg-accent/5">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-12 h-12 ring-2 ring-accent/40">
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {session.user.name?.charAt(0) || 'م'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold text-sm truncate">{session.user.name}</div>
                      <div className="text-xs text-muted-foreground">{roleLabel(role)}</div>
                    </div>
                  </div>
                </div>
              )}

              {/* Nav Links */}
              <nav className="flex-1 overflow-y-auto custom-scroll p-3 space-y-1">
                {navLinks.map((link) => {
                  const Icon = link.icon
                  return (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-medium hover:bg-accent/20 transition-colors text-foreground/90"
                    >
                      <Icon className="w-5 h-5 text-primary shrink-0" />
                      <span className="flex-1">{link.label}</span>
                      <ChevronLeft className="w-4 h-4 text-muted-foreground" />
                    </Link>
                  )
                })}

                {/* Divider */}
                <div className="h-px bg-border/40 my-3" />

                {/* Auth Links */}
                {session?.user ? (
                  <>
                    <Link
                      href={dashboardHref}
                      onClick={() => setOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-medium hover:bg-accent/20 transition-colors text-foreground/90"
                    >
                      <LayoutDashboard className="w-5 h-5 text-primary shrink-0" />
                      <span className="flex-1">پیشخان</span>
                      <ChevronLeft className="w-4 h-4 text-muted-foreground" />
                    </Link>
                    <Link
                      href="/profile"
                      onClick={() => setOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-medium hover:bg-accent/20 transition-colors text-foreground/90"
                    >
                      <UserIcon className="w-5 h-5 text-primary shrink-0" />
                      <span className="flex-1">پروفایل</span>
                      <ChevronLeft className="w-4 h-4 text-muted-foreground" />
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-medium hover:bg-destructive/10 transition-colors text-destructive"
                    >
                      <LogOut className="w-5 h-5 shrink-0" />
                      <span className="flex-1 text-right">خروج از حساب</span>
                    </button>
                  </>
                ) : (
                  <div className="p-3">
                    <Button asChild className="w-full rounded-full" size="lg">
                      <Link href="/login" onClick={() => setOpen(false)}>
                        ورود به حساب
                      </Link>
                    </Button>
                  </div>
                )}
              </nav>

              {/* Footer */}
              <div className="p-4 border-t border-border/40 text-center text-xs text-muted-foreground">
                © {new Date().getFullYear()} {siteName || 'موسسه رویش‌های پیشران'}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}

function roleLabel(role?: string) {
  switch (role) {
    case 'SUPER_ADMIN':
      return 'مدیر اصلی'
    case 'COACH':
      return 'مربی'
    case 'MEMBER':
      return 'عضو'
    default:
      return 'کاربر'
  }
}
