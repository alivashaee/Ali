'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'
import { LayoutDashboard, FileText, BarChart3, type LucideIcon } from 'lucide-react'

export type SidebarLink = {
  href: string
  label: string
  icon: LucideIcon
  exact?: boolean
}

type Props = {
  links: SidebarLink[]
  title: string
  subtitle?: string
  /** For super_admin — link to /admin */
  adminLink?: boolean
}

export function PanelSidebar({ links, title, subtitle, adminLink }: Props) {
  const pathname = usePathname()

  const isActive = (link: SidebarLink) => {
    if (link.exact) return pathname === link.href
    return pathname === link.href || pathname.startsWith(link.href + '/')
  }

  return (
    <aside className="w-full md:w-64 md:shrink-0">
      <div className="md:sticky md:top-24 glass rounded-2xl p-4 md:p-5 flex flex-col gap-1.5">
        <div className="px-2 pb-3 mb-1 border-b border-border/40">
          <h2 className="font-bold text-primary text-base leading-tight">{title}</h2>
          {subtitle && (
            <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
          )}
        </div>
        <nav className="flex flex-col gap-1">
          {links.map((link) => {
            const Icon = link.icon
            const active = isActive(link)
            return (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  'relative flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors',
                  active
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-foreground/80 hover:bg-accent/30'
                )}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{link.label}</span>
                {active && (
                  <motion.span
                    layoutId="sidebar-active-indicator"
                    className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-1 rounded-full bg-accent"
                    transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                  />
                )}
              </Link>
            )
          })}
        </nav>
        {adminLink && (
          <Link
            href="/admin"
            className="mt-2 flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium text-foreground/80 hover:bg-accent/30 transition-colors border-t border-border/40 pt-3"
          >
            <LayoutDashboard className="w-4 h-4 shrink-0" />
            <span>پنل مدیریت</span>
          </Link>
        )}
      </div>
    </aside>
  )
}

export const coachNavLinks: SidebarLink[] = [
  { href: '/coach', label: 'داشبورد', icon: LayoutDashboard, exact: true },
  { href: '/coach/polls', label: 'نظرسنجی‌ها', icon: BarChart3 },
  { href: '/coach/summaries', label: 'خلاصه جلسات', icon: FileText },
]

export const memberNavLinks: SidebarLink[] = [
  { href: '/member', label: 'داشبورد', icon: LayoutDashboard, exact: true },
  { href: '/member/polls', label: 'نظرسنجی‌ها', icon: BarChart3 },
  { href: '/member/summaries', label: 'خلاصه جلسات', icon: FileText },
]
