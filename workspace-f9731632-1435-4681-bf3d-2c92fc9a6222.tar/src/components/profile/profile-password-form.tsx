'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { useToast } from '@/hooks/use-toast'
import { Loader2, Lock, Eye, EyeOff, KeyRound } from 'lucide-react'

export function ProfilePasswordForm() {
  const { toast } = useToast()
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showCurrent, setShowCurrent] = useState(false)
  const [showNew, setShowNew] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    if (newPassword.length < 6) {
      setError('رمز جدید باید حداقل ۶ کاراکتر باشد')
      return
    }
    if (newPassword !== confirmPassword) {
      setError('رمز جدید و تکرار آن مطابقت ندارند')
      return
    }
    if (newPassword === currentPassword) {
      setError('رمز جدید نباید با رمز فعلی یکسان باشد')
      return
    }

    setLoading(true)
    try {
      const res = await fetch('/api/profile/password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentPassword,
          newPassword,
          confirmPassword,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'خطا در تغییر رمز')
      toast({
        title: 'رمز عبور با موفقیت تغییر کرد ✅',
        description: 'لطفاً دفعه بعد با رمز جدید وارد شوید.',
      })
      setCurrentPassword('')
      setNewPassword('')
      setConfirmPassword('')
    } catch (e: any) {
      setError(e.message || 'خطایی رخ داد')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <PasswordField
        id="current"
        label="رمز عبور فعلی"
        value={currentPassword}
        onChange={setCurrentPassword}
        show={showCurrent}
        onToggleShow={() => setShowCurrent((v) => !v)}
        disabled={loading}
      />
      <PasswordField
        id="new"
        label="رمز عبور جدید"
        value={newPassword}
        onChange={setNewPassword}
        show={showNew}
        onToggleShow={() => setShowNew((v) => !v)}
        disabled={loading}
        hint="حداقل ۶ کاراکتر"
      />
      <PasswordField
        id="confirm"
        label="تکرار رمز عبور جدید"
        value={confirmPassword}
        onChange={setConfirmPassword}
        show={showConfirm}
        onToggleShow={() => setShowConfirm((v) => !v)}
        disabled={loading}
      />

      <Button
        type="submit"
        className="rounded-full w-full sm:w-auto"
        disabled={loading || !currentPassword || !newPassword || !confirmPassword}
      >
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            در حال تغییر...
          </>
        ) : (
          <>
            <KeyRound className="w-4 h-4" />
            تغییر رمز عبور
          </>
        )}
      </Button>
    </form>
  )
}

function PasswordField({
  id,
  label,
  value,
  onChange,
  show,
  onToggleShow,
  disabled,
  hint,
}: {
  id: string
  label: string
  value: string
  onChange: (v: string) => void
  show: boolean
  onToggleShow: () => void
  disabled?: boolean
  hint?: string
}) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id} className="flex items-center gap-1.5">
        <Lock className="w-3.5 h-3.5" />
        {label}
      </Label>
      <div className="relative">
        <Input
          id={id}
          type={show ? 'text' : 'password'}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          dir="ltr"
          className="text-left pl-9"
          autoComplete={id === 'current' ? 'current-password' : 'new-password'}
          required
        />
        <button
          type="button"
          onClick={onToggleShow}
          className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1"
          aria-label={show ? 'مخفی کردن' : 'نمایش'}
        >
          {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        </button>
      </div>
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  )
}
