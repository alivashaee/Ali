'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useEffect, useState } from 'react'
import Image from 'next/image'

export function SplashScreen() {
  // Always start visible on both server and client to avoid hydration mismatch.
  const [visible, setVisible] = useState(true)

  useEffect(() => {
    let seen = false
    try {
      seen = sessionStorage.getItem('splash-seen') === '1'
    } catch {
      seen = false
    }

    if (seen) {
      // Already seen - hide via rAF to avoid setState-in-effect lint error
      const raf = requestAnimationFrame(() => setVisible(false))
      return () => cancelAnimationFrame(raf)
    }

    // Not seen - show splash for 2.7s, then hide
    const timer = setTimeout(() => {
      setVisible(false)
      try {
        sessionStorage.setItem('splash-seen', '1')
      } catch {
        // ignore
      }
    }, 2700)

    return () => clearTimeout(timer)
  }, [])

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="splash-overlay flex flex-col items-center justify-center"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: 'easeInOut' }}
        >
          <motion.div
            initial={{ rotate: 0, scale: 0.8, opacity: 0 }}
            animate={{
              rotate: 360,
              scale: 1,
              opacity: 1,
            }}
            transition={{
              rotate: { duration: 1.5, ease: 'easeInOut' },
              scale: { duration: 0.6, ease: 'easeOut' },
              opacity: { duration: 0.4 },
            }}
            className="relative w-48 h-32 md:w-64 md:h-44"
          >
            <Image
              src="/institute-logo-final.png"
              alt="لوگوی موسسه رویش‌های پیشران"
              fill
              className="object-contain drop-shadow-2xl"
              priority
              sizes="(max-width: 768px) 192px, 256px"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.6 }}
            className="mt-8 text-center"
          >
            <h1 className="text-2xl md:text-3xl font-bold text-primary">
              رویش‌های پیشران
            </h1>
            <p className="mt-2 text-sm md:text-base text-muted-foreground">
              فضایی برای رویش نوجوانان در سایه آموزه‌های دینی
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.8, duration: 0.4 }}
            className="mt-6 flex gap-1.5"
          >
            {[0, 1, 2].map((i) => (
              <motion.span
                key={i}
                className="w-2 h-2 rounded-full bg-primary/60"
                animate={{ scale: [1, 1.4, 1], opacity: [0.5, 1, 0.5] }}
                transition={{
                  duration: 1,
                  repeat: Infinity,
                  delay: i * 0.2,
                }}
              />
            ))}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
