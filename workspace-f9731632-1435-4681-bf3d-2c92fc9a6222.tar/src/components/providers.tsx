'use client'

import { SessionProvider } from 'next-auth/react'
import { ReactNode, useState, useEffect } from 'react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Toaster } from '@/components/ui/sonner'
import { toast as sonnerToast } from 'sonner'

export function Providers({ children }: { children: ReactNode }) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 30 * 1000, // 30s
            retry: 1,
            refetchOnWindowFocus: false,
          },
        },
      })
  )

  // Expose sonner's toast globally for debugging
  useEffect(() => {
    if (typeof window !== 'undefined') {
      ;(window as any).sonnerToast = sonnerToast
    }
  }, [])

  return (
    <SessionProvider>
      <QueryClientProvider client={queryClient}>
        {children}
        <Toaster position="top-center" richColors closeButton dir="rtl" />
      </QueryClientProvider>
    </SessionProvider>
  )
}
