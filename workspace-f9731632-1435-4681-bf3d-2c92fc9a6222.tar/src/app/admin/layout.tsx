import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { getSiteSettings } from '@/lib/site-settings'
import { SiteHeader } from '@/components/site-header'
import {
  AdminSidebar,
  AdminMobileNav,
} from '@/components/admin/admin-sidebar'

export const dynamic = 'force-dynamic'

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect('/login?callbackUrl=/admin')
  }

  const role = (session.user as any).role
  if (role !== 'SUPER_ADMIN') {
    // Send non-admins to their own dashboard
    const target = role === 'COACH' ? '/coach' : '/member'
    redirect(target)
  }

  const [settings, fullUser] = await Promise.all([
    getSiteSettings(),
    db.user.findUnique({
      where: { id: (session.user as any).id },
      select: { name: true, username: true, role: true, avatar: true },
    }),
  ])

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader
        session={session}
        logo={settings.logo}
        siteName={settings.siteName}
      />
      <AdminSidebar />
      <main className="flex-1 pt-20 md:pr-60">
        <div className="container mx-auto px-4 py-6 max-w-6xl">
          <AdminMobileNav />
          {children}
        </div>
      </main>
    </div>
  )
}
