import { db } from '@/lib/db'
import { UsersClient } from './users-client'

export const dynamic = 'force-dynamic'

export default async function AdminUsersPage() {
  const users = await db.user.findMany({
    orderBy: { createdAt: 'desc' },
    take: 100,
    select: {
      id: true,
      name: true,
      username: true,
      email: true,
      phone: true,
      role: true,
      avatar: true,
      blocked: true,
      createdAt: true,
    },
  })

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-primary">مدیریت کاربران</h1>
        <p className="text-sm text-muted-foreground mt-1">
          اضافه کردن، ویرایش نقش، مسدودسازی و حذف کاربران سامانه
        </p>
      </div>
      <UsersClient users={users} />
    </div>
  )
}
