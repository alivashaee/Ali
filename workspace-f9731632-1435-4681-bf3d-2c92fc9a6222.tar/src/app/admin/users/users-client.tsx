'use client'

import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Switch } from '@/components/ui/switch'
import { useToast } from '@/hooks/use-toast'
import {
  UserPlus,
  Search,
  Edit,
  Trash2,
  Ban,
  CheckCircle,
  KeyRound,
  Loader2,
} from 'lucide-react'

type Role = 'SUPER_ADMIN' | 'COACH' | 'MEMBER'

type User = {
  id: string
  name: string
  username: string | null
  email: string | null
  phone: string | null
  role: Role
  avatar: string | null
  blocked: boolean
  createdAt: string
}

export function UsersClient({ users: initial }: { users: User[] }) {
  const router = useRouter()
  const { toast } = useToast()
  const [users, setUsers] = useState(initial)
  const [search, setSearch] = useState('')
  const [createOpen, setCreateOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [editOpen, setEditOpen] = useState(false)
  const [busy, setBusy] = useState(false)

  const filtered = users.filter((u) => {
    const s = search.trim().toLowerCase()
    if (!s) return true
    return (
      u.name?.toLowerCase().includes(s) ||
      u.username?.toLowerCase().includes(s) ||
      u.email?.toLowerCase().includes(s) ||
      u.phone?.toLowerCase().includes(s)
    )
  })

  async function refresh() {
    router.refresh()
    const res = await fetch('/api/admin/users?pageSize=100', { cache: 'no-store' })
    if (res.ok) {
      const data = await res.json()
      setUsers(data.items)
    }
  }

  async function toggleBlock(user: User) {
    setBusy(true)
    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ blocked: !user.blocked }),
      })
      if (!res.ok) throw new Error('خطا')
      toast({
        title: user.blocked ? 'کاربر رفع مسدودیت شد' : 'کاربر مسدود شد',
      })
      await refresh()
    } catch {
      toast({ title: 'خطا', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function deleteUser(user: User) {
    setBusy(true)
    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: 'DELETE',
      })
      if (!res.ok) throw new Error('خطا')
      toast({ title: 'کاربر حذف شد' })
      await refresh()
    } catch {
      toast({ title: 'خطا در حذف', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="relative w-full sm:max-w-xs">
          <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="جستجو بر اساس نام، کاربری، موبایل، ایمیل..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-9"
          />
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="w-4 h-4 ml-2" />
              افزودن کاربر
            </Button>
          </DialogTrigger>
          <CreateUserDialog
            onClose={() => setCreateOpen(false)}
            onCreated={refresh}
          />
        </Dialog>
      </div>

      <Card className="border-accent/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">فهرست کاربران</CardTitle>
          <CardDescription>
            مجموعاً {users.length.toLocaleString('fa-IR')} کاربر ثبت شده است
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto custom-scroll">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">نام</TableHead>
                  <TableHead className="text-right">نام کاربری</TableHead>
                  <TableHead className="text-right">نقش</TableHead>
                  <TableHead className="text-right">وضعیت</TableHead>
                  <TableHead className="text-right">تاریخ عضویت</TableHead>
                  <TableHead className="text-center">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.length === 0 && (
                  <TableRow>
                    <TableCell
                      colSpan={6}
                      className="text-center text-muted-foreground py-6"
                    >
                      کاربری یافت نشد
                    </TableCell>
                  </TableRow>
                )}
                {filtered.map((u) => (
                  <TableRow key={u.id}>
                    <TableCell className="font-medium">{u.name}</TableCell>
                    <TableCell dir="ltr" className="text-right text-sm">
                      {u.username || u.phone || '—'}
                    </TableCell>
                    <TableCell>
                      <RoleBadge role={u.role} />
                    </TableCell>
                    <TableCell>
                      {u.blocked ? (
                        <Badge variant="destructive" className="text-xs">
                          مسدود
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-xs">
                          فعال
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(u.createdAt).toLocaleDateString('fa-IR')}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => {
                            setEditingUser(u)
                            setEditOpen(true)
                          }}
                          title="ویرایش"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => toggleBlock(u)}
                          disabled={busy}
                          title={u.blocked ? 'رفع مسدودیت' : 'مسدودسازی'}
                          className={
                            u.blocked ? 'text-sprout' : 'text-destructive'
                          }
                        >
                          {u.blocked ? (
                            <CheckCircle className="w-4 h-4" />
                          ) : (
                            <Ban className="w-4 h-4" />
                          )}
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="text-destructive"
                              title="حذف"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>
                                حذف کاربر؟
                              </AlertDialogTitle>
                              <AlertDialogDescription>
                                آیا از حذف کاربر «{u.name}» مطمئن هستید؟ این
                                عمل برگشت‌پذیر نیست.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>انصراف</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => deleteUser(u)}
                                className="bg-destructive text-white hover:bg-destructive/90"
                              >
                                حذف
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <EditUserDialog
        user={editingUser}
        open={editOpen}
        onOpenChange={(o) => {
          setEditOpen(o)
          if (!o) setEditingUser(null)
        }}
        onUpdated={refresh}
      />
    </div>
  )
}

function RoleBadge({ role }: { role: Role }) {
  const map: Record<Role, { label: string; variant: any }> = {
    SUPER_ADMIN: { label: 'مدیر اصلی', variant: 'default' },
    COACH: { label: 'مربی', variant: 'secondary' },
    MEMBER: { label: 'عضو', variant: 'outline' },
  }
  const cfg = map[role]
  return (
    <Badge variant={cfg.variant} className="text-xs">
      {cfg.label}
    </Badge>
  )
}

function CreateUserDialog({
  onClose,
  onCreated,
}: {
  onClose: () => void
  onCreated: () => void
}) {
  const { toast } = useToast()
  const [name, setName] = useState('')
  const [username, setUsername] = useState('')
  const [phone, setPhone] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState<Role>('MEMBER')
  const [loading, setLoading] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!name || !password) {
      toast({ title: 'نام و رمز عبور الزامی است', variant: 'destructive' })
      return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          username: username || undefined,
          phone: phone || undefined,
          email: email || undefined,
          password,
          role,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'خطا')
      toast({ title: 'کاربر ایجاد شد' })
      setName('')
      setUsername('')
      setPhone('')
      setEmail('')
      setPassword('')
      setRole('MEMBER')
      onCreated()
      onClose()
    } catch (e: any) {
      toast({
        title: 'خطا',
        description: e?.message,
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <DialogContent className="max-w-md">
      <DialogHeader>
        <DialogTitle>افزودن کاربر جدید</DialogTitle>
        <DialogDescription>
          اطلاعات کاربر را وارد کنید. رمز عبور به‌صورت امن هش خواهد شد.
        </DialogDescription>
      </DialogHeader>
      <form onSubmit={submit} className="space-y-3">
        <div>
          <Label htmlFor="cu-name">نام کامل *</Label>
          <Input
            id="cu-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            placeholder="نام و نام خانوادگی"
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="cu-username">نام کاربری</Label>
            <Input
              id="cu-username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              dir="ltr"
              className="text-right"
              placeholder="username"
            />
          </div>
          <div>
            <Label htmlFor="cu-phone">شماره موبایل</Label>
            <Input
              id="cu-phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              dir="ltr"
              className="text-right"
              placeholder="0912..."
            />
          </div>
        </div>
        <div>
          <Label htmlFor="cu-email">ایمیل</Label>
          <Input
            id="cu-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            dir="ltr"
            className="text-right"
            placeholder="user@example.com"
          />
        </div>
        <div>
          <Label htmlFor="cu-password">رمز عبور *</Label>
          <Input
            id="cu-password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            dir="ltr"
            className="text-right"
            placeholder="حداقل ۴ کاراکتر"
          />
        </div>
        <div>
          <Label>نقش</Label>
          <Select value={role} onValueChange={(v) => setRole(v as Role)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="MEMBER">عضو</SelectItem>
              <SelectItem value="COACH">مربی</SelectItem>
              <SelectItem value="SUPER_ADMIN">مدیر اصلی</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <DialogFooter>
          <Button type="button" variant="ghost" onClick={onClose}>
            انصراف
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? (
              <Loader2 className="w-4 h-4 ml-2 animate-spin" />
            ) : (
              <UserPlus className="w-4 h-4 ml-2" />
            )}
            افزودن کاربر
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  )
}

function EditUserDialog({
  user,
  open,
  onOpenChange,
  onUpdated,
}: {
  user: User | null
  open: boolean
  onOpenChange: (o: boolean) => void
  onUpdated: () => void
}) {
  const { toast } = useToast()
  const [name, setName] = useState('')
  const [role, setRole] = useState<Role>('MEMBER')
  const [blocked, setBlocked] = useState(false)
  const [newPassword, setNewPassword] = useState('')
  const [loading, setLoading] = useState(false)

  // Sync state when user changes
  const lastUserIdRef = useRef<string | null>(null)
  if (user && user.id !== lastUserIdRef.current) {
    lastUserIdRef.current = user.id
    setName(user.name)
    setRole(user.role)
    setBlocked(user.blocked)
    setNewPassword('')
  }
  if (!user && lastUserIdRef.current !== null) {
    lastUserIdRef.current = null
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!user) return
    setLoading(true)
    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          role,
          blocked,
          newPassword: newPassword || undefined,
        }),
      })
      if (!res.ok) throw new Error('خطا')
      toast({ title: 'به‌روزرسانی شد' })
      setNewPassword('')
      onUpdated()
      onOpenChange(false)
    } catch {
      toast({ title: 'خطا', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  if (!user) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>ویرایش کاربر</DialogTitle>
          <DialogDescription>
            {user.username || user.phone || '—'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div>
            <Label htmlFor="eu-name">نام کامل</Label>
            <Input
              id="eu-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div>
            <Label>نقش</Label>
            <Select value={role} onValueChange={(v) => setRole(v as Role)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="MEMBER">عضو</SelectItem>
                <SelectItem value="COACH">مربی</SelectItem>
                <SelectItem value="SUPER_ADMIN">مدیر اصلی</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <div className="text-sm font-medium">مسدودسازی کاربر</div>
              <div className="text-xs text-muted-foreground">
                کاربر مسدود شده نمی‌تواند وارد شود
              </div>
            </div>
            <Switch checked={blocked} onCheckedChange={setBlocked} />
          </div>
          <div>
            <Label htmlFor="eu-pw" className="flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5" />
              بازنشانی رمز عبور (اختیاری)
            </Label>
            <Input
              id="eu-pw"
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              dir="ltr"
              className="text-right"
              placeholder="خالی بگذارید اگر نمی‌خواهید تغییر کند"
            />
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="ghost"
              onClick={() => onOpenChange(false)}
            >
              انصراف
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="w-4 h-4 ml-2 animate-spin" />}
              ذخیره تغییرات
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
