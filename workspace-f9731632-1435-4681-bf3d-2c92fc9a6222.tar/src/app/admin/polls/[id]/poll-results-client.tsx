'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts'
import {
  Download,
  Share2,
  ExternalLink,
  Trash2,
  Edit,
  Loader2,
  Users,
  ListChecks,
  FileText,
} from 'lucide-react'

type PollResults = {
  id: string
  title: string
  description: string | null
  buttonColor: string
  buttonShape: string
  buttonText: string
  background: string | null
  isPublic: boolean
  shareToken: string | null
  createdAt: string
  creatorName: string | null
  total: number
  pollType?: string
  descriptiveResponses?: Array<{
    id: string
    text: string | null
    fileUrl: string | null
    fileName: string | null
    fileType: string | null
    createdAt: string
    user: string
  }>
  allowFileUpload?: boolean
  fileUploadLabel?: string | null
  allFiles?: Array<{
    id: string
    url: string | null
    name: string | null
    type: string | null
    createdAt: string
    user: string
    optionText: string
  }>
  options: {
    id: string
    text: string
    imageUrl: string | null
    count: number
    percent: number
  }[]
}

const CHART_COLORS = [
  '#1f5130',
  '#c79e3d',
  '#335c8a',
  '#a55b3d',
  '#5da9a8',
  '#7c5b8c',
  '#4a7c4e',
  '#b87333',
]

export function PollResultsClient({ poll }: { poll: PollResults }) {
  const { toast } = useToast()
  const [busy, setBusy] = useState(false)
  const [shareUrl, setShareUrl] = useState<string | null>(
    poll.shareToken ? `/polls/${poll.shareToken}` : null
  )
  const [loading, setLoading] = useState(false)

  async function ensureShare() {
    setBusy(true)
    try {
      const res = await fetch(`/api/admin/polls/${poll.id}/share`, {
        method: 'POST',
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setShareUrl(data.url)
      toast({ title: 'لینک اشتراک ساخته شد' })
    } catch {
      toast({ title: 'خطا', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  async function downloadCsv() {
    setLoading(true)
    try {
      const res = await fetch(`/api/admin/polls/${poll.id}/csv`)
      if (!res.ok) throw new Error('خطا')
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `نظرسنجی-${poll.title}.csv`
      a.click()
      URL.revokeObjectURL(url)
    } catch {
      toast({ title: 'خطا در دانلود', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const barData = poll.options.map((o, i) => ({
    name: o.text.length > 18 ? o.text.slice(0, 18) + '…' : o.text,
    fullName: o.text,
    آراء: o.count,
    fill: CHART_COLORS[i % CHART_COLORS.length],
  }))

  const pieData = poll.options.map((o, i) => ({
    name: o.text,
    value: o.count,
    fill: CHART_COLORS[i % CHART_COLORS.length],
  }))

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Button onClick={downloadCsv} variant="outline" size="sm" disabled={loading}>
          {loading ? (
            <Loader2 className="w-4 h-4 ml-2 animate-spin" />
          ) : (
            <Download className="w-4 h-4 ml-2" />
          )}
          خروجی CSV
        </Button>
        {shareUrl ? (
          <>
            <Button asChild size="sm" variant="outline">
              <Link href={shareUrl} target="_blank">
                <ExternalLink className="w-4 h-4 ml-2" />
                باز کردن صفحه عمومی
              </Link>
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={async () => {
                try {
                  const full = `${window.location.origin}${shareUrl}`
                  await navigator.clipboard.writeText(full)
                  toast({ title: 'لینک کپی شد' })
                } catch {
                  toast({ title: 'کپی ناموفق بود', variant: 'destructive' })
                }
              }}
            >
              <Share2 className="w-4 h-4 ml-2" />
              کپی لینک
            </Button>
          </>
        ) : (
          <Button onClick={ensureShare} size="sm" disabled={busy}>
            {busy ? (
              <Loader2 className="w-4 h-4 ml-2 animate-spin" />
            ) : (
              <Share2 className="w-4 h-4 ml-2" />
            )}
            ایجاد لینک اشتراک
          </Button>
        )}
        {poll.shareToken ? null : null}
      </div>

      {/* Stats summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Card className="border-accent/20">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-primary" />
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">
                {poll.total.toLocaleString('fa-IR')}
              </div>
              <div className="text-xs text-muted-foreground">کل پاسخ‌ها</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-accent/20">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-sprout/15 flex items-center justify-center">
              <ListChecks className="w-5 h-5 text-sprout" />
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">
                {poll.options.length.toLocaleString('fa-IR')}
              </div>
              <div className="text-xs text-muted-foreground">گزینه‌ها</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-accent/20">
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground mb-1">پررنگ‌ترین گزینه</div>
            <div className="font-bold text-foreground text-sm">
              {poll.options.length
                ? poll.options.reduce((a, b) =>
                    a.count >= b.count ? a : b
                  ).text
                : '—'}
            </div>
          </CardContent>
        </Card>
        <Card className="border-accent/20">
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground mb-1">تاریخ ایجاد</div>
            <div className="font-bold text-foreground text-sm">
              {new Date(poll.createdAt).toLocaleDateString('fa-IR')}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="border-accent/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">نمودار میله‌ای</CardTitle>
            <CardDescription>تعداد آراء هر گزینه</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={barData}
                  layout="vertical"
                  margin={{ left: 16, right: 16, top: 8, bottom: 8 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="var(--border)"
                  />
                  <XAxis
                    type="number"
                    tick={{ fontSize: 11, fontFamily: 'Vazirmatn' }}
                    stroke="var(--muted-foreground)"
                  />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={120}
                    tick={{ fontSize: 11, fontFamily: 'Vazirmatn' }}
                    stroke="var(--muted-foreground)"
                  />
                  <Tooltip
                    contentStyle={{
                      fontFamily: 'Vazirmatn',
                      fontSize: 12,
                      borderRadius: 8,
                      border: '1px solid var(--border)',
                    }}
                    formatter={(value: any, _name, props) => [
                      `${value} (${(
                        (value / Math.max(poll.total, 1)) *
                        100
                      ).toFixed(0)}%)`,
                      props?.payload?.fullName || 'آراء',
                    ]}
                  />
                  <Bar dataKey="آراء" radius={[0, 6, 6, 0]}>
                    {barData.map((entry, idx) => (
                      <Cell key={idx} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="border-accent/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">نمودار دایره‌ای</CardTitle>
            <CardDescription>سهم هر گزینه از کل</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    outerRadius={90}
                    innerRadius={45}
                    label={({ name, percent }) =>
                      `${name.slice(0, 12)}${
                        name.length > 12 ? '…' : ''
                      }: ${(percent ? percent * 100 : 0).toFixed(0)}%`
                    }
                    labelLine={false}
                    isAnimationActive={false}
                  >
                    {pieData.map((entry, idx) => (
                      <Cell key={idx} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      fontFamily: 'Vazirmatn',
                      fontSize: 12,
                      borderRadius: 8,
                      border: '1px solid var(--border)',
                    }}
                  />
                  <Legend
                    wrapperStyle={{
                      fontFamily: 'Vazirmatn',
                      fontSize: 11,
                      maxHeight: 60,
                      overflow: 'auto',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Options list */}
      <Card className="border-accent/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">جزئیات گزینه‌ها</CardTitle>
          <CardDescription>
            تفکیک آراء به تفکیک هر گزینه
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {poll.options.map((opt, idx) => (
            <div key={opt.id} className="space-y-1">
              <div className="flex items-center justify-between gap-2 text-sm">
                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className="w-3 h-3 rounded-full shrink-0"
                    style={{
                      backgroundColor: CHART_COLORS[idx % CHART_COLORS.length],
                    }}
                  />
                  {opt.imageUrl && (
                    <img
                      src={opt.imageUrl}
                      alt=""
                      className="w-7 h-7 rounded object-cover shrink-0"
                    />
                  )}
                  <span className="font-medium truncate">{opt.text}</span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Badge variant="outline" className="text-xs">
                    {opt.count.toLocaleString('fa-IR')} ({opt.percent}٪)
                  </Badge>
                </div>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full transition-all"
                  style={{
                    width: `${opt.percent}%`,
                    backgroundColor: CHART_COLORS[idx % CHART_COLORS.length],
                  }}
                />
              </div>
            </div>
          ))}
          {poll.options.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-4">
              گزینه‌ای وجود ندارد
            </p>
          )}
        </CardContent>
      </Card>

      {/* پاسخ‌های تشریحی (متن آزاد) */}
      {poll.pollType === 'descriptive' && (
        <Card className="border-accent/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="w-4 h-4" />
              پاسخ‌های تشریحی
            </CardTitle>
            <CardDescription>
              {poll.descriptiveResponses?.length || 0} پاسخ ثبت شده
            </CardDescription>
          </CardHeader>
          <CardContent>
            {poll.descriptiveResponses && poll.descriptiveResponses.length > 0 ? (
              <div className="space-y-3">
                {poll.descriptiveResponses.map((resp) => {
                  const isImage = resp.fileType?.startsWith('image/') || /\.(jpg|jpeg|png|gif|webp)$/i.test(resp.fileName || '')
                  return (
                    <div
                      key={resp.id}
                      className="rounded-lg border border-border/60 p-3 bg-card/50 space-y-2"
                    >
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span className="font-medium text-foreground/80">
                          {resp.user}
                        </span>
                        <span>{new Date(resp.createdAt).toLocaleDateString('fa-IR')}</span>
                      </div>
                      {resp.text && (
                        <div className="text-sm leading-relaxed whitespace-pre-wrap p-2 rounded bg-muted/30">
                          {resp.text}
                        </div>
                      )}
                      {resp.fileUrl && (
                        <div className="mt-2">
                          {isImage ? (
                            <a
                              href={resp.fileUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="block max-w-xs"
                            >
                              <img
                                src={resp.fileUrl}
                                alt={resp.fileName || 'فایل'}
                                className="w-full max-h-48 object-cover rounded-lg border border-border/40"
                              />
                            </a>
                          ) : (
                            <a
                              href={resp.fileUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-2 text-sm text-primary hover:underline"
                            >
                              <FileText className="w-4 h-4" />
                              {resp.fileName || 'دانلود فایل'}
                            </a>
                          )}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                هنوز پاسخی ثبت نشده است
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* فایل‌های آپلودشده توسط مخاطبان */}
      {poll.allowFileUpload && (
        <Card className="border-accent/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="w-4 h-4" />
              فایل‌های آپلودشده توسط مخاطبان
            </CardTitle>
            <CardDescription>
              {poll.fileUploadLabel || 'فایل‌های ارسال‌شده توسط پاسخ‌دهندگان'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {poll.allFiles && poll.allFiles.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {poll.allFiles.map((file) => {
                  const isImage = file.type?.startsWith('image/') || /\.(jpg|jpeg|png|gif|webp)$/i.test(file.name || '')
                  return (
                    <div
                      key={file.id}
                      className="rounded-lg border border-border/60 overflow-hidden bg-card/50"
                    >
                      {isImage && file.url ? (
                        <a
                          href={file.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="block aspect-video bg-muted/30"
                        >
                          <img
                            src={file.url}
                            alt={file.name || 'فایل'}
                            className="w-full h-full object-cover hover:scale-105 transition-transform"
                          />
                        </a>
                      ) : (
                        <a
                          href={file.url || '#'}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="block aspect-video bg-muted/30 flex items-center justify-center"
                        >
                          <FileText className="w-10 h-10 text-muted-foreground" />
                        </a>
                      )}
                      <div className="p-2 space-y-1">
                        <div className="text-xs font-medium truncate" title={file.name || ''}>
                          {file.name || 'فایل بدون نام'}
                        </div>
                        <div className="text-[10px] text-muted-foreground flex items-center justify-between gap-2">
                          <span className="truncate">گزینه: {file.optionText}</span>
                          <span>{new Date(file.createdAt).toLocaleDateString('fa-IR')}</span>
                        </div>
                        <div className="text-[10px] text-muted-foreground">
                          ارسال توسط: {file.user}
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                هنوز فایلی آپلود نشده است
              </p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
