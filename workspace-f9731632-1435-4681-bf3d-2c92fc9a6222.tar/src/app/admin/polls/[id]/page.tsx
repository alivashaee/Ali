import Link from 'next/link'
import { notFound } from 'next/navigation'
import { db } from '@/lib/db'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { ArrowRight } from 'lucide-react'
import { PollResultsClient } from './poll-results-client'

export const dynamic = 'force-dynamic'

type Props = { params: Promise<{ id: string }> }

export default async function AdminPollResultsPage({ params }: Props) {
  const { id } = await params
  const poll = await db.poll.findUnique({
    where: { id },
    include: {
      options: {
        orderBy: { id: 'asc' },
        include: {
          _count: { select: { responses: true } },
          responses: {
            select: {
              id: true,
              fileUrl: true,
              fileName: true,
              fileType: true,
              textResponse: true,
              createdAt: true,
              userId: true,
              user: { select: { name: true, username: true } },
            },
            orderBy: { createdAt: 'desc' },
          },
        },
      },
      responses: {
        // پاسخ‌های تشریحی که optionId ندارند
        where: { optionId: null },
        select: {
          id: true,
          textResponse: true,
          fileUrl: true,
          fileName: true,
          fileType: true,
          createdAt: true,
          userId: true,
          user: { select: { name: true, username: true } },
        },
        orderBy: { createdAt: 'desc' },
      },
      creator: { select: { name: true } },
      _count: { select: { responses: true } },
    },
  })

  if (!poll) notFound()

  const total = poll._count.responses

  // پاسخ‌های تشریحی (متن آزاد)
  const descriptiveResponses = poll.responses.map((r) => ({
    id: r.id,
    text: r.textResponse,
    fileUrl: r.fileUrl,
    fileName: r.fileName,
    fileType: r.fileType,
    createdAt: r.createdAt.toISOString(),
    user: r.user ? r.user.name : 'مخاطب ناشناس',
  }))

  // جمع‌آوری همه فایل‌های آپلودشده
  const allFiles = poll.options.flatMap((o) =>
    o.responses
      .filter((r) => !!r.fileUrl)
      .map((r) => ({
        id: r.id,
        url: r.fileUrl,
        name: r.fileName,
        type: r.fileType,
        createdAt: r.createdAt.toISOString(),
        user: r.user ? r.user.name : 'مخاطب ناشناس',
        optionText: o.text,
      }))
  )

  const results = {
    id: poll.id,
    title: poll.title,
    description: poll.description,
    buttonColor: poll.buttonColor,
    buttonShape: poll.buttonShape,
    buttonText: poll.buttonText,
    background: poll.background,
    isPublic: poll.isPublic,
    shareToken: poll.shareToken,
    createdAt: poll.createdAt.toISOString(),
    creatorName: poll.creator?.name || null,
    total,
    pollType: poll.pollType,
    descriptiveResponses,
    allowFileUpload: poll.allowFileUpload,
    fileUploadLabel: poll.fileUploadLabel,
    allFiles,
    options: poll.options.map((o) => ({
      id: o.id,
      text: o.text,
      imageUrl: o.imageUrl,
      count: o._count.responses,
      percent:
        total > 0 ? Math.round((o._count.responses / total) * 100) : 0,
    })),
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" size="sm">
              <Link href="/admin/polls">
                <ArrowRight className="w-4 h-4 ml-1" />
                بازگشت
              </Link>
            </Button>
          </div>
          <h1 className="text-2xl font-bold text-primary mt-1">
            {poll.title}
          </h1>
          <div className="flex items-center gap-2 mt-1">
            <Badge variant={poll.isPublic ? 'default' : 'secondary'}>
              {poll.isPublic ? 'عمومی' : 'خصوصی'}
            </Badge>
            {poll.creator?.name && (
              <span className="text-xs text-muted-foreground">
                ساخته‌شده توسط {poll.creator.name}
              </span>
            )}
          </div>
        </div>
      </div>

      <PollResultsClient poll={results} />
    </div>
  )
}
