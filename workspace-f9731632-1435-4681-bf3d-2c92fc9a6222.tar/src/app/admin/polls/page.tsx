import Link from 'next/link'
import { db } from '@/lib/db'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Plus,
  BarChart3,
  ExternalLink,
  Users,
} from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function AdminPollsPage() {
  const polls = await db.poll.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      _count: { select: { responses: true, options: true } },
      creator: { select: { name: true } },
    },
  })

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-primary">مدیریت نظرسنجی‌ها</h1>
          <p className="text-sm text-muted-foreground mt-1">
            ایجاد، ویرایش و مشاهده نتایج نظرسنجی‌ها
          </p>
        </div>
        <Button asChild>
          <Link href="/admin/polls/new">
            <Plus className="w-4 h-4 ml-2" />
            نظرسنجی جدید
          </Link>
        </Button>
      </div>

      <Card className="border-accent/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-primary" />
            فهرست نظرسنجی‌ها
          </CardTitle>
          <CardDescription>
            مجموعاً {polls.length.toLocaleString('fa-IR')} نظرسنجی
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto custom-scroll">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">عنوان</TableHead>
                  <TableHead className="text-right">نوع</TableHead>
                  <TableHead className="text-right">گزینه‌ها</TableHead>
                  <TableHead className="text-right">پاسخ‌ها</TableHead>
                  <TableHead className="text-right">تاریخ</TableHead>
                  <TableHead className="text-center">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {polls.length === 0 && (
                  <TableRow>
                    <TableCell
                      colSpan={6}
                      className="text-center text-muted-foreground py-6"
                    >
                      نظرسنجی‌ای یافت نشد. یک نظرسنجی جدید بسازید.
                    </TableCell>
                  </TableRow>
                )}
                {polls.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell>
                      <div className="font-medium max-w-[260px] truncate">
                        {p.title}
                      </div>
                      {p.description && (
                        <div className="text-xs text-muted-foreground line-clamp-1 max-w-xs">
                          {p.description}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={p.isPublic ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {p.isPublic ? 'عمومی' : 'خصوصی'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {p._count.options.toLocaleString('fa-IR')}
                    </TableCell>
                    <TableCell className="text-xs">
                      <span className="inline-flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {p._count.responses.toLocaleString('fa-IR')}
                      </span>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(p.createdAt).toLocaleDateString('fa-IR')}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-1">
                        <Button asChild size="icon" variant="ghost" title="مشاهده نتایج">
                          <Link href={`/admin/polls/${p.id}`}>
                            <BarChart3 className="w-4 h-4" />
                          </Link>
                        </Button>
                        {p.shareToken && (
                          <Button
                            asChild
                            size="icon"
                            variant="ghost"
                            title="صفحه عمومی"
                          >
                            <Link
                              href={`/polls/${p.shareToken}`}
                              target="_blank"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </Link>
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
