'use client'

import { useState } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import Link from 'next/link'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { FileUpload } from '@/components/admin/file-upload'
import {
  ArrowRight,
  Plus,
  Trash2,
  Save,
  Loader2,
  ImageIcon,
  ExternalLink,
  Copy,
  Check,
  Upload,
} from 'lucide-react'

type Option = { id: string; text: string; imageUrl: string | null }

export function PollBuilderClient() {
  const router = useRouter()
  const pathname = usePathname()
  // تشخیص اینکه آیا کاربر در /admin است یا /coach — برای انتخاب API درست
  const apiBase = pathname?.startsWith('/coach') ? '/api/coach/polls' : '/api/admin/polls'
  const { toast } = useToast()
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [background, setBackground] = useState<string | null>(null)
  const [buttonColor, setButtonColor] = useState('#1f5130')
  const [buttonShape, setButtonShape] = useState<'rounded' | 'square' | 'pill'>(
    'rounded'
  )
  const [buttonText, setButtonText] = useState('ثبت پاسخ')
  const [isPublic, setIsPublic] = useState(true)
  const [pollType, setPollType] = useState<'multiple' | 'descriptive'>('multiple')
  const [allowFileUpload, setAllowFileUpload] = useState(false)
  const [fileUploadLabel, setFileUploadLabel] = useState('')
  const [fileUploadRequired, setFileUploadRequired] = useState(false)
  const [options, setOptions] = useState<Option[]>([
    { id: cryptoId(), text: '', imageUrl: null },
    { id: cryptoId(), text: '', imageUrl: null },
  ])
  const [loading, setLoading] = useState(false)
  const [shareUrl, setShareUrl] = useState<string | null>(null)

  function cryptoId() {
    return Math.random().toString(36).slice(2) + Date.now().toString(36)
  }

  function updateOption(id: string, patch: Partial<Option>) {
    setOptions((arr) =>
      arr.map((o) => (o.id === id ? { ...o, ...patch } : o))
    )
  }

  function addOption() {
    setOptions((arr) => [
      ...arr,
      { id: cryptoId(), text: '', imageUrl: null },
    ])
  }

  function removeOption(id: string) {
    setOptions((arr) => (arr.length <= 2 ? arr : arr.filter((o) => o.id !== id)))
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!title.trim()) {
      toast({ title: 'عنوان نظرسنجی الزامی است', variant: 'destructive' })
      return
    }
    const valid = options.filter((o) => o.text.trim())
    if (pollType === 'multiple' && valid.length < 2) {
      toast({
        title: 'برای نظرسنجی چندگزینه‌ای، حداقل دو گزینه با متن الزامی است',
        variant: 'destructive',
      })
      return
    }
    setLoading(true)
    setShareUrl(null)
    try {
      const res = await fetch(apiBase, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title.trim(),
          description,
          background,
          buttonColor,
          buttonShape,
          buttonText,
          isPublic,
          pollType,
          allowFileUpload,
          fileUploadLabel: fileUploadLabel.trim() || null,
          fileUploadRequired,
          options: valid.map((o) => ({
            text: o.text.trim(),
            imageUrl: o.imageUrl,
          })),
          autoShare: true,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'خطا')
      toast({ title: 'نظرسنجی ایجاد شد' })
      setShareUrl(data.shareUrl || null)
      router.refresh()
    } catch (e: any) {
      toast({
        title: 'خطا',
        description: e?.message,
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <Card className="lg:col-span-2 border-accent/20">
        <CardHeader>
          <CardTitle className="text-base">تنظیمات نظرسنجی</CardTitle>
          <CardDescription>اطلاعات اصلی نظرسنجی</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            <div>
              <Label htmlFor="pb-title">عنوان *</Label>
              <Input
                id="pb-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                placeholder="مثلاً: چه موضوعی برای جلسه بعد پیشنهاد می‌دهید؟"
              />
            </div>
            <div>
              <Label htmlFor="pb-desc">توضیحات (اختیاری)</Label>
              <Textarea
                id="pb-desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                placeholder="توضیح کوتاه درباره نظرسنجی..."
              />
            </div>

            <div>
              <Label>پس‌زمینه (تصویر)</Label>
              <FileUpload
                value={background}
                onChange={setBackground}
                accept="image/*"
                label="بارگذاری پس‌زمینه"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <Label htmlFor="pb-btnColor">رنگ دکمه</Label>
                <div className="flex items-center gap-2">
                  <input
                    id="pb-btnColor"
                    type="color"
                    value={buttonColor}
                    onChange={(e) => setButtonColor(e.target.value)}
                    className="w-12 h-10 rounded-md border border-border cursor-pointer"
                  />
                  <Input
                    value={buttonColor}
                    onChange={(e) => setButtonColor(e.target.value)}
                    dir="ltr"
                    className="text-right font-mono text-sm"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="pb-btnText">متن دکمه</Label>
                <Input
                  id="pb-btnText"
                  value={buttonText}
                  onChange={(e) => setButtonText(e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="pb-btnShape">شکل دکمه</Label>
              <Select
                value={buttonShape}
                onValueChange={(v) =>
                  setButtonShape(v as 'rounded' | 'square' | 'pill')
                }
              >
                <SelectTrigger id="pb-btnShape">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rounded">گرد (متوسط)</SelectItem>
                  <SelectItem value="square">مربع</SelectItem>
                  <SelectItem value="pill">کاملاً گرد</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <div className="text-sm font-medium">نظرسنجی عمومی</div>
                <div className="text-xs text-muted-foreground">
                  اگر فعال باشد، لینک اشتراک‌گذاری برای همه باز می‌شود
                </div>
              </div>
              <Switch checked={isPublic} onCheckedChange={setIsPublic} />
            </div>

            {/* نوع نظرسنجی */}
            <div className="rounded-lg border p-3 space-y-2 bg-accent/5">
              <div>
                <div className="text-sm font-medium">نوع نظرسنجی</div>
                <div className="text-xs text-muted-foreground">
                  انتخاب کنید که مخاطب از بین گزینه‌ها انتخاب کند یا پاسخ تشریحی بنویسد
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <label
                  className={`flex items-start gap-2 p-3 rounded-lg cursor-pointer transition-all border-2 ${
                    pollType === 'multiple'
                      ? 'border-primary bg-primary/10'
                      : 'border-border hover:bg-accent/10'
                  }`}
                >
                  <input
                    type="radio"
                    name="pollType"
                    value="multiple"
                    checked={pollType === 'multiple'}
                    onChange={() => setPollType('multiple')}
                    className="mt-0.5"
                  />
                  <div>
                    <div className="text-sm font-medium">چندگزینه‌ای</div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      مخاطب یکی از گزینه‌ها را انتخاب می‌کند
                    </div>
                  </div>
                </label>
                <label
                  className={`flex items-start gap-2 p-3 rounded-lg cursor-pointer transition-all border-2 ${
                    pollType === 'descriptive'
                      ? 'border-primary bg-primary/10'
                      : 'border-border hover:bg-accent/10'
                  }`}
                >
                  <input
                    type="radio"
                    name="pollType"
                    value="descriptive"
                    checked={pollType === 'descriptive'}
                    onChange={() => setPollType('descriptive')}
                    className="mt-0.5"
                  />
                  <div>
                    <div className="text-sm font-medium">تشریحی (متن آزاد)</div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      مخاطب پاسخ خود را به صورت متن می‌نویسد
                    </div>
                  </div>
                </label>
              </div>
              {pollType === 'descriptive' && (
                <div className="text-xs text-primary bg-primary/10 rounded p-2 mt-1">
                  ℹ️ در حالت تشریحی، بخش گزینه‌ها غیرفعال می‌شود و مخاطب یک فیلد متن برای نوشتن پاسخ خواهد دید.
                </div>
              )}
            </div>

            {/* قابلیت آپلود فایل توسط مخاطب */}
            <div className="rounded-lg border p-3 space-y-3 bg-accent/5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium flex items-center gap-1.5">
                    <Upload className="w-4 h-4" />
                    اجازه آپلود فایل توسط مخاطب
                  </div>
                  <div className="text-xs text-muted-foreground">
                    اگر فعال باشد، مخاطب می‌تواند هنگام پاسخ‌دهی فایل خود را آپلود کند (مثلاً عکس، مدرک، یا فایل درخواستی)
                  </div>
                </div>
                <Switch checked={allowFileUpload} onCheckedChange={setAllowFileUpload} />
              </div>
              {allowFileUpload && (
                <>
                  <div className="space-y-1.5 pt-2 border-t border-border/40">
                    <Label htmlFor="fileUploadLabel" className="text-xs">
                      برچسب فیلد آپلود (مثلاً: «لطفاً عکس خود را آپلود کنید»)
                    </Label>
                    <Input
                      id="fileUploadLabel"
                      value={fileUploadLabel}
                      onChange={(e) => setFileUploadLabel(e.target.value)}
                      placeholder="مثلاً: بارگذاری عکس مدرک"
                      className="text-sm"
                    />
                  </div>
                  <div className="flex items-center justify-between pt-1">
                    <div>
                      <div className="text-sm font-medium">آپلود فایل الزامی است</div>
                      <div className="text-xs text-muted-foreground">
                        اگر فعال باشد، مخاطب نمی‌تواند بدون بارگذاری فایل پاسخ ثبت کند
                      </div>
                    </div>
                    <Switch checked={fileUploadRequired} onCheckedChange={setFileUploadRequired} />
                  </div>
                </>
              )}
            </div>

            {/* Options - فقط در حالت چندگزینه‌ای نمایش داده می‌شود */}
            {pollType === 'multiple' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>گزینه‌ها (حداقل ۲)</Label>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={addOption}
                >
                  <Plus className="w-4 h-4 ml-2" />
                  افزودن گزینه
                </Button>
              </div>
              <div className="space-y-2">
                {options.map((opt, idx) => (
                  <div
                    key={opt.id}
                    className="flex items-center gap-2 rounded-lg border p-2"
                  >
                    <span className="text-xs text-muted-foreground w-6 text-center">
                      {idx + 1}
                    </span>
                    <div className="flex-1 space-y-1">
                      <Input
                        value={opt.text}
                        onChange={(e) =>
                          updateOption(opt.id, { text: e.target.value })
                        }
                        placeholder={`متن گزینه ${idx + 1}`}
                      />
                      {opt.imageUrl && (
                        <div className="relative w-16 h-12 rounded overflow-hidden border border-border">
                          <img
                            src={opt.imageUrl}
                            alt=""
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                    </div>
                    <FileUpload
                      value={opt.imageUrl}
                      onChange={(v) =>
                        updateOption(opt.id, { imageUrl: v })
                      }
                      accept="image/*"
                      label=""
                      preview={false}
                    />
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      className="text-destructive"
                      onClick={() => removeOption(opt.id)}
                      disabled={options.length <= 2}
                      title="حذف گزینه"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
            )}

            <div className="flex items-center justify-between gap-2 pt-2">
              <Button asChild variant="ghost">
                <Link href="/admin/polls">
                  <ArrowRight className="w-4 h-4 ml-2" />
                  بازگشت
                </Link>
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? (
                  <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 ml-2" />
                )}
                ایجاد و اشتراک‌گذاری
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Live preview & share */}
      <div className="space-y-4">
        <Card className="border-accent/20">
          <CardHeader>
            <CardTitle className="text-base">پیش‌نمایش</CardTitle>
            <CardDescription>ظاهر صفحه‌ی نظرسنجی</CardDescription>
          </CardHeader>
          <CardContent>
            <div
              className="relative rounded-xl overflow-hidden border border-border min-h-[280px] flex flex-col"
              style={{
                background: background
                  ? `linear-gradient(rgba(0,0,0,0.35), rgba(0,0,0,0.35)), url(${background}) center/cover`
                  : 'linear-gradient(135deg, var(--sprout) 12%, var(--background) 50%, var(--gold) 8%)',
              }}
            >
              <div className="p-4 flex-1 flex flex-col gap-3 text-white">
                <div>
                  <h3 className="font-bold text-lg drop-shadow">
                    {title || 'عنوان نظرسنجی'}
                  </h3>
                  {description && (
                    <p className="text-xs opacity-90 line-clamp-2 mt-1">
                      {description}
                    </p>
                  )}
                </div>
                <div className="space-y-2 flex-1">
                  {options
                    .filter((o) => o.text)
                    .map((opt) => (
                      <label
                        key={opt.id}
                        className="flex items-center gap-2 rounded-lg bg-white/20 backdrop-blur p-2 cursor-pointer"
                      >
                        <input
                          type="radio"
                          name="preview-opt"
                          className="w-4 h-4 accent-white"
                        />
                        {opt.imageUrl && (
                          <img
                            src={opt.imageUrl}
                            alt=""
                            className="w-8 h-8 rounded object-cover"
                          />
                        )}
                        <span className="text-sm">{opt.text}</span>
                      </label>
                    ))}
                </div>
                <button
                  type="button"
                  className="self-end px-5 py-2 font-bold text-white shadow-md disabled:opacity-50"
                  style={{
                    backgroundColor: buttonColor,
                    borderRadius:
                      buttonShape === 'square'
                        ? '0'
                        : buttonShape === 'pill'
                        ? '9999px'
                        : '0.5rem',
                  }}
                >
                  {buttonText || 'ثبت پاسخ'}
                </button>
              </div>
            </div>
          </CardContent>
        </Card>

        {shareUrl && (
          <Card className="border-accent/40 bg-accent/5">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-sprout" />
                لینک اشتراک‌گذاری
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-xs text-muted-foreground">
                نظرسنجی ایجاد شد. این لینک را با مخاطبان به اشتراک بگذارید.
              </p>
              <div className="flex items-center gap-2">
                <Input
                  value={
                    typeof window !== 'undefined'
                      ? `${window.location.origin}${shareUrl}`
                      : shareUrl
                  }
                  readOnly
                  dir="ltr"
                  className="text-right text-xs font-mono"
                />
                <CopyButton text={shareUrl} />
              </div>
              <Button asChild variant="outline" className="w-full">
                <Link href={shareUrl} target="_blank">
                  <ExternalLink className="w-4 h-4 ml-2" />
                  باز کردن صفحه نظرسنجی
                </Link>
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

function CopyButton({ text }: { text: string }) {
  const { toast } = useToast()
  const [copied, setCopied] = useState(false)
  async function copy() {
    try {
      const full =
        typeof window !== 'undefined' ? `${window.location.origin}${text}` : text
      await navigator.clipboard.writeText(full)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
      toast({ title: 'کپی شد' })
    } catch {
      toast({ title: 'کپی ناموفق بود', variant: 'destructive' })
    }
  }
  return (
    <Button size="icon" variant="outline" onClick={copy} type="button">
      {copied ? (
        <Check className="w-4 h-4 text-sprout" />
      ) : (
        <Copy className="w-4 h-4" />
      )}
    </Button>
  )
}
