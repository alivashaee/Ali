import { PollBuilderClient } from './poll-builder-client'

export const dynamic = 'force-dynamic'

export default function NewPollPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-primary">نظرسنجی جدید</h1>
        <p className="text-sm text-muted-foreground mt-1">
          با گزینه‌های دلخواه، دکمه و پس‌زمینه‌ی سفارشی
        </p>
      </div>
      <PollBuilderClient />
    </div>
  )
}
