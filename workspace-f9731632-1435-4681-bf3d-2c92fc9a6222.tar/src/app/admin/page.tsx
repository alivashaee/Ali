import Link from 'next/link'
import { db } from '@/lib/db'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Users,
  GraduationCap,
  Users2,
  BarChart3,
  FileText,
  ArrowLeft,
  TrendingUp,
} from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function AdminDashboardPage() {
  const [
    totalUsers,
    totalCoaches,
    totalGroups,
    totalPolls,
    totalBlogPosts,
    totalMembers,
    totalResponses,
    recentUsers,
    recentPolls,
    recentPosts,
  ] = await Promise.all([
    db.user.count(),
    db.user.count({ where: { role: 'COACH' } }),
    db.group.count(),
    db.poll.count(),
    db.blogPost.count(),
    db.user.count({ where: { role: 'MEMBER' } }),
    db.pollResponse.count(),
    db.user.findMany({
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: {
        id: true,
        name: true,
        username: true,
        role: true,
        createdAt: true,
        blocked: true,
      },
    }),
    db.poll.findMany({
      orderBy: { createdAt: 'desc' },
      take: 5,
      include: {
        _count: { select: { responses: true } },
        creator: { select: { name: true } },
      },
    }),
    db.blogPost.findMany({
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: {
        id: true,
        title: true,
        published: true,
        createdAt: true,
      },
    }),
  ])

  const stats = [
    {
      label: 'کل کاربران',
      value: totalUsers,
      icon: Users,
      href: '/admin/users',
      color: 'text-primary',
    },
    {
      label: 'مربیان',
      value: totalCoaches,
      icon: GraduationCap,
      href: '/admin/users',
      color: 'text-sprout',
    },
    {
      label: 'اعضای عادی',
      value: totalMembers,
      icon: Users,
      href: '/admin/users',
      color: 'text-navy',
    },
    {
      label: 'گروه‌ها',
      value: totalGroups,
      icon: Users2,
      href: '/admin/groups',
      color: 'text-accent-foreground',
    },
    {
      label: 'نظرسنجی‌ها',
      value: totalPolls,
      icon: BarChart3,
      href: '/admin/polls',
      color: 'text-gold',
    },
    {
      label: 'پست‌های وبلاگ',
      value: totalBlogPosts,
      icon: FileText,
      href: '/admin/content',
      color: 'text-foreground',
    },
    {
      label: 'پاسخ‌های نظرسنجی',
      value: totalResponses,
      icon: TrendingUp,
      href: '/admin/polls',
      color: 'text-sprout',
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-primary">پیشخان مدیریت</h1>
          <p className="text-sm text-muted-foreground mt-1">
            نمای کلی سامانه‌ی موسسه رویش‌های پیشران
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <Link
              key={stat.label}
              href={stat.href}
              className="transition-transform hover:scale-[1.02]"
            >
              <Card className="border-accent/20 hover:border-accent/40 transition-colors">
                <CardContent className="p-4 flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {stat.label}
                    </span>
                    <Icon className={`w-4 h-4 ${stat.color}`} />
                  </div>
                  <span className="text-2xl font-bold text-foreground">
                    {stat.value.toLocaleString('fa-IR')}
                  </span>
                </CardContent>
              </Card>
            </Link>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Recent Users */}
        <Card className="border-accent/20">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Users className="w-4 h-4 text-primary" />
                آخرین کاربران
              </CardTitle>
              <Link
                href="/admin/users"
                className="text-xs text-primary flex items-center gap-1 hover:underline"
              >
                همه
                <ArrowLeft className="w-3 h-3" />
              </Link>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentUsers.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                کاربری یافت نشد
              </p>
            )}
            {recentUsers.map((u) => (
              <div
                key={u.id}
                className="flex items-center justify-between gap-2 text-sm border-b border-border/40 pb-2 last:border-0"
              >
                <div className="min-w-0">
                  <div className="font-medium truncate">{u.name}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {u.username}
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1 shrink-0">
                  <RoleBadge role={u.role} />
                  <span className="text-xs text-muted-foreground">
                    {new Date(u.createdAt).toLocaleDateString('fa-IR')}
                  </span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recent Polls */}
        <Card className="border-accent/20">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-primary" />
                آخرین نظرسنجی‌ها
              </CardTitle>
              <Link
                href="/admin/polls"
                className="text-xs text-primary flex items-center gap-1 hover:underline"
              >
                همه
                <ArrowLeft className="w-3 h-3" />
              </Link>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentPolls.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                نظرسنجی یافت نشد
              </p>
            )}
            {recentPolls.map((p) => (
              <div
                key={p.id}
                className="flex items-center justify-between gap-2 text-sm border-b border-border/40 pb-2 last:border-0"
              >
                <div className="min-w-0">
                  <div className="font-medium truncate">{p.title}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {p.creator?.name || 'نامشخص'}
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1 shrink-0">
                  <Badge
                    variant={p.isPublic ? 'default' : 'secondary'}
                    className="text-xs"
                  >
                    {p.isPublic ? 'عمومی' : 'خصوصی'}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {p._count.responses.toLocaleString('fa-IR')} پاسخ
                  </span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recent Posts */}
        <Card className="border-accent/20">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <FileText className="w-4 h-4 text-primary" />
                آخرین پست‌ها
              </CardTitle>
              <Link
                href="/admin/content"
                className="text-xs text-primary flex items-center gap-1 hover:underline"
              >
                همه
                <ArrowLeft className="w-3 h-3" />
              </Link>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentPosts.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                پستی یافت نشد
              </p>
            )}
            {recentPosts.map((p) => (
              <div
                key={p.id}
                className="flex items-center justify-between gap-2 text-sm border-b border-border/40 pb-2 last:border-0"
              >
                <div className="min-w-0">
                  <div className="font-medium truncate">{p.title}</div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(p.createdAt).toLocaleDateString('fa-IR')}
                  </div>
                </div>
                <Badge
                  variant={p.published ? 'default' : 'secondary'}
                  className="text-xs shrink-0"
                >
                  {p.published ? 'منتشر' : 'پیش‌نویس'}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function RoleBadge({ role }: { role: string }) {
  const map: Record<string, { label: string; variant: 'default' | 'secondary' | 'outline' }> = {
    SUPER_ADMIN: { label: 'مدیر', variant: 'default' },
    COACH: { label: 'مربی', variant: 'secondary' },
    MEMBER: { label: 'عضو', variant: 'outline' },
  }
  const cfg = map[role] || { label: role, variant: 'outline' as const }
  return (
    <Badge variant={cfg.variant} className="text-xs">
      {cfg.label}
    </Badge>
  )
}
