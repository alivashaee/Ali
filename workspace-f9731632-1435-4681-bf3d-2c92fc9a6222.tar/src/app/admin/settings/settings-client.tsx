'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { useToast } from '@/hooks/use-toast'
import { FileUpload } from '@/components/admin/file-upload'
import { Save, Loader2, Settings as SettingsIcon } from 'lucide-react'

type Settings = {
  siteName: string
  description: string
  introVideo: string | null
  logo: string | null
  contactInfo: string | null
  heroTitle: string
  heroSubtitle: string
}

export function SettingsClient({ settings }: { settings: Settings }) {
  const router = useRouter()
  const { toast } = useToast()
  const [form, setForm] = useState(settings)
  const [loading, setLoading] = useState(false)

  function setField<K extends keyof Settings>(
    key: K,
    value: Settings[K]
  ) {
    setForm((p) => ({ ...p, [key]: value }))
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (!res.ok) throw new Error('خطا')
      toast({ title: 'تنظیمات ذخیره شد' })
      router.refresh()
    } catch {
      toast({ title: 'خطا', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="border-accent/20 max-w-3xl">
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <SettingsIcon className="w-4 h-4" />
          پیکربندی پایه
        </CardTitle>
        <CardDescription>
          این تنظیمات روی عنوان، فوتر و صفحه اصلی اثر می‌گذارند.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <Label htmlFor="ss-siteName">نام موسسه</Label>
              <Input
                id="ss-siteName"
                value={form.siteName}
                onChange={(e) => setField('siteName', e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="ss-introVideo">ویدیوی معرفی (URL)</Label>
              <Input
                id="ss-introVideo"
                value={form.introVideo || ''}
                onChange={(e) => setField('introVideo', e.target.value)}
                dir="ltr"
                className="text-right"
                placeholder="https://..."
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <Label htmlFor="ss-heroTitle">عنوان هیرو صفحه اصلی</Label>
              <Input
                id="ss-heroTitle"
                value={form.heroTitle}
                onChange={(e) => setField('heroTitle', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="ss-heroSubtitle">زیرعنوان هیرو</Label>
              <Input
                id="ss-heroSubtitle"
                value={form.heroSubtitle}
                onChange={(e) => setField('heroSubtitle', e.target.value)}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="ss-description">توضیحات کوتاه</Label>
            <Textarea
              id="ss-description"
              value={form.description}
              onChange={(e) => setField('description', e.target.value)}
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="ss-contactInfo">اطلاعات تماس</Label>
            <Textarea
              id="ss-contactInfo"
              value={form.contactInfo || ''}
              onChange={(e) => setField('contactInfo', e.target.value)}
              rows={4}
              placeholder="آدرس، تلفن، ایمیل و..."
            />
          </div>

          <div>
            <Label>لوگو</Label>
            <FileUpload
              value={form.logo}
              onChange={(v) => setField('logo', v)}
              accept="image/*"
              label="بارگذاری لوگو"
            />
          </div>

          <Button type="submit" disabled={loading}>
            {loading ? (
              <Loader2 className="w-4 h-4 ml-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 ml-2" />
            )}
            ذخیره تنظیمات
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
