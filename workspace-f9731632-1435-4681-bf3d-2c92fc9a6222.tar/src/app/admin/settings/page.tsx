import { getSiteSettings } from '@/lib/site-settings'
import { SettingsClient } from './settings-client'

export const dynamic = 'force-dynamic'

export default async function AdminSettingsPage() {
  const settings = await getSiteSettings()
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-primary">تنظیمات سامانه</h1>
        <p className="text-sm text-muted-foreground mt-1">
          پیکربندی نام موسسه، اطلاعات تماس، لوگو و ویدیوی معرفی
        </p>
      </div>
      <SettingsClient
        settings={{
          siteName: settings.siteName,
          description: settings.description,
          introVideo: settings.introVideo,
          logo: settings.logo,
          contactInfo: settings.contactInfo,
          heroTitle: settings.heroTitle ?? '',
          heroSubtitle: settings.heroSubtitle ?? '',
        }}
      />
    </div>
  )
}
