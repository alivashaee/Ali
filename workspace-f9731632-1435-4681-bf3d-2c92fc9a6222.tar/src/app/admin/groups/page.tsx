import Link from 'next/link'
import { db } from '@/lib/db'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Users2 } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function AdminGroupsPage() {
  const groups = await db.group.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      coach: {
        select: { id: true, name: true, username: true },
      },
      _count: { select: { members: true, messages: true } },
    },
  })

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-primary">مدیریت گروه‌ها</h1>
        <p className="text-sm text-muted-foreground mt-1">
          مشاهده تمام گروه‌های سامانه به‌تفکیک مربی
        </p>
      </div>

      <Card className="border-accent/20">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Users2 className="w-4 h-4 text-primary" />
                فهرست گروه‌ها
              </CardTitle>
              <CardDescription className="mt-1">
                مجموعاً {groups.length.toLocaleString('fa-IR')} گروه فعال
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto custom-scroll">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">نام گروه</TableHead>
                  <TableHead className="text-right">مربی</TableHead>
                  <TableHead className="text-right">تعداد اعضا</TableHead>
                  <TableHead className="text-right">پیام‌ها</TableHead>
                  <TableHead className="text-right">تاریخ ایجاد</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {groups.length === 0 && (
                  <TableRow>
                    <TableCell
                      colSpan={5}
                      className="text-center text-muted-foreground py-6"
                    >
                      گروهی یافت نشد
                    </TableCell>
                  </TableRow>
                )}
                {groups.map((g) => (
                  <TableRow key={g.id}>
                    <TableCell>
                      <div className="font-medium">{g.name}</div>
                      {g.description && (
                        <div className="text-xs text-muted-foreground line-clamp-1 max-w-xs">
                          {g.description}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">{g.coach?.name || '—'}</div>
                      <div
                        className="text-xs text-muted-foreground"
                        dir="ltr"
                      >
                        {g.coach?.username || ''}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-xs">
                        {g._count.members.toLocaleString('fa-IR')} عضو
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {g._count.messages.toLocaleString('fa-IR')} پیام
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(g.createdAt).toLocaleDateString('fa-IR')}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
