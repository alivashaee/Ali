import { db } from '@/lib/db'
import { getSiteSettings } from '@/lib/site-settings'
import { ContentClient } from './content-client'

export const dynamic = 'force-dynamic'

export default async function AdminContentPage() {
  const [posts, settings] = await Promise.all([
    db.blogPost.findMany({
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        title: true,
        excerpt: true,
        image: true,
        published: true,
        createdAt: true,
      },
    }),
    getSiteSettings(),
  ])

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-primary">مدیریت محتوا</h1>
        <p className="text-sm text-muted-foreground mt-1">
          مدیریت پست‌های وبلاگ، تنظیمات صفحه اصلی و معرفی موسسه
        </p>
      </div>
      <ContentClient
        posts={posts.map((p) => ({
          ...p,
          createdAt: p.createdAt.toISOString(),
        }))}
        settings={{
          siteName: settings.siteName,
          description: settings.description,
          introVideo: settings.introVideo,
          logo: settings.logo,
          contactInfo: settings.contactInfo,
          heroTitle: settings.heroTitle ?? '',
          heroSubtitle: settings.heroSubtitle ?? '',
        }}
      />
    </div>
  )
}
