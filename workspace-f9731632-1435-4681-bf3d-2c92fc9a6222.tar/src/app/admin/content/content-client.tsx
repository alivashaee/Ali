'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { useToast } from '@/hooks/use-toast'
import { FileUpload } from '@/components/admin/file-upload'
import {
  Plus,
  Edit,
  Trash2,
  Save,
  Loader2,
  FileText,
  Settings as SettingsIcon,
  Info,
} from 'lucide-react'

type Post = {
  id: string
  title: string
  excerpt: string | null
  image: string | null
  published: boolean
  createdAt: string
}

type Settings = {
  siteName: string
  description: string
  introVideo: string | null
  logo: string | null
  contactInfo: string | null
  heroTitle: string
  heroSubtitle: string
}

export function ContentClient({
  posts: initial,
  settings: initialSettings,
}: {
  posts: Post[]
  settings: Settings
}) {
  return (
    <Tabs defaultValue="blog" className="w-full">
      <TabsList className="flex-wrap h-auto">
        <TabsTrigger value="blog" className="flex items-center gap-1.5">
          <FileText className="w-3.5 h-3.5" />
          وبلاگ
        </TabsTrigger>
        <TabsTrigger value="settings" className="flex items-center gap-1.5">
          <SettingsIcon className="w-3.5 h-3.5" />
          تنظیمات صفحه
        </TabsTrigger>
        <TabsTrigger value="about" className="flex items-center gap-1.5">
          <Info className="w-3.5 h-3.5" />
          معرفی موسسه
        </TabsTrigger>
      </TabsList>
      <TabsContent value="blog" className="mt-4">
        <BlogTab posts={initial} />
      </TabsContent>
      <TabsContent value="settings" className="mt-4">
        <SettingsTab settings={initialSettings} />
      </TabsContent>
      <TabsContent value="about" className="mt-4">
        <AboutTab settings={initialSettings} />
      </TabsContent>
    </Tabs>
  )
}

function BlogTab({ posts: initial }: { posts: Post[] }) {
  const router = useRouter()
  const [posts, setPosts] = useState(initial)
  const [editingPost, setEditingPost] = useState<Post | null>(null)
  const [createOpen, setCreateOpen] = useState(false)
  const [editOpen, setEditOpen] = useState(false)

  async function refresh() {
    router.refresh()
    const res = await fetch('/api/admin/blog?pageSize=100', {
      cache: 'no-store',
    })
    if (res.ok) {
      const data = await res.json()
      setPosts(data.items)
    }
  }

  async function togglePublish(post: Post) {
    const res = await fetch(`/api/admin/blog/${post.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ published: !post.published }),
    })
    if (!res.ok) return
    await refresh()
  }

  async function deletePost(post: Post) {
    const res = await fetch(`/api/admin/blog/${post.id}`, {
      method: 'DELETE',
    })
    if (!res.ok) return
    await refresh()
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {posts.length.toLocaleString('fa-IR')} پست وبلاگ
        </p>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 ml-2" />
              پست جدید
            </Button>
          </DialogTrigger>
          <PostDialog
            key="create"
            onClose={() => setCreateOpen(false)}
            onSaved={refresh}
          />
        </Dialog>
      </div>

      <Card className="border-accent/20">
        <CardContent className="p-0">
          <div className="overflow-x-auto custom-scroll">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">عنوان</TableHead>
                  <TableHead className="text-right">وضعیت</TableHead>
                  <TableHead className="text-right">تاریخ</TableHead>
                  <TableHead className="text-center">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {posts.length === 0 && (
                  <TableRow>
                    <TableCell
                      colSpan={4}
                      className="text-center text-muted-foreground py-6"
                    >
                      پستی یافت نشد
                    </TableCell>
                  </TableRow>
                )}
                {posts.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell className="font-medium max-w-[200px] truncate">
                      {p.title}
                    </TableCell>
                    <TableCell>
                      <button onClick={() => togglePublish(p)}>
                        <Badge
                          variant={p.published ? 'default' : 'secondary'}
                          className="text-xs cursor-pointer"
                        >
                          {p.published ? 'منتشر' : 'پیش‌نویس'}
                        </Badge>
                      </button>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(p.createdAt).toLocaleDateString('fa-IR')}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => {
                            setEditingPost(p)
                            setEditOpen(true)
                          }}
                          title="ویرایش"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="text-destructive"
                              title="حذف"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>حذف پست؟</AlertDialogTitle>
                              <AlertDialogDescription>
                                آیا از حذف پست «{p.title}» مطمئن هستید؟
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>انصراف</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => deletePost(p)}
                                className="bg-destructive text-white hover:bg-destructive/90"
                              >
                                حذف
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {editingPost && (
        <PostDialog
          key={editingPost.id}
          post={editingPost}
          open={editOpen}
          onOpenChange={(o) => {
            setEditOpen(o)
            if (!o) setEditingPost(null)
          }}
          onSaved={refresh}
        />
      )}
    </div>
  )
}

function PostDialog({
  post,
  open: controlledOpen,
  onOpenChange,
  onSaved,
  onClose,
}: {
  post?: Post | null
  open?: boolean
  onOpenChange?: (o: boolean) => void
  onSaved?: () => void
  onClose?: () => void
}) {
  const { toast } = useToast()
  const [title, setTitle] = useState(post?.title || '')
  const [excerpt, setExcerpt] = useState(post?.excerpt || '')
  const [content, setContent] = useState('')
  const [image, setImage] = useState<string | null>(post?.image || null)
  const [published, setPublished] = useState(post?.published ?? true)
  const [loading, setLoading] = useState(false)
  const [loadingContent, setLoadingContent] = useState(!!post)
  const editingId = post?.id

  const isControlled = controlledOpen !== undefined
  const [internalOpen, setInternalOpen] = useState(false)
  const isOpen = isControlled ? controlledOpen : internalOpen

  useEffect(() => {
    if (!post || !isOpen) return
    let cancelled = false
    setLoadingContent(true)
    fetch(`/api/admin/blog/${post.id}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (!cancelled && data) {
          setContent(data.content || '')
        }
      })
      .finally(() => !cancelled && setLoadingContent(false))
    return () => {
      cancelled = true
    }
  }, [post?.id, isOpen])

  function close() {
    if (isControlled && onOpenChange) onOpenChange(false)
    else setInternalOpen(false)
    if (onClose) onClose()
    // Reset form (only for uncontrolled mode / create)
    setTitle('')
    setExcerpt('')
    setContent('')
    setImage(null)
    setPublished(true)
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!title || !content) {
      toast({ title: 'عنوان و محتوا الزامی است', variant: 'destructive' })
      return
    }
    setLoading(true)
    try {
      const url = editingId ? `/api/admin/blog/${editingId}` : '/api/admin/blog'
      const method = editingId ? 'PATCH' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          excerpt: excerpt || null,
          content,
          image,
          published,
        }),
      })
      if (!res.ok) throw new Error('خطا')
      toast({ title: editingId ? 'پست به‌روزرسانی شد' : 'پست ایجاد شد' })
      onSaved?.()
      close()
    } catch {
      toast({ title: 'خطا', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const dialog = (
    <DialogContent className="max-w-2xl">
      <DialogHeader>
        <DialogTitle>{editingId ? 'ویرایش پست' : 'پست وبلاگ جدید'}</DialogTitle>
        <DialogDescription>
          {editingId
            ? 'محتوای پست را ویرایش کنید'
            : 'یک پست وبلاگ جدید بسازید'}
        </DialogDescription>
      </DialogHeader>
      <form
        onSubmit={submit}
        className="space-y-3 max-h-[70vh] overflow-y-auto custom-scroll pl-1"
      >
        <div>
          <Label htmlFor="p-title">عنوان</Label>
          <Input
            id="p-title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="p-excerpt">خلاصه (اختیاری)</Label>
          <Textarea
            id="p-excerpt"
            value={excerpt}
            onChange={(e) => setExcerpt(e.target.value)}
            rows={2}
            placeholder="خلاصه‌ی کوتاه پست"
          />
        </div>
        <div>
          <Label>تصویر شاخص</Label>
          <FileUpload
            value={image}
            onChange={setImage}
            accept="image/*"
            label="بارگذاری تصویر"
          />
        </div>
        <div>
          <Label htmlFor="p-content">محتوای پست (Markdown)</Label>
          <Textarea
            id="p-content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={10}
            placeholder={
              loadingContent
                ? 'در حال بارگذاری محتوا...'
                : 'محتوای کامل پست را با فرمت Markdown بنویسید...'
            }
            className="font-mono text-sm"
            dir="rtl"
            disabled={loadingContent}
          />
        </div>
        <div className="flex items-center justify-between rounded-lg border p-3">
          <div>
            <div className="text-sm font-medium">وضعیت انتشار</div>
            <div className="text-xs text-muted-foreground">
              {published
                ? 'پست بلافاصله منتشر می‌شود'
                : 'به‌صورت پیش‌نویس ذخیره می‌شود'}
            </div>
          </div>
          <Switch checked={published} onCheckedChange={setPublished} />
        </div>
        <DialogFooter>
          <Button type="button" variant="ghost" onClick={close}>
            انصراف
          </Button>
          <Button type="submit" disabled={loading || loadingContent}>
            {loading ? (
              <Loader2 className="w-4 h-4 ml-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 ml-2" />
            )}
            {editingId ? 'به‌روزرسانی' : 'انتشار'}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  )

  if (isControlled) {
    return (
      <Dialog open={isOpen} onOpenChange={onOpenChange!}>
        {dialog}
      </Dialog>
    )
  }
  return (
    <Dialog open={isOpen} onOpenChange={(o) => !o && close()}>
      {dialog}
    </Dialog>
  )
}

function SettingsTab({ settings }: { settings: Settings }) {
  const router = useRouter()
  const { toast } = useToast()
  const [form, setForm] = useState(settings)
  const [loading, setLoading] = useState(false)

  function setField(key: keyof Settings, value: string | null) {
    setForm((p) => ({ ...p, [key]: value }))
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (!res.ok) throw new Error('خطا')
      toast({ title: 'تنظیمات ذخیره شد' })
      router.refresh()
    } catch {
      toast({ title: 'خطا', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="border-accent/20">
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <SettingsIcon className="w-4 h-4" />
          تنظیمات صفحه اصلی
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <Label htmlFor="s-siteName">نام موسسه</Label>
              <Input
                id="s-siteName"
                value={form.siteName}
                onChange={(e) => setField('siteName', e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="s-introVideo">ویدیوی معرفی (URL)</Label>
              <Input
                id="s-introVideo"
                value={form.introVideo || ''}
                onChange={(e) => setField('introVideo', e.target.value)}
                dir="ltr"
                className="text-right"
                placeholder="https://..."
              />
            </div>
          </div>
          <div>
            <Label htmlFor="s-heroTitle">عنوان هیرو</Label>
            <Input
              id="s-heroTitle"
              value={form.heroTitle || ''}
              onChange={(e) => setField('heroTitle', e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="s-heroSubtitle">زیرعنوان هیرو</Label>
            <Input
              id="s-heroSubtitle"
              value={form.heroSubtitle || ''}
              onChange={(e) => setField('heroSubtitle', e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="s-description">توضیحات کوتاه موسسه</Label>
            <Textarea
              id="s-description"
              value={form.description}
              onChange={(e) => setField('description', e.target.value)}
              rows={3}
            />
          </div>
          <div>
            <Label htmlFor="s-contactInfo">اطلاعات تماس</Label>
            <Textarea
              id="s-contactInfo"
              value={form.contactInfo || ''}
              onChange={(e) => setField('contactInfo', e.target.value)}
              rows={3}
              placeholder="آدرس، تلفن، ایمیل و..."
            />
          </div>
          <div>
            <Label>لوگوی موسسه</Label>
            <FileUpload
              value={form.logo}
              onChange={(v) => setField('logo', v)}
              accept="image/*"
              label="بارگذاری لوگو"
            />
          </div>
          <Button type="submit" disabled={loading}>
            {loading ? (
              <Loader2 className="w-4 h-4 ml-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 ml-2" />
            )}
            ذخیره تنظیمات
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

function AboutTab({ settings }: { settings: Settings }) {
  const router = useRouter()
  const { toast } = useToast()
  const [description, setDescription] = useState(settings.description)
  const [loading, setLoading] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description }),
      })
      if (!res.ok) throw new Error('خطا')
      toast({ title: 'به‌روزرسانی شد' })
      router.refresh()
    } catch {
      toast({ title: 'خطا', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="border-accent/20">
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Info className="w-4 h-4" />
          معرفی موسسه
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="space-y-4">
          <div>
            <Label htmlFor="a-desc">متن کامل معرفی موسسه</Label>
            <Textarea
              id="a-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={8}
              placeholder="متن کامل معرفی موسسه را بنویسید..."
            />
            <p className="text-xs text-muted-foreground mt-2">
              این متن در بخش «درباره ما» صفحه اصلی نمایش داده می‌شود.
            </p>
          </div>
          <Button type="submit" disabled={loading}>
            {loading ? (
              <Loader2 className="w-4 h-4 ml-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 ml-2" />
            )}
            ذخیره متن معرفی
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
