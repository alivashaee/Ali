import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { getSiteSettings } from '@/lib/site-settings'
import { SplashScreen } from '@/components/splash-screen'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { LandingPageClient } from '@/components/landing-page-client'

export default async function HomePage() {
  const [session, settings, blogPosts] = await Promise.all([
    getServerSession(authOptions),
    getSiteSettings(),
    db.blogPost.findMany({
      where: { published: true },
      orderBy: { createdAt: 'desc' },
      take: 6,
    }),
  ])

  return (
    <div className="min-h-screen flex flex-col">
      <SplashScreen />
      <SiteHeader
        session={session}
        logo={settings.logo}
        siteName={settings.siteName}
      />

      <main className="flex-1 pt-20">
        <LandingPageClient
          settings={{
            siteName: settings.siteName,
            description: settings.description,
            heroTitle: settings.heroTitle ?? undefined,
            heroSubtitle: settings.heroSubtitle ?? undefined,
            introVideo: settings.introVideo,
            logo: settings.logo,
            contactInfo: settings.contactInfo,
          }}
          blogPosts={blogPosts.map((p) => ({
            id: p.id,
            title: p.title,
            excerpt: p.excerpt,
            image: p.image,
            createdAt: p.createdAt.toISOString(),
          }))}
          session={session}
        />
      </main>

      <SiteFooter siteName={settings.siteName} contactInfo={settings.contactInfo} />
    </div>
  )
}
