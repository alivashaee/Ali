import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import crypto from 'crypto'
import fs from 'fs'
import path from 'path'

type Params = { params: Promise<{ token: string }> }

export async function GET(_req: Request, { params }: Params) {
  const { token } = await params
  const poll = await db.poll.findUnique({
    where: { shareToken: token },
    include: {
      options: {
        orderBy: { id: 'asc' },
      },
    },
  })

  if (!poll) {
    return NextResponse.json({ error: 'نظرسنجی یافت نشد' }, { status: 404 })
  }

  // Don't expose response counts to keep blind
  return NextResponse.json({
    id: poll.id,
    title: poll.title,
    description: poll.description,
    background: poll.background,
    buttonColor: poll.buttonColor,
    buttonShape: poll.buttonShape,
    buttonText: poll.buttonText,
    pollType: poll.pollType,
    allowFileUpload: poll.allowFileUpload,
    fileUploadLabel: poll.fileUploadLabel,
    fileUploadRequired: poll.fileUploadRequired,
    options: poll.options.map((o) => ({
      id: o.id,
      text: o.text,
      imageUrl: o.imageUrl,
    })),
  })
}

export async function POST(req: Request, { params }: Params) {
  const { token } = await params
  const poll = await db.poll.findUnique({
    where: { shareToken: token },
    include: { options: true },
  })
  if (!poll) {
    return NextResponse.json({ error: 'نظرسنجی یافت نشد' }, { status: 404 })
  }

  // Handle both JSON and multipart form data
  const contentType = req.headers.get('content-type') || ''
  let optionId: string | null = null
  let textResponse: string | null = null
  let anonymousToken: string | undefined
  let userId: string | undefined
  let fileUrl: string | null = null
  let fileName: string | null = null
  let fileType: string | null = null

  if (contentType.includes('multipart/form-data')) {
    const formData = await req.formData()
    optionId = formData.get('optionId')?.toString() || null
    textResponse = formData.get('textResponse')?.toString() || null
    anonymousToken = formData.get('anonymousToken')?.toString() || undefined
    userId = formData.get('userId')?.toString() || undefined
    const file = formData.get('file') as File | null
    if (file) {
      const ext = (file.name.split('.').pop() || 'bin').toLowerCase()
      const id = crypto.randomUUID()
      const uploadDir = path.join(process.cwd(), 'public', 'uploads')
      if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })
      const filePath = path.join(uploadDir, `${id}_${file.name.replace(/[^\w\u0600-\u06FF.\-]/g, '_')}`)
      const buffer = Buffer.from(await file.arrayBuffer())
      fs.writeFileSync(filePath, buffer)
      fileUrl = `/uploads/${id}_${file.name.replace(/[^\w\u0600-\u06FF.\-]/g, '_')}`
      fileName = file.name
      fileType = file.type
    }
  } else {
    let body: any = {}
    try {
      body = await req.json()
    } catch {
      return NextResponse.json({ error: 'بدنه درخواست نامعتبر' }, { status: 400 })
    }
    optionId = body.optionId || null
    textResponse = body.textResponse || null
    anonymousToken = body.anonymousToken
    userId = body.userId
    fileUrl = body.fileUrl || null
    fileName = body.fileName || null
    fileType = body.fileType || null
  }

  // اعتبارسنجی بر اساس نوع نظرسنجی
  const isDescriptive = poll.pollType === 'descriptive'
  if (isDescriptive) {
    if (!textResponse || textResponse.trim().length === 0) {
      return NextResponse.json(
        { error: 'پاسخ تشریحی الزامی است' },
        { status: 400 }
      )
    }
  } else {
    if (!optionId) {
      return NextResponse.json({ error: 'گزینه انتخاب نشده' }, { status: 400 })
    }
    const option = poll.options.find((o) => o.id === optionId)
    if (!option) {
      return NextResponse.json({ error: 'گزینه نامعتبر است' }, { status: 400 })
    }
  }

  // اگر آپلود فایل الزامی باشد
  if (poll.allowFileUpload && poll.fileUploadRequired && !fileUrl) {
    return NextResponse.json(
      { error: 'بارگذاری فایل الزامی است' },
      { status: 400 }
    )
  }

  // Token for anonymous dedupe
  const cookieToken = parseCookie(req.headers.get('cookie') || '')
  const anonToken =
    anonymousToken || cookieToken['poll_anon'] || cryptoToken()

  // Check if already voted (pollId + anonymousToken unique)
  const existing = await db.pollResponse.findUnique({
    where: {
      pollId_anonymousToken: { pollId: poll.id, anonymousToken: anonToken },
    },
  })

  if (existing) {
    return NextResponse.json(
      { error: 'شما قبلا در این نظرسنجی شرکت کرده‌اید', alreadyVoted: true },
      { status: 409 }
    )
  }

  try {
    await db.pollResponse.create({
      data: {
        pollId: poll.id,
        optionId: optionId || null,
        userId: userId || null,
        anonymousToken: anonToken,
        textResponse,
        fileUrl,
        fileName,
        fileType,
      },
    })
  } catch (e: any) {
    if (e?.code === 'P2002') {
      return NextResponse.json(
        { error: 'شما قبلا در این نظرسنجی شرکت کرده‌اید', alreadyVoted: true },
        { status: 409 }
      )
    }
    console.error('Poll response error:', e)
    return NextResponse.json({ error: 'خطا در ثبت پاسخ' }, { status: 500 })
  }

  const res = NextResponse.json({ ok: true, anonToken })
  res.headers.append(
    'Set-Cookie',
    `poll_anon=${anonToken}; Path=/; Max-Age=${60 * 60 * 24 * 365}; SameSite=Lax`
  )
  return res
}

function parseCookie(header: string): Record<string, string> {
  const out: Record<string, string> = {}
  if (!header) return out
  for (const part of header.split(';')) {
    const idx = part.indexOf('=')
    if (idx === -1) continue
    const k = part.slice(0, idx).trim()
    const v = part.slice(idx + 1).trim()
    out[k] = decodeURIComponent(v)
  }
  return out
}

function cryptoToken(): string {
  if (
    typeof globalThis !== 'undefined' &&
    typeof (globalThis as any).crypto?.randomUUID === 'function'
  ) {
    try {
      return (globalThis as any).crypto.randomUUID()
    } catch {
      /* fall through */
    }
  }
  return 'anon-' + Math.random().toString(36).slice(2) + Date.now().toString(36)
}
