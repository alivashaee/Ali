import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

type Params = { params: Promise<{ id: string }> }

export async function GET(_req: Request, { params }: Params) {
  const { id } = await params
  const poll = await db.poll.findUnique({
    where: { id },
    include: {
      options: {
        include: {
          _count: { select: { responses: true } },
          responses: {
            select: {
              id: true,
              fileUrl: true,
              fileName: true,
              fileType: true,
              createdAt: true,
              userId: true,
              user: { select: { name: true, username: true } },
            },
            orderBy: { createdAt: 'desc' },
          },
        },
        orderBy: { id: 'asc' },
      },
      _count: { select: { responses: true } },
    },
  })

  if (!poll) {
    return NextResponse.json({ error: 'نظرسنجی یافت نشد' }, { status: 404 })
  }

  const total = poll._count.responses
  const options = poll.options.map((o) => ({
    id: o.id,
    text: o.text,
    imageUrl: o.imageUrl,
    count: o._count.responses,
    percent: total > 0 ? Math.round((o._count.responses / total) * 100) : 0,
    // فایل‌های آپلودشده توسط مخاطبان
    files: o.responses
      .filter((r) => !!r.fileUrl)
      .map((r) => ({
        id: r.id,
        url: r.fileUrl,
        name: r.fileName,
        type: r.fileType,
        createdAt: r.createdAt.toISOString(),
        user: r.user ? r.user.name : 'مخاطب ناشناس',
      })),
  }))

  // همه فایل‌های آپلودشده به‌صورت یک لیست
  const allFiles = options.flatMap((o) => o.files.map((f) => ({ ...f, optionText: o.text })))

  return NextResponse.json({
    id: poll.id,
    title: poll.title,
    description: poll.description,
    total,
    allowFileUpload: poll.allowFileUpload,
    fileUploadLabel: poll.fileUploadLabel,
    options,
    allFiles,
  })
}
