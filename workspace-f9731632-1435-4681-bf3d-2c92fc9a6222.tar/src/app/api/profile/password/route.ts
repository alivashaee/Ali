import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { z } from 'zod'
import { db } from '@/lib/db'
import { requireAuth, type SessionUser } from '@/lib/auth-utils'

const schema = z.object({
  currentPassword: z.string().min(1, 'رمز عبور فعلی را وارد کنید'),
  newPassword: z.string().min(6, 'رمز جدید باید حداقل ۶ کاراکتر باشد'),
  confirmPassword: z.string().min(1, 'تکرار رمز را وارد کنید'),
})

export async function POST(req: NextRequest) {
  let user: SessionUser
  try {
    user = await requireAuth()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const body = await req.json().catch(() => ({}))
  const parsed = schema.safeParse(body)
  if (!parsed.success) {
    const msg = parsed.error.issues[0]?.message || 'ورودی نامعتبر'
    return NextResponse.json({ error: msg }, { status: 400 })
  }

  const { currentPassword, newPassword, confirmPassword } = parsed.data
  if (newPassword !== confirmPassword) {
    return NextResponse.json(
      { error: 'رمز جدید و تکرار آن مطابقت ندارند' },
      { status: 400 }
    )
  }

  const dbUser = await db.user.findUnique({
    where: { id: user.id },
    select: { id: true, password: true },
  })
  if (!dbUser || !dbUser.password) {
    return NextResponse.json({ error: 'کاربر یافت نشد' }, { status: 404 })
  }

  const valid = await bcrypt.compare(currentPassword, dbUser.password)
  if (!valid) {
    return NextResponse.json({ error: 'رمز عبور فعلی اشتباه است' }, { status: 400 })
  }

  const same = await bcrypt.compare(newPassword, dbUser.password)
  if (same) {
    return NextResponse.json(
      { error: 'رمز جدید نباید با رمز فعلی یکسان باشد' },
      { status: 400 }
    )
  }

  const hashed = await bcrypt.hash(newPassword, 10)
  await db.user.update({
    where: { id: user.id },
    data: { password: hashed },
  })

  return NextResponse.json({ ok: true })
}
