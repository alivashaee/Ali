import { NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/auth-utils'
import { db } from '@/lib/db'

type Params = { params: Promise<{ id: string }> }

function escapeCsv(s: string): string {
  if (!s) return ''
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`
  return s
}

function toIso(date: Date): string {
  return date.toISOString()
}

export async function GET(_req: Request, { params }: Params) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  const { id } = await params
  const poll = await db.poll.findUnique({
    where: { id },
    include: {
      options: true,
      responses: {
        orderBy: { createdAt: 'asc' },
        include: { option: true, user: { select: { name: true, username: true } } },
      },
    },
  })

  if (!poll)
    return NextResponse.json({ error: 'نظرسنجی یافت نشد' }, { status: 404 })

  const header = [
    'ردیف',
    'گزینه انتخابی',
    'کاربر (در صورت ورود)',
    'توکن ناشناس',
    'زمان پاسخ',
  ].join(',')

  const rows = poll.responses.map((r, idx) =>
    [
      String(idx + 1),
      escapeCsv(r.option?.text || ''),
      escapeCsv(r.user?.name || r.user?.username || ''),
      escapeCsv(r.anonymousToken || ''),
      toIso(r.createdAt),
    ].join(',')
  )

  const csv = '\uFEFF' + [header, ...rows].join('\r\n') // BOM for Excel + RTL
  const fileName = encodeURIComponent(
    `نظرسنجی-${poll.title}-${new Date().toISOString().slice(0, 10)}.csv`
  )

  return new NextResponse(csv, {
    status: 200,
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename*=UTF-8''${fileName}`,
    },
  })
}
