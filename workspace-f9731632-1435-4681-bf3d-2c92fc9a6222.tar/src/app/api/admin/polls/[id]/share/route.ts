import { NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/auth-utils'
import { db } from '@/lib/db'
import crypto from 'crypto'

type Params = { params: Promise<{ id: string }> }

export async function POST(_req: Request, { params }: Params) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { id } = await params
  const poll = await db.poll.findUnique({ where: { id } })
  if (!poll)
    return NextResponse.json({ error: 'نظرسنجی یافت نشد' }, { status: 404 })

  let shareToken = poll.shareToken
  if (!shareToken) {
    shareToken = crypto.randomBytes(12).toString('hex')
    await db.poll.update({
      where: { id },
      data: { shareToken },
    })
  }

  return NextResponse.json({
    token: shareToken,
    url: `/polls/${shareToken}`,
    absoluteUrl: `/polls/${shareToken}`,
  })
}

export async function DELETE(_req: Request, { params }: Params) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { id } = await params
  await db.poll.update({
    where: { id },
    data: { shareToken: null },
  })
  return NextResponse.json({ ok: true })
}
