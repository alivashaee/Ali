import { NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/auth-utils'
import { db } from '@/lib/db'

type Params = { params: Promise<{ id: string }> }

export async function GET(_req: Request, { params }: Params) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { id } = await params
  const poll = await db.poll.findUnique({
    where: { id },
    include: {
      options: {
        include: { _count: { select: { responses: true } } },
      },
      creator: { select: { name: true } },
      _count: { select: { responses: true } },
    },
  })
  if (!poll)
    return NextResponse.json({ error: 'نظرسنجی یافت نشد' }, { status: 404 })

  return NextResponse.json({
    ...poll,
    shareUrl: poll.shareToken ? `/polls/${poll.shareToken}` : null,
  })
}

export async function PATCH(req: Request, { params }: Params) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { id } = await params
  const body = await req.json()
  const {
    title,
    description,
    background,
    buttonColor,
    buttonShape,
    buttonText,
    isPublic,
    options,
  } = body || {}

  const existing = await db.poll.findUnique({
    where: { id },
    include: { options: true },
  })
  if (!existing)
    return NextResponse.json({ error: 'نظرسنجی یافت نشد' }, { status: 404 })

  const data: any = {}
  if (typeof title === 'string' && title.trim()) data.title = title.trim()
  if (typeof description === 'string') data.description = description || null
  if (typeof background === 'string') data.background = background || null
  if (typeof buttonColor === 'string') data.buttonColor = buttonColor
  if (typeof buttonShape === 'string') data.buttonShape = buttonShape
  if (typeof buttonText === 'string') data.buttonText = buttonText
  if (typeof isPublic === 'boolean') data.isPublic = isPublic

  // Update options if provided
  if (Array.isArray(options)) {
    // Remove existing options and create new ones
    await db.pollOption.deleteMany({ where: { pollId: id } })
    const clean = options
      .map((o: any) => ({
        text: String(o.text || '').trim(),
        imageUrl: o.imageUrl ? String(o.imageUrl) : null,
      }))
      .filter((o: any) => o.text)
    if (clean.length < 2) {
      return NextResponse.json(
        { error: 'حداقل دو گزینه با متن الزامی است' },
        { status: 400 }
      )
    }
    data.options = {
      create: clean,
    }
  }

  const updated = await db.poll.update({
    where: { id },
    data,
    include: { options: true },
  })

  return NextResponse.json(updated)
}

export async function DELETE(_req: Request, { params }: Params) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { id } = await params
  await db.poll.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
