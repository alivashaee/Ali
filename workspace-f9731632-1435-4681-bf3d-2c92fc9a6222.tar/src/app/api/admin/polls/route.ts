import { NextResponse } from 'next/server'
import { requireAdmin, requireCoachOrAdmin } from '@/lib/auth-utils'
import { db } from '@/lib/db'
import crypto from 'crypto'

export async function GET(req: Request) {
  try {
    await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { searchParams } = new URL(req.url)
  const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10))
  const pageSize = Math.min(
    100,
    Math.max(1, parseInt(searchParams.get('pageSize') || '20', 10))
  )
  const search = searchParams.get('search')?.trim() || ''

  const where: any = {}
  if (search) where.title = { contains: search }

  const [total, items] = await Promise.all([
    db.poll.count({ where }),
    db.poll.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        _count: { select: { responses: true, options: true } },
        creator: { select: { name: true } },
      },
    }),
  ])

  return NextResponse.json({
    items: items.map((p) => ({
      ...p,
      shareUrl: p.shareToken ? `/polls/${p.shareToken}` : null,
    })),
    total,
    page,
    pageSize,
    pages: Math.ceil(total / pageSize),
  })
}

export async function POST(req: Request) {
  try {
    // هم ادمین و هم مربی می‌توانند نظرسنجی بسازند
    const user = await requireCoachOrAdmin()
    const body = await req.json()
    const {
      title,
      description,
      background,
      buttonColor,
      buttonShape,
      buttonText,
      isPublic,
      pollType = 'multiple',
      options = [],
      autoShare = true,
      allowFileUpload = false,
      fileUploadLabel,
      fileUploadRequired = false,
    } = body || {}

    if (!title) {
      return NextResponse.json(
        { error: 'عنوان نظرسنجی الزامی است' },
        { status: 400 }
      )
    }

    // برای نوع تشریحی، گزینه‌ها اختیاری است
    const isDescriptive = pollType === 'descriptive'
    
    let cleanOptions: any[] = []
    if (!isDescriptive) {
      if (!Array.isArray(options) || options.length < 2) {
        return NextResponse.json(
          { error: 'برای نظرسنجی چندگزینه‌ای، حداقل دو گزینه الزامی است' },
          { status: 400 }
        )
      }
      cleanOptions = options
        .map((o: any) => ({
          text: String(o.text || '').trim(),
          imageUrl: o.imageUrl ? String(o.imageUrl) : null,
        }))
        .filter((o: any) => o.text)
      if (cleanOptions.length < 2) {
        return NextResponse.json(
          { error: 'حداقل دو گزینه با متن الزامی است' },
          { status: 400 }
        )
      }
    }

    const shareToken = autoShare ? crypto.randomBytes(12).toString('hex') : null

    const poll = await db.poll.create({
      data: {
        title: title.trim(),
        description: description || null,
        background: background || null,
        buttonColor: buttonColor || '#1f5130',
        buttonShape: buttonShape || 'rounded',
        buttonText: buttonText || 'ثبت پاسخ',
        isPublic: !!isPublic,
        pollType: pollType || 'multiple',
        allowFileUpload: !!allowFileUpload,
        fileUploadLabel: fileUploadLabel || null,
        fileUploadRequired: !!fileUploadRequired,
        shareToken,
        createdBy: user.id,
        options: isDescriptive ? undefined : { create: cleanOptions },
      },
      include: { options: true },
    })

    return NextResponse.json(
      {
        ...poll,
        shareUrl: poll.shareToken ? `/polls/${poll.shareToken}` : null,
      },
      { status: 201 }
    )
  } catch (e: any) {
    if (e instanceof Response) {
      return NextResponse.json(
        { error: 'دسترسی غیرمجاز' },
        { status: 403 }
      )
    }
    console.error('Create poll error:', e)
    return NextResponse.json(
      { error: 'خطا در ایجاد نظرسنجی' },
      { status: 500 }
    )
  }
}
