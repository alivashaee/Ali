import { NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/auth-utils'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

type Params = { params: Promise<{ id: string }> }

export async function GET(_req: Request, { params }: Params) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { id } = await params
  const user = await db.user.findUnique({
    where: { id },
    select: {
      id: true,
      name: true,
      username: true,
      email: true,
      phone: true,
      role: true,
      avatar: true,
      blocked: true,
      createdAt: true,
    },
  })
  if (!user)
    return NextResponse.json({ error: 'کاربر یافت نشد' }, { status: 404 })
  return NextResponse.json(user)
}

export async function PATCH(req: Request, { params }: Params) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { id } = await params
  const body = await req.json()
  const { name, role, blocked, newPassword } = body || {}

  const existing = await db.user.findUnique({ where: { id } })
  if (!existing)
    return NextResponse.json({ error: 'کاربر یافت نشد' }, { status: 404 })

  const data: any = {}
  if (typeof name === 'string' && name.trim()) data.name = name.trim()
  if (role && ['SUPER_ADMIN', 'COACH', 'MEMBER'].includes(role)) data.role = role
  if (typeof blocked === 'boolean') data.blocked = blocked

  if (newPassword && typeof newPassword === 'string' && newPassword.length >= 4) {
    data.password = await bcrypt.hash(newPassword, 10)
  }

  const updated = await db.user.update({
    where: { id },
    data,
    select: {
      id: true,
      name: true,
      username: true,
      role: true,
      blocked: true,
      updatedAt: true,
    },
  })
  return NextResponse.json(updated)
}

export async function DELETE(_req: Request, { params }: Params) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { id } = await params
  await db.user.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
