import { NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/auth-utils'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

export async function GET(req: Request) {
  try {
    await requireAdmin()
  } catch (e: any) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  const { searchParams } = new URL(req.url)
  const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10))
  const pageSize = Math.min(
    100,
    Math.max(1, parseInt(searchParams.get('pageSize') || '20', 10))
  )
  const search = searchParams.get('search')?.trim() || ''
  const role = searchParams.get('role') || ''

  const where: any = {}
  if (search) {
    where.OR = [
      { name: { contains: search } },
      { username: { contains: search } },
      { phone: { contains: search } },
      { email: { contains: search } },
    ]
  }
  if (role && ['SUPER_ADMIN', 'COACH', 'MEMBER'].includes(role)) {
    where.role = role
  }

  const [total, users] = await Promise.all([
    db.user.count({ where }),
    db.user.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
      select: {
        id: true,
        name: true,
        username: true,
        email: true,
        phone: true,
        role: true,
        avatar: true,
        blocked: true,
        createdAt: true,
      },
    }),
  ])

  return NextResponse.json({
    items: users,
    total,
    page,
    pageSize,
    pages: Math.ceil(total / pageSize),
  })
}

export async function POST(req: Request) {
  try {
    await requireAdmin()
  } catch (e: any) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  const body = await req.json()
  const { name, username, password, role, phone, email } = body || {}

  if (!name || !password) {
    return NextResponse.json(
      { error: 'نام و رمز عبور الزامی است' },
      { status: 400 }
    )
  }

  if (!['SUPER_ADMIN', 'COACH', 'MEMBER'].includes(role)) {
    return NextResponse.json({ error: 'نقش نامعتبر' }, { status: 400 })
  }

  // uniqueness check for username/phone/email
  if (username) {
    const exists = await db.user.findUnique({ where: { username } })
    if (exists) {
      return NextResponse.json(
        { error: 'این نام کاربری قبلا ثبت شده است' },
        { status: 400 }
      )
    }
  }
  if (phone) {
    const exists = await db.user.findUnique({ where: { phone } })
    if (exists) {
      return NextResponse.json(
        { error: 'این شماره موبایل قبلا ثبت شده است' },
        { status: 400 }
      )
    }
  }
  if (email) {
    const exists = await db.user.findUnique({ where: { email } })
    if (exists) {
      return NextResponse.json(
        { error: 'این ایمیل قبلا ثبت شده است' },
        { status: 400 }
      )
    }
  }

  const hashed = await bcrypt.hash(password, 10)

  const user = await db.user.create({
    data: {
      name,
      username: username || null,
      password: hashed,
      role,
      phone: phone || null,
      email: email || null,
    },
    select: {
      id: true,
      name: true,
      username: true,
      role: true,
      createdAt: true,
    },
  })

  return NextResponse.json(user, { status: 201 })
}
