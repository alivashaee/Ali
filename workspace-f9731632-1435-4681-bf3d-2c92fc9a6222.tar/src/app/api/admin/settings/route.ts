import { NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/auth-utils'
import { db } from '@/lib/db'

export async function GET() {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const settings = await db.siteSettings.findUnique({
    where: { id: 'singleton' },
  })
  if (!settings)
    return NextResponse.json({ error: 'تنظیمات یافت نشد' }, { status: 404 })
  return NextResponse.json(settings)
}

export async function PUT(req: Request) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const body = await req.json()
  const {
    siteName,
    description,
    introVideo,
    logo,
    contactInfo,
    heroTitle,
    heroSubtitle,
  } = body || {}

  const existing = await db.siteSettings.findUnique({
    where: { id: 'singleton' },
  })

  const data: any = {}
  if (typeof siteName === 'string' && siteName.trim()) data.siteName = siteName.trim()
  if (typeof description === 'string') data.description = description
  if (typeof introVideo === 'string') data.introVideo = introVideo || null
  if (typeof logo === 'string') data.logo = logo || null
  if (typeof contactInfo === 'string') data.contactInfo = contactInfo || null
  if (typeof heroTitle === 'string') data.heroTitle = heroTitle || null
  if (typeof heroSubtitle === 'string') data.heroSubtitle = heroSubtitle || null

  let settings
  if (!existing) {
    settings = await db.siteSettings.create({
      data: {
        id: 'singleton',
        siteName: siteName || 'موسسه رویش‌های پیشران',
        description: description || '',
        ...data,
      },
    })
  } else {
    settings = await db.siteSettings.update({
      where: { id: 'singleton' },
      data,
    })
  }

  return NextResponse.json(settings)
}
