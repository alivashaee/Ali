import { NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/auth-utils'
import { db } from '@/lib/db'

type Params = { params: Promise<{ id: string }> }

export async function GET(_req: Request, { params }: Params) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { id } = await params
  const post = await db.blogPost.findUnique({ where: { id } })
  if (!post)
    return NextResponse.json({ error: 'پست یافت نشد' }, { status: 404 })
  return NextResponse.json(post)
}

export async function PATCH(req: Request, { params }: Params) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { id } = await params
  const body = await req.json()
  const { title, excerpt, content, image, published } = body || {}

  const existing = await db.blogPost.findUnique({
    where: { id },
  })
  if (!existing)
    return NextResponse.json({ error: 'پست یافت نشد' }, { status: 404 })

  const data: any = {}
  if (typeof title === 'string' && title.trim()) data.title = title.trim()
  if (typeof excerpt === 'string') data.excerpt = excerpt || null
  if (typeof content === 'string' && content.trim()) data.content = content
  if (typeof image === 'string') data.image = image || null
  if (typeof published === 'boolean') data.published = published

  const updated = await db.blogPost.update({
    where: { id },
    data,
  })
  return NextResponse.json(updated)
}

export async function DELETE(_req: Request, { params }: Params) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { id } = await params
  await db.blogPost.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
