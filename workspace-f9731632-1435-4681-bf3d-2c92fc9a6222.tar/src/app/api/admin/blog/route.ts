import { NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/auth-utils'
import { db } from '@/lib/db'

export async function GET(req: Request) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const { searchParams } = new URL(req.url)
  const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10))
  const pageSize = Math.min(
    100,
    Math.max(1, parseInt(searchParams.get('pageSize') || '20', 10))
  )
  const search = searchParams.get('search')?.trim() || ''
  const publishedOnly =
    searchParams.get('published') === 'true' ? true : undefined

  const where: any = {}
  if (search) where.title = { contains: search }
  if (publishedOnly === true) where.published = true

  const [total, items] = await Promise.all([
    db.blogPost.count({ where }),
    db.blogPost.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
  ])

  return NextResponse.json({
    items,
    total,
    page,
    pageSize,
    pages: Math.ceil(total / pageSize),
  })
}

export async function POST(req: Request) {
  try {
    await requireAdmin()
  } catch {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }
  const body = await req.json()
  const { title, excerpt, content, image, published } = body || {}

  if (!title || !content) {
    return NextResponse.json(
      { error: 'عنوان و محتوا الزامی است' },
      { status: 400 }
    )
  }

  const post = await db.blogPost.create({
    data: {
      title,
      excerpt: excerpt || null,
      content,
      image: image || null,
      published: typeof published === 'boolean' ? published : true,
    },
  })

  return NextResponse.json(post, { status: 201 })
}
