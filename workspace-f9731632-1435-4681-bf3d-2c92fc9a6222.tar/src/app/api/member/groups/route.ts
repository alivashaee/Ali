import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, type SessionUser } from '@/lib/auth-utils'

/**
 * Member panel uses a single-group architecture too.
 * - GET: returns the member's single group (the first group they are a member of).
 *        For coaches/admins viewing the member panel, returns their owned group or first membership.
 *        Returns `{ group: null }` if they are not in any group yet.
 */
export async function GET() {
  let user: SessionUser
  try {
    user = await requireAuth()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  // Try owned group first (for coaches), then any membership
  const owned = await db.group.findFirst({
    where: { coachId: user.id },
    select: {
      id: true,
      name: true,
      description: true,
      createdAt: true,
      coach: { select: { id: true, name: true } },
      _count: { select: { members: true, messages: true, summaries: true } },
    },
  })

  if (owned) {
    return NextResponse.json({ group: owned })
  }

  const membership = await db.groupMember.findFirst({
    where: { userId: user.id },
    orderBy: { joinedAt: 'desc' },
    select: {
      group: {
        select: {
          id: true,
          name: true,
          description: true,
          createdAt: true,
          coach: { select: { id: true, name: true } },
          _count: { select: { members: true, messages: true, summaries: true } },
        },
      },
    },
  })

  return NextResponse.json({ group: membership?.group ?? null })
}
