import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, canAccessGroup, type SessionUser } from '@/lib/auth-utils'

type Params = { params: Promise<{ id: string }> }

export async function GET(_req: Request, { params }: Params) {
  let user: SessionUser
  try {
    user = await requireAuth()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const { id } = await params
  const summary = await db.meetingSummary.findUnique({
    where: { id },
    select: {
      id: true,
      groupId: true,
      audioUrl: true,
      transcript: true,
      summary: true,
      status: true,
      createdAt: true,
      group: { select: { id: true, name: true } },
    },
  })

  if (!summary) {
    return NextResponse.json({ error: 'خلاصه یافت نشد' }, { status: 404 })
  }

  const ok = await canAccessGroup(user.id, summary.groupId)
  if (!ok) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  return NextResponse.json({ summary })
}
