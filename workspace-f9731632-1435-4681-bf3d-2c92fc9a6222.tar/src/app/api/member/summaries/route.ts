import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, type SessionUser } from '@/lib/auth-utils'

export async function GET(req: NextRequest) {
  let user: SessionUser
  try {
    user = await requireAuth()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const isMember = user.role === 'MEMBER'

  const url = new URL(req.url)
  const groupId = url.searchParams.get('groupId')

  const baseWhere = isMember
    ? { group: { members: { some: { userId: user.id } } } }
    : {
        OR: [
          { group: { coachId: user.id } },
          { group: { members: { some: { userId: user.id } } } },
        ],
      }

  const where = {
    ...baseWhere,
    status: 'completed' as const,
    ...(groupId ? { groupId } : {}),
  }

  const summaries = await db.meetingSummary.findMany({
    where,
    select: {
      id: true,
      audioUrl: true,
      createdAt: true,
      summary: true,
      group: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 200,
  })

  return NextResponse.json({ summaries })
}
