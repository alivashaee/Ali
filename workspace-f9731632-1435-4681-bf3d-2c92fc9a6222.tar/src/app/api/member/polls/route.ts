import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, type SessionUser } from '@/lib/auth-utils'

export async function GET() {
  let user: SessionUser
  try {
    user = await requireAuth()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  // Show public polls and any created by admin
  const polls = await db.poll.findMany({
    where: {
      OR: [{ isPublic: true }, { createdBy: user.id }],
    },
    select: {
      id: true,
      title: true,
      description: true,
      isPublic: true,
      createdAt: true,
      _count: { select: { responses: true } },
      options: {
        select: {
          id: true,
          text: true,
          _count: { select: { responses: true } },
        },
      },
    },
    orderBy: { createdAt: 'desc' },
  })

  // Has the user voted?
  const userResponses = await db.pollResponse.findMany({
    where: { userId: user.id, pollId: { in: polls.map((p) => p.id) } },
    select: { pollId: true, optionId: true },
  })
  const voted = new Map(userResponses.map((r) => [r.pollId, r.optionId]))

  return NextResponse.json({
    polls: polls.map((p) => ({
      ...p,
      userVotedOptionId: voted.get(p.id) || null,
    })),
  })
}
