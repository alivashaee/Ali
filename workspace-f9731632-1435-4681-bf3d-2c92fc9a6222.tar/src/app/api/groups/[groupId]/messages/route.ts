import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, canAccessGroup } from '@/lib/auth-utils'

export const dynamic = 'force-dynamic'

interface RawMessage {
  id: string
  groupId: string
  senderId: string
  content: string | null
  fileUrl: string | null
  fileType: string | null
  fileName: string | null
  reactions: string | null
  createdAt: Date
  sender: {
    id: string
    name: string
    avatar: string | null
  } | null
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ groupId: string }> },
) {
  try {
    const user = await requireAuth()
    const { groupId } = await params

    if (!groupId) {
      return NextResponse.json({ error: 'شناسه گروه الزامی است' }, { status: 400 })
    }

    const allowed = await canAccessGroup(user.id, groupId)
    if (!allowed) {
      return NextResponse.json(
        { error: 'شما به این گروه دسترسی ندارید' },
        { status: 403 },
      )
    }

    const url = new URL(req.url)
    const limitParam = url.searchParams.get('limit')
    const limit = Math.min(Math.max(Number(limitParam) || 50, 1), 200)
    const beforeParam = url.searchParams.get('before')
    const before = beforeParam ? new Date(beforeParam) : undefined
    if (beforeParam && (!before || Number.isNaN(before.getTime()))) {
      return NextResponse.json(
        { error: 'پارامتر before نامعتبر است' },
        { status: 400 },
      )
    }

    const messages = (await db.message.findMany({
      where: {
        groupId,
        ...(before ? { createdAt: { lt: before } } : {}),
      },
      include: {
        sender: {
          select: { id: true, name: true, avatar: true },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })) as RawMessage[]

    const data = messages.reverse().map((m) => {
      let reactions: Record<string, string[]> = {}
      if (m.reactions) {
        try {
          const parsed = JSON.parse(m.reactions)
          if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
            reactions = parsed as Record<string, string[]>
          }
        } catch {
          reactions = {}
        }
      }
      return {
        id: m.id,
        groupId: m.groupId,
        senderId: m.senderId,
        senderName: m.sender?.name ?? 'کاربر حذف‌شده',
        senderAvatar: m.sender?.avatar ?? null,
        content: m.content,
        fileUrl: m.fileUrl,
        fileType: m.fileType,
        fileName: m.fileName,
        reactions,
        createdAt: m.createdAt.toISOString(),
      }
    })

    const oldest = data[0]
    const nextCursor = oldest ? oldest.createdAt : null

    return NextResponse.json({
      groupId,
      messages: data,
      nextCursor,
      hasMore: data.length === limit,
    })
  } catch (e) {
    if (e instanceof Response) {
      const status = e.status || 401
      try {
        const body = await e.json()
        return NextResponse.json(
          { error: body.error ?? 'احراز هویت نشده' },
          { status },
        )
      } catch {
        return NextResponse.json({ error: 'احراز هویت نشده' }, { status })
      }
    }
    const message = e instanceof Error ? e.message : 'خطا در دریافت پیام‌ها'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
