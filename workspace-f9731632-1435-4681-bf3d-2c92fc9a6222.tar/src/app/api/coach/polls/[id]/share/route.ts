export { POST } from '@/app/api/admin/polls/[id]/share/route'
