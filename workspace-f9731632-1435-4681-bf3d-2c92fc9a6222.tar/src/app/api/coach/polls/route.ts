// Re-export from /api/admin/polls since both admins and coaches can create polls
export { GET, POST } from '@/app/api/admin/polls/route'
