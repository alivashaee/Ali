import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireCoachOrAdmin, isCoachOfGroup, type SessionUser } from '@/lib/auth-utils'

type Params = { params: Promise<{ id: string }> }

export async function GET(_req: NextRequest, { params }: Params) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const { id } = await params
  const group = await db.group.findUnique({
    where: { id },
    select: {
      id: true,
      name: true,
      description: true,
      createdAt: true,
      coach: { select: { id: true, name: true } },
      _count: { select: { members: true, messages: true, summaries: true } },
    },
  })

  if (!group) {
    return NextResponse.json({ error: 'گروه یافت نشد' }, { status: 404 })
  }

  const owns =
    user.role === 'SUPER_ADMIN' || (await isCoachOfGroup(user.id, group.id))
  if (!owns) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  return NextResponse.json({ group })
}

export async function PATCH(req: NextRequest, { params }: Params) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const { id } = await params
  const group = await db.group.findUnique({ where: { id }, select: { id: true, coachId: true } })
  if (!group) {
    return NextResponse.json({ error: 'گروه یافت نشد' }, { status: 404 })
  }
  const owns =
    user.role === 'SUPER_ADMIN' || (await isCoachOfGroup(user.id, group.id))
  if (!owns) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  const body = await req.json().catch(() => ({}))
  const data: { name?: string; description?: string | null } = {}
  if (typeof body.name === 'string' && body.name.trim()) {
    data.name = body.name.trim()
  }
  if (typeof body.description === 'string') {
    data.description = body.description.trim() || null
  }

  const updated = await db.group.update({
    where: { id },
    data,
    select: { id: true, name: true, description: true, createdAt: true },
  })

  return NextResponse.json({ group: updated })
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const { id } = await params
  const group = await db.group.findUnique({ where: { id }, select: { id: true, coachId: true } })
  if (!group) {
    return NextResponse.json({ error: 'گروه یافت نشد' }, { status: 404 })
  }
  const owns =
    user.role === 'SUPER_ADMIN' || (await isCoachOfGroup(user.id, group.id))
  if (!owns) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  await db.group.delete({ where: { id } })

  return NextResponse.json({ ok: true })
}
