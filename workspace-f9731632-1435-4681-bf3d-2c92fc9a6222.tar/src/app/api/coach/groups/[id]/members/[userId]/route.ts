import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireCoachOrAdmin, isCoachOfGroup, type SessionUser } from '@/lib/auth-utils'

type Params = { params: Promise<{ id: string; userId: string }> }

export async function DELETE(_req: NextRequest, { params }: Params) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const { id, userId } = await params
  const owns =
    user.role === 'SUPER_ADMIN' || (await isCoachOfGroup(user.id, id))
  if (!owns) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  const member = await db.groupMember.findUnique({
    where: { groupId_userId: { groupId: id, userId } },
    select: { id: true },
  })
  if (!member) {
    return NextResponse.json({ error: 'عضو یافت نشد' }, { status: 404 })
  }

  await db.groupMember.delete({
    where: { groupId_userId: { groupId: id, userId } },
  })

  return NextResponse.json({ ok: true })
}
