import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'
import { requireCoachOrAdmin, isCoachOfGroup, type SessionUser } from '@/lib/auth-utils'

type Params = { params: Promise<{ id: string }> }

export async function GET(_req: NextRequest, { params }: Params) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const { id } = await params
  const owns =
    user.role === 'SUPER_ADMIN' || (await isCoachOfGroup(user.id, id))
  if (!owns) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  const members = await db.groupMember.findMany({
    where: { groupId: id },
    select: {
      id: true,
      joinedAt: true,
      user: {
        select: {
          id: true,
          name: true,
          username: true,
          role: true,
          avatar: true,
        },
      },
    },
    orderBy: { joinedAt: 'asc' },
  })

  return NextResponse.json({ members })
}

export async function POST(req: NextRequest, { params }: Params) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const { id } = await params
  const owns =
    user.role === 'SUPER_ADMIN' || (await isCoachOfGroup(user.id, id))
  if (!owns) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  const body = await req.json().catch(() => ({}))
  const name: string = (body.name || '').trim()
  const username: string = (body.username || '').trim()
  const password: string | undefined = body.password ? String(body.password) : undefined
  const mode: 'create' | 'existing' = body.mode === 'existing' ? 'existing' : 'create'

  if (!name && mode === 'create') {
    return NextResponse.json({ error: 'نام عضو الزامی است' }, { status: 400 })
  }
  if (!username) {
    return NextResponse.json({ error: 'نام کاربری الزامی است' }, { status: 400 })
  }

  // Look up existing user by username
  const existingUser = await db.user.findFirst({
    where: { OR: [{ username }, { phone: username }] },
  })

  let userId: string
  if (existingUser) {
    if (mode === 'create') {
      return NextResponse.json(
        { error: 'این نام کاربری قبلاً ثبت شده است. لطفاً گزینه «افزودن عضو موجود» را انتخاب کنید.' },
        { status: 409 }
      )
    }
    userId = existingUser.id
  } else {
    if (mode === 'existing') {
      return NextResponse.json(
        { error: 'کاربری با این نام کاربری یافت نشد' },
        { status: 404 }
      )
    }
    if (!password) {
      return NextResponse.json(
        { error: 'برای کاربر جدید، رمز عبور الزامی است' },
        { status: 400 }
      )
    }
    const hashed = await bcrypt.hash(password, 10)
    const newUser = await db.user.create({
      data: {
        name,
        username,
        password: hashed,
        role: 'MEMBER',
      },
    })
    userId = newUser.id
  }

  // Add to group (idempotent)
  try {
    await db.groupMember.create({
      data: { groupId: id, userId },
    })
  } catch (e: any) {
    // Already a member
  }

  const member = await db.groupMember.findUnique({
    where: { groupId_userId: { groupId: id, userId } },
    select: {
      id: true,
      joinedAt: true,
      user: {
        select: { id: true, name: true, username: true, role: true, avatar: true },
      },
    },
  })

  return NextResponse.json({ member }, { status: 201 })
}
