import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireCoachOrAdmin, type SessionUser } from '@/lib/auth-utils'

/**
 * Each coach has ONLY ONE group (single-group architecture).
 * - GET: returns the coach's single group (or `null` if none).
 *        For SUPER_ADMIN we still return only their own group (if any)
 *        since admins manage all groups from `/admin/groups`.
 * - POST: creates the coach's single group. Returns 400 if they already have one.
 */
export async function GET() {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const group = await db.group.findFirst({
    where: { coachId: user.id },
    select: {
      id: true,
      name: true,
      description: true,
      createdAt: true,
      coach: { select: { id: true, name: true } },
      _count: { select: { members: true, messages: true, summaries: true } },
    },
  })

  return NextResponse.json({ group })
}

export async function POST(req: NextRequest) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  // Enforce single-group-per-coach rule
  const existing = await db.group.findFirst({
    where: { coachId: user.id },
    select: { id: true },
  })
  if (existing) {
    return NextResponse.json(
      { error: 'شما قبلاً یک گروه ساخته‌اید. هر مربی فقط می‌تواند یک گروه داشته باشد.' },
      { status: 400 },
    )
  }

  const body = await req.json().catch(() => ({}))
  const name: string = (body.name || '').trim()
  const description: string | null = body.description ? String(body.description).trim() : null

  if (!name) {
    return NextResponse.json({ error: 'نام گروه الزامی است' }, { status: 400 })
  }

  const group = await db.group.create({
    data: {
      name,
      description,
      coachId: user.id,
    },
    select: {
      id: true,
      name: true,
      description: true,
      createdAt: true,
    },
  })

  return NextResponse.json({ group }, { status: 201 })
}
