import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireCoachOrAdmin, type SessionUser } from '@/lib/auth-utils'

type Params = { params: Promise<{ id: string }> }

export async function GET(_req: NextRequest, { params }: Params) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const { id } = await params
  const summary = await db.meetingSummary.findUnique({
    where: { id },
    select: {
      id: true,
      groupId: true,
      audioUrl: true,
      transcript: true,
      summary: true,
      status: true,
      createdAt: true,
      updatedAt: true,
      group: { select: { id: true, name: true } },
    },
  })

  if (!summary) {
    return NextResponse.json({ error: 'خلاصه یافت نشد' }, { status: 404 })
  }

  // Verify ownership: super_admin OR coach of the group
  if (user.role !== 'SUPER_ADMIN') {
    const group = await db.group.findUnique({
      where: { id: summary.groupId },
      select: { coachId: true },
    })
    if (!group || group.coachId !== user.id) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
    }
  }

  return NextResponse.json({ summary })
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const { id } = await params
  const summary = await db.meetingSummary.findUnique({
    where: { id },
    select: { id: true, groupId: true, audioUrl: true },
  })
  if (!summary) {
    return NextResponse.json({ error: 'خلاصه یافت نشد' }, { status: 404 })
  }

  if (user.role !== 'SUPER_ADMIN') {
    const group = await db.group.findUnique({
      where: { id: summary.groupId },
      select: { coachId: true },
    })
    if (!group || group.coachId !== user.id) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
    }
  }

  // Try to delete the audio file (best effort)
  try {
    const fs = await import('fs/promises')
    const path = await import('path')
    const audioPath = path.join(process.cwd(), 'public', summary.audioUrl.replace(/^\//, ''))
    await fs.unlink(audioPath)
  } catch {
    // Ignore file errors
  }

  await db.meetingSummary.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
