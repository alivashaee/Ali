import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireCoachOrAdmin, type SessionUser } from '@/lib/auth-utils'
import { toPersianDigits } from '@/lib/format-jalali'

type Params = { params: Promise<{ id: string }> }

const PERSIAN_MONTHS = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
]

function getPersianDate(date: Date): string {
  try {
    const fmt = new Intl.DateTimeFormat('en-US-u-ca-persian', {
      year: 'numeric', month: 'numeric', day: 'numeric',
    })
    const parts = fmt.formatToParts(date)
    const y = parts.find((p) => p.type === 'year')?.value || ''
    const m = parts.find((p) => p.type === 'month')?.value || ''
    const d = parts.find((p) => p.type === 'day')?.value || ''
    const monthName = PERSIAN_MONTHS[parseInt(m, 10) - 1] || m
    return `${toPersianDigits(d)} ${monthName} ${toPersianDigits(y)}`
  } catch {
    return date.toLocaleDateString('fa-IR')
  }
}

function buildHtmlDocument(title: string, dateStr: string, audioUrl: string, transcript: string | null, summary: string | null): string {
  const escape = (s: string) => s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')

  const htmlEscape = (s: string) => escape(s).replace(/\n/g, '<br>')

  // Convert basic markdown to HTML (headings, bold, lists, paragraphs)
  function mdToHtml(md: string): string {
    const lines = escape(md).split(/\n/)
    let html = ''
    let inList = false
    for (const raw of lines) {
      const line = raw.replace(/\r$/, '')
      if (/^###\s+/.test(line)) {
        if (inList) { html += '</ul>'; inList = false }
        html += `<h3>${line.replace(/^###\s+/, '')}</h3>`
      } else if (/^##\s+/.test(line)) {
        if (inList) { html += '</ul>'; inList = false }
        html += `<h2>${line.replace(/^##\s+/, '')}</h2>`
      } else if (/^#\s+/.test(line)) {
        if (inList) { html += '</ul>'; inList = false }
        html += `<h1>${line.replace(/^#\s+/, '')}</h1>`
      } else if (/^[-*]\s+/.test(line)) {
        if (!inList) { html += '<ul>'; inList = true }
        html += `<li>${line.replace(/^[-*]\s+/, '')}</li>`
      } else if (/^\d+\.\s+/.test(line)) {
        if (!inList) { html += '<ol>'; inList = true }
        html += `<li>${line.replace(/^\d+\.\s+/, '')}</li>`
      } else if (line.trim() === '') {
        if (inList) { html += '</ul>'; inList = false }
        html += '<br/>'
      } else {
        if (inList) { html += '</ul>'; inList = false }
        html += `<p>${line}</p>`
      }
    }
    if (inList) html += '</ul>'
    return html
  }

  return `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>${escape(title)} — خلاصه جلسه</title>
<style>
  body { font-family: 'Vazirmatn', Tahoma, sans-serif; color: #2a1f10; background: #fff; padding: 40px; max-width: 800px; margin: 0 auto; line-height: 1.8; }
  h1, h2, h3 { color: #1f5130; }
  h1 { font-size: 28px; border-bottom: 3px solid #1f5130; padding-bottom: 8px; margin-top: 0; }
  h2 { font-size: 22px; margin-top: 28px; }
  h3 { font-size: 18px; margin-top: 20px; }
  .meta { color: #555; font-size: 14px; margin-bottom: 24px; }
  .section { margin-top: 36px; padding: 16px 20px; background: #faf6ec; border-right: 5px solid #c7a008; border-radius: 8px; }
  .section h2 { margin-top: 0; }
  audio { width: 100%; margin-top: 12px; }
  ul, ol { padding-right: 24px; }
  li { margin-bottom: 6px; }
  p { margin: 8px 0; }
  .branding { text-align: center; margin-top: 36px; padding-top: 16px; border-top: 1px solid #e0d5b8; color: #888; font-size: 12px; }
</style>
</head>
<body>
  <h1>${escape(title)} — خلاصه جلسه</h1>
  <div class="meta">تاریخ: ${escape(dateStr)}</div>
  <audio controls src="${escape(audioUrl)}"></audio>

  ${summary ? `<div class="section"><h2>خلاصه</h2>${mdToHtml(summary)}</div>` : ''}
  ${transcript ? `<div class="section"><h2>ترانسکریپت کامل</h2><div style="white-space: pre-wrap;">${htmlEscape(transcript)}</div></div>` : ''}

  <div class="branding">موسسه تربیتی رویش‌های پیشران — تولید شده توسط هوش مصنوعی</div>
</body>
</html>`
}

export async function GET(req: NextRequest, { params }: Params) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const { id } = await params
  const summary = await db.meetingSummary.findUnique({
    where: { id },
    select: {
      id: true,
      groupId: true,
      audioUrl: true,
      transcript: true,
      summary: true,
      status: true,
      createdAt: true,
      group: { select: { name: true } },
    },
  })

  if (!summary) {
    return NextResponse.json({ error: 'خلاصه یافت نشد' }, { status: 404 })
  }

  if (user.role !== 'SUPER_ADMIN') {
    const group = await db.group.findUnique({
      where: { id: summary.groupId },
      select: { coachId: true },
    })
    if (!group || group.coachId !== user.id) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
    }
  }

  const url = new URL(req.url)
  const format = (url.searchParams.get('format') || 'markdown').toLowerCase()
  const title = summary.group?.name || 'گروه'
  const dateStr = getPersianDate(summary.createdAt)

  if (format === 'pdf') {
    const html = buildHtmlDocument(title, dateStr, summary.audioUrl, summary.transcript, summary.summary)
    return new NextResponse(html, {
      status: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Disposition': `inline; filename="summary-${summary.id}.html"`,
      },
    })
  }

  // Markdown
  let md = `# ${title} — خلاصه جلسه\n\n`
  md += `**تاریخ:** ${dateStr}\n\n`
  md += `**فایل صوتی:** ${summary.audioUrl}\n\n`
  md += `---\n\n`
  if (summary.summary) {
    md += `## خلاصه\n\n${summary.summary}\n\n---\n\n`
  }
  if (summary.transcript) {
    md += `## ترانسکریپت کامل\n\n${summary.transcript}\n`
  }

  return new NextResponse(md, {
    status: 200,
    headers: {
      'Content-Type': 'text/markdown; charset=utf-8',
      'Content-Disposition': `attachment; filename="summary-${summary.id}.md"`,
    },
  })
}
