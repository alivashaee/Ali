import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireCoachOrAdmin, type SessionUser } from '@/lib/auth-utils'

type Params = { params: Promise<{ id: string }> }

export async function GET(_req: NextRequest, { params }: Params) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const { id } = await params
  const summary = await db.meetingSummary.findUnique({
    where: { id },
    select: { id: true, status: true, groupId: true },
  })

  if (!summary) {
    return NextResponse.json({ error: 'خلاصه یافت نشد' }, { status: 404 })
  }

  if (user.role !== 'SUPER_ADMIN') {
    const group = await db.group.findUnique({
      where: { id: summary.groupId },
      select: { coachId: true },
    })
    if (!group || group.coachId !== user.id) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
    }
  }

  return NextResponse.json({ status: summary.status })
}
