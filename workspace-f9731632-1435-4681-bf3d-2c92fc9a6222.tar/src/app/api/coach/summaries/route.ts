import { NextRequest, NextResponse } from 'next/server'
import { after } from 'next/server'
import { db } from '@/lib/db'
import { requireCoachOrAdmin, isCoachOfGroup, type SessionUser } from '@/lib/auth-utils'
import { generateMeetingSummary } from '@/lib/ai-summary'

export async function GET(req: NextRequest) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const url = new URL(req.url)
  const groupId = url.searchParams.get('groupId')
  const where = user.role === 'SUPER_ADMIN'
    ? (groupId ? { groupId } : {})
    : { group: { coachId: user.id }, ...(groupId ? { groupId } : {}) }

  const summaries = await db.meetingSummary.findMany({
    where,
    select: {
      id: true,
      groupId: true,
      audioUrl: true,
      status: true,
      createdAt: true,
      updatedAt: true,
      group: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 200,
  })

  return NextResponse.json({ summaries })
}

export async function POST(req: NextRequest) {
  let user: SessionUser
  try {
    user = await requireCoachOrAdmin()
  } catch {
    return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
  }

  const body = await req.json().catch(() => ({}))
  const groupId: string = (body.groupId || '').trim()
  const audioUrl: string = (body.audioUrl || '').trim()

  if (!groupId || !audioUrl) {
    return NextResponse.json(
      { error: 'شناسه گروه و آدرس فایل صوتی الزامی هستند' },
      { status: 400 }
    )
  }

  const owns =
    user.role === 'SUPER_ADMIN' || (await isCoachOfGroup(user.id, groupId))
  if (!owns) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  // Verify the audio URL is local (under /uploads/)
  if (!audioUrl.startsWith('/uploads/')) {
    return NextResponse.json(
      { error: 'فقط فایل‌های آپلود شده در سیستم قابل استفاده هستند' },
      { status: 400 }
    )
  }

  const summary = await db.meetingSummary.create({
    data: {
      groupId,
      audioUrl,
      status: 'pending',
    },
    select: {
      id: true,
      groupId: true,
      audioUrl: true,
      status: true,
      createdAt: true,
    },
  })

  // Kick off background processing (fire and forget)
  after(async () => {
    try {
      await generateMeetingSummary(summary.id)
    } catch (err) {
      console.error('AI summary background error:', err)
      try {
        await db.meetingSummary.update({
          where: { id: summary.id },
          data: { status: 'failed' },
        })
      } catch {}
    }
  })

  return NextResponse.json({ summary }, { status: 202 })
}
