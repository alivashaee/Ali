'use client'

import { useState, Suspense } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter, useSearchParams } from 'next/navigation'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2, LogIn, User, Lock, ArrowRight } from 'lucide-react'
import Link from 'next/link'

function LoginInner() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const callbackUrl = searchParams.get('callbackUrl') || '/'

  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubmit(e?: React.FormEvent) {
    if (e) e.preventDefault()
    if (!username || !password) return
    setLoading(true)
    setError(null)

    try {
      const res = await signIn('credentials', {
        username,
        password,
        redirect: false,
      })

      if (res?.error) {
        setError('نام کاربری یا رمز عبور اشتباه است')
        setLoading(false)
        return
      }

      // Fetch user role to redirect appropriately
      const r = await fetch('/api/auth/session')
      const data = await r.json()
      const role = data?.user?.role
      const target =
        role === 'SUPER_ADMIN' ? '/admin' : role === 'COACH' ? '/coach' : role === 'MEMBER' ? '/member' : callbackUrl
      router.push(target)
      router.refresh()
    } catch (err) {
      setError('خطایی رخ داد. دوباره تلاش کنید.')
      setLoading(false)
    }
  }

  // Click handler that calls submit directly (as a fallback when form onSubmit isn't triggered by some browsers)
  function handleButtonClick(e: React.MouseEvent) {
    e.preventDefault()
    handleSubmit()
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center gradient-hero px-4 py-16">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-6">
          <img
            src="/institute-logo-final.png"
            alt="لوگوی موسسه رویش‌های پیشران"
            className="w-48 h-auto mx-auto object-contain drop-shadow-lg"
          />
          <h1 className="mt-4 text-2xl font-bold text-primary">ورود به حساب کاربری</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            موسسه رویش‌های پیشران
          </p>
        </div>

        <Card className="border-accent/20 shadow-xl bg-card/80 backdrop-blur">
          <CardHeader>
            <CardTitle className="text-primary flex items-center gap-2">
              <LogIn className="w-5 h-5" />
              ورود
            </CardTitle>
            <CardDescription>
              نام کاربری و رمز عبور خود را وارد کنید
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="username" className="flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5" />
                  نام کاربری یا شماره موبایل
                </Label>
                <Input
                  id="username"
                  type="text"
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  dir="ltr"
                  className="text-right"
                  placeholder="مثلاً: adminro"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5" />
                  رمز عبور
                </Label>
                <Input
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  dir="ltr"
                  className="text-right"
                />
              </div>
            </CardContent>
            <CardFooter className="flex-col gap-3">
              <Button
                type="submit"
                className="w-full rounded-full"
                disabled={loading || !username || !password}
                onClick={handleButtonClick}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                    در حال ورود...
                  </>
                ) : (
                  <>
                    ورود به حساب
                    <ArrowRight className="w-4 h-4 mr-2" />
                  </>
                )}
              </Button>
              <Button asChild variant="link" size="sm">
                <Link href="/">بازگشت به صفحه اصلی</Link>
              </Button>
            </CardFooter>
          </form>
        </Card>

        <div className="mt-4 text-center text-xs text-muted-foreground">
          <p>برای دریافت حساب کاربری، با مربی گروه خود تماس بگیرید.</p>
        </div>
      </motion.div>
    </div>
  )
}

export default function LoginPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    }>
      <LoginInner />
    </Suspense>
  )
}
