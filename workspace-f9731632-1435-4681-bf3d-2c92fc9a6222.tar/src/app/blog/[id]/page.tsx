import { notFound } from 'next/navigation'
import Link from 'next/link'
import { ArrowRight, Calendar } from 'lucide-react'
import { db } from '@/lib/db'
import { getSiteSettings } from '@/lib/site-settings'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { Button } from '@/components/ui/button'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import ReactMarkdown from 'react-markdown'

export default async function BlogPostPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const [post, session, settings] = await Promise.all([
    db.blogPost.findUnique({ where: { id } }),
    getServerSession(authOptions),
    getSiteSettings(),
  ])

  if (!post || !post.published) {
    notFound()
  }

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader session={session} logo={settings.logo} siteName={settings.siteName} />
      <main className="flex-1 pt-20 max-w-3xl mx-auto px-4 py-10 w-full">
        <Button asChild variant="ghost" size="sm" className="mb-4">
          <Link href="/#blog">
            <ArrowRight className="w-4 h-4 ml-1" />
            بازگشت به وبلاگ
          </Link>
        </Button>

        <article>
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3">
            <Calendar className="w-3 h-3" />
            {new Date(post.createdAt).toLocaleDateString('fa-IR')}
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-primary mb-4">{post.title}</h1>
          {post.excerpt && (
            <p className="text-base md:text-lg text-muted-foreground mb-6 leading-relaxed">
              {post.excerpt}
            </p>
          )}
          {post.image && (
            <img
              src={post.image}
              alt={post.title}
              className="w-full aspect-video object-cover rounded-2xl mb-8 shadow-lg"
            />
          )}
          <div className="prose prose-spiritual max-w-none text-foreground/90 leading-relaxed">
            <ReactMarkdown
              components={{
                h1: ({ node, ...props }) => <h1 className="text-2xl font-bold text-primary mt-6 mb-3" {...props} />,
                h2: ({ node, ...props }) => <h2 className="text-xl font-bold text-primary mt-6 mb-3" {...props} />,
                h3: ({ node, ...props }) => <h3 className="text-lg font-semibold text-primary mt-4 mb-2" {...props} />,
                p: ({ node, ...props }) => <p className="mb-4 leading-relaxed" {...props} />,
                ul: ({ node, ...props }) => <ul className="list-disc pr-6 mb-4 space-y-1" {...props} />,
                ol: ({ node, ...props }) => <ol className="list-decimal pr-6 mb-4 space-y-1" {...props} />,
                strong: ({ node, ...props }) => <strong className="font-bold text-foreground" {...props} />,
                blockquote: ({ node, ...props }) => <blockquote className="border-r-4 border-accent pr-4 py-2 my-4 text-muted-foreground italic" {...props} />,
              }}
            >
              {post.content}
            </ReactMarkdown>
          </div>
        </article>
      </main>
      <SiteFooter siteName={settings.siteName} contactInfo={settings.contactInfo} />
    </div>
  )
}
