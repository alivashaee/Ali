import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { MemberSummaryDetail } from '@/components/member/member-summary-detail'

export const dynamic = 'force-dynamic'

type Params = { params: Promise<{ id: string }> }

export default async function MemberSummaryDetailPage({ params }: Params) {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect('/login?callbackUrl=/member/summaries')
  const role = (session.user as any).role as string
  if (role !== 'MEMBER' && role !== 'COACH' && role !== 'SUPER_ADMIN') redirect('/login')

  const { id } = await params
  return <MemberSummaryDetail summaryId={id} />
}
