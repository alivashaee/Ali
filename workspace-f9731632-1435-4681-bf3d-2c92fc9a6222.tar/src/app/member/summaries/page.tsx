import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { FileAudio, ChevronLeft, Clock, Users } from 'lucide-react'
import { formatJalaliDate } from '@/lib/format-jalali'

export const dynamic = 'force-dynamic'

export default async function MemberSummariesPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect('/login?callbackUrl=/member/summaries')
  const role = (session.user as any).role as string
  if (role !== 'MEMBER' && role !== 'COACH' && role !== 'SUPER_ADMIN') redirect('/login')

  const userId = (session.user as any).id as string
  const isMember = role === 'MEMBER'

  const where = isMember
    ? { group: { members: { some: { userId } } }, status: 'completed' }
    : {
        OR: [{ group: { coachId: userId } }, { group: { members: { some: { userId } } } }],
        status: 'completed' as const,
      }

  const summaries = await db.meetingSummary.findMany({
    where,
    select: {
      id: true,
      audioUrl: true,
      createdAt: true,
      summary: true,
      group: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 100,
  })

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-2xl font-bold text-primary">خلاصه جلسات</h1>
        <p className="text-sm text-muted-foreground mt-1">
          خلاصه‌های تولید شده از جلسات گروه‌های شما.
        </p>
      </header>

      {summaries.length === 0 ? (
        <Card className="border-dashed border-accent/30">
          <CardContent className="py-12 flex flex-col items-center text-center gap-3">
            <div className="w-14 h-14 rounded-full bg-accent/15 flex items-center justify-center">
              <FileAudio className="w-7 h-7 text-accent-foreground" />
            </div>
            <div>
              <h3 className="font-semibold text-base">هنوز خلاصه‌ای موجود نیست</h3>
              <p className="text-sm text-muted-foreground mt-1">
                وقتی مربی گروه فایل صوتی جلسه را آپلود کند، خلاصه اینجا نمایش داده می‌شود.
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {summaries.map((s) => (
            <Card key={s.id} className="hover:shadow-md transition-shadow border-accent/20">
              <CardContent className="pt-5 pb-5 px-5 flex flex-col gap-2">
                <div className="flex items-start justify-between gap-2">
                  <Link href={`/member/summaries/${s.id}`} className="min-w-0">
                    <h3 className="font-bold text-sm text-foreground hover:text-primary transition-colors truncate">
                      {s.group.name}
                    </h3>
                  </Link>
                  <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-sprout/15 text-sprout shrink-0">
                    <Clock className="w-3 h-3" />
                    آماده
                  </span>
                </div>
                <div className="text-xs text-muted-foreground">
                  {formatJalaliDate(s.createdAt)}
                </div>
                {s.summary && (
                  <p className="text-xs text-muted-foreground line-clamp-3 mt-1">
                    {s.summary.replace(/[#*>`]/g, '').slice(0, 200)}
                  </p>
                )}
                <div className="pt-2 border-t border-border/30 flex items-center justify-between">
                  <audio controls src={s.audioUrl} className="h-8 max-w-[60%]" />
                  <Button asChild size="sm" variant="outline" className="rounded-full">
                    <Link href={`/member/summaries/${s.id}`}>
                      مشاهده جزئیات
                      <ChevronLeft className="w-4 h-4" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="text-center pt-2">
        <Button asChild variant="link" size="sm">
          <Link href="/member">بازگشت به داشبورد</Link>
        </Button>
      </div>
    </div>
  )
}
