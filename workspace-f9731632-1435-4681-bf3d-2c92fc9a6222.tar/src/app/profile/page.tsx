import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { getSiteSettings } from '@/lib/site-settings'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { formatJalaliDate } from '@/lib/format-jalali'
import { ProfilePasswordForm } from '@/components/profile/profile-password-form'

export const dynamic = 'force-dynamic'

function roleLabel(role: string) {
  switch (role) {
    case 'SUPER_ADMIN':
      return 'مدیر اصلی'
    case 'COACH':
      return 'مربی'
    case 'MEMBER':
      return 'عضو'
    default:
      return 'کاربر'
  }
}

export default async function ProfilePage() {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect('/login?callbackUrl=/profile')

  const userId = (session.user as any).id as string
  const role = (session.user as any).role as string

  const user = await db.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      name: true,
      username: true,
      email: true,
      phone: true,
      role: true,
      avatar: true,
      createdAt: true,
    },
  })
  if (!user) redirect('/login')

  const settings = await getSiteSettings()

  const dashboardHref = role === 'SUPER_ADMIN' ? '/admin' : role === 'COACH' ? '/coach' : '/member'

  return (
    <div className="min-h-screen flex flex-col gradient-spiritual">
      <SiteHeader session={session} logo={settings.logo} siteName={settings.siteName} />
      <div className="flex-1 pt-24 pb-12 px-4 md:px-6">
        <div className="max-w-3xl mx-auto space-y-6">
          <header>
            <h1 className="text-2xl font-bold text-primary">پروفایل کاربری</h1>
            <p className="text-sm text-muted-foreground mt-1">
              اطلاعات حساب شما و تغییر رمز عبور.
            </p>
          </header>

          <Card className="border-accent/20">
            <CardHeader>
              <CardTitle className="text-base">اطلاعات کاربری</CardTitle>
              <CardDescription>اطلاعات پایه حساب شما</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <Avatar className="w-16 h-16 ring-4 ring-accent/30">
                  <AvatarFallback className="bg-primary text-primary-foreground text-xl">
                    {user.name?.charAt(0) || 'ک'}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="font-bold text-lg text-foreground">{user.name}</h2>
                    <Badge variant="secondary" className="text-xs">
                      {roleLabel(role)}
                    </Badge>
                  </div>
                  {user.username && (
                    <div className="text-sm text-muted-foreground" dir="ltr">
                      @{user.username}
                    </div>
                  )}
                  <div className="text-xs text-muted-foreground mt-1">
                    عضو از {formatJalaliDate(user.createdAt)}
                  </div>
                </div>
              </div>

              <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                <InfoRow label="نام کاربری" value={user.username ? `@${user.username}` : '—'} ltr />
                <InfoRow label="نقش" value={roleLabel(role)} />
                <InfoRow label="ایمیل" value={user.email || '—'} ltr />
                <InfoRow label="تلفن" value={user.phone || '—'} ltr />
              </div>
            </CardContent>
          </Card>

          <Card className="border-accent/20">
            <CardHeader>
              <CardTitle className="text-base">تغییر رمز عبور</CardTitle>
              <CardDescription>
                برای امنیت بیشتر، رمز عبور خود را به‌صورت دوره‌ای تغییر دهید.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ProfilePasswordForm />
            </CardContent>
          </Card>
        </div>
      </div>
      <SiteFooter siteName={settings.siteName} contactInfo={settings.contactInfo} />
    </div>
  )
}

function InfoRow({ label, value, ltr }: { label: string; value: string; ltr?: boolean }) {
  return (
    <div className="rounded-xl bg-muted/30 p-3 flex items-center justify-between gap-3">
      <span className="text-muted-foreground text-xs">{label}</span>
      <span className={`font-medium ${ltr ? 'dir-ltr' : ''}`} dir={ltr ? 'ltr' : 'rtl'}>
        {value}
      </span>
    </div>
  )
}
