import { notFound } from 'next/navigation'
import { db } from '@/lib/db'
import { PublicPollClient } from './poll-vote-client'

export const dynamic = 'force-dynamic'

type Props = { params: Promise<{ token: string }> }

export default async function PublicPollPage({ params }: Props) {
  const { token } = await params
  const poll = await db.poll.findUnique({
    where: { shareToken: token },
    include: {
      options: { orderBy: { id: 'asc' } },
    },
  })

  if (!poll) notFound()

  return (
    <div className="min-h-screen flex flex-col">
      <PublicPollClient
        poll={{
          id: poll.id,
          title: poll.title,
          description: poll.description,
          background: poll.background,
          buttonColor: poll.buttonColor,
          buttonShape: poll.buttonShape,
          buttonText: poll.buttonText,
          pollType: poll.pollType,
          allowFileUpload: poll.allowFileUpload,
          fileUploadLabel: poll.fileUploadLabel,
          fileUploadRequired: poll.fileUploadRequired,
          options: poll.options.map((o) => ({
            id: o.id,
            text: o.text,
            imageUrl: o.imageUrl,
          })),
        }}
        token={token}
      />
    </div>
  )
}
