'use client'

import { useState, useEffect, useMemo, useRef } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { useToast } from '@/hooks/use-toast'
import { Loader2, CheckCircle2, Home, AlertCircle, Upload, FileText, X } from 'lucide-react'

type Option = {
  id: string
  text: string
  imageUrl: string | null
}

type Poll = {
  id: string
  title: string
  description: string | null
  background: string | null
  buttonColor: string
  buttonShape: string
  buttonText: string
  pollType?: string
  allowFileUpload?: boolean
  fileUploadLabel?: string | null
  fileUploadRequired?: boolean
  options: Option[]
}

function getOrCreateAnonToken() {
  if (typeof window === 'undefined') return null
  let t = localStorage.getItem('poll_anon')
  if (!t) {
    t =
      'anon-' +
      Math.random().toString(36).slice(2, 12) +
      Date.now().toString(36)
    localStorage.setItem('poll_anon', t!)
  }
  return t
}

export function PublicPollClient({
  poll,
  token,
}: {
  poll: Poll
  token: string
}) {
  const { toast } = useToast()
  const [selected, setSelected] = useState<string | null>(null)
  const [textResponse, setTextResponse] = useState('')
  const [status, setStatus] = useState<'idle' | 'submitting' | 'done' | 'error' | 'already'>('idle')
  const [errorMsg, setErrorMsg] = useState<string | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    getOrCreateAnonToken()
  }, [])

  const isDescriptive = poll.pollType === 'descriptive'

  async function submit() {
    if (isDescriptive) {
      if (!textResponse.trim()) {
        toast({ title: 'پاسخ تشریحی الزامی است', variant: 'destructive' })
        return
      }
    } else {
      if (!selected) {
        toast({ title: 'یک گزینه را انتخاب کنید', variant: 'destructive' })
        return
      }
    }
    if (poll.allowFileUpload && poll.fileUploadRequired && !file) {
      toast({ title: 'بارگذاری فایل الزامی است', variant: 'destructive' })
      return
    }
    setStatus('submitting')
    setErrorMsg(null)
    try {
      const anonToken = getOrCreateAnonToken()
      // Use FormData if file upload is enabled and a file is selected
      if (poll.allowFileUpload && file) {
        const fd = new FormData()
        if (!isDescriptive) fd.append('optionId', selected as string)
        fd.append('textResponse', textResponse)
        fd.append('anonymousToken', anonToken || '')
        fd.append('file', file)
        const res = await fetch(`/api/polls/public/${token}`, {
          method: 'POST',
          body: fd,
        })
        const data = await res.json()
        if (!res.ok) {
          if (data.alreadyVoted) {
            setStatus('already')
            setErrorMsg('شما قبلا در این نظرسنجی شرکت کرده‌اید.')
          } else {
            setStatus('error')
            setErrorMsg(data.error || 'خطا در ثبت پاسخ')
          }
          return
        }
        setStatus('done')
      } else {
        const res = await fetch(`/api/polls/public/${token}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            optionId: selected,
            textResponse: textResponse || null,
            anonymousToken: anonToken,
          }),
        })
        const data = await res.json()
        if (!res.ok) {
          if (data.alreadyVoted) {
            setStatus('already')
            setErrorMsg('شما قبلا در این نظرسنجی شرکت کرده‌اید.')
          } else {
            setStatus('error')
            setErrorMsg(data.error || 'خطا در ثبت پاسخ')
          }
          return
        }
        setStatus('done')
      }
    } catch {
      setStatus('error')
      setErrorMsg('ارتباط با سرور برقرار نشد')
    }
  }

  const shapeClass = useMemo(() => {
    switch (poll.buttonShape) {
      case 'square':
        return 'rounded-none'
      case 'pill':
        return 'rounded-full'
      case 'rounded':
      default:
        return 'rounded-lg'
    }
  }, [poll.buttonShape])

  function formatFileSize(bytes: number) {
    if (bytes < 1024) return bytes + ' بایت'
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' کیلوبایت'
    return (bytes / 1024 / 1024).toFixed(1) + ' مگابایت'
  }

  return (
    <main
      className="flex-1 flex items-center justify-center p-4"
      style={
        poll.background
          ? {
              backgroundImage: `linear-gradient(rgba(0,0,0,0.45), rgba(0,0,0,0.55)), url(${poll.background})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }
          : {
              background:
                'linear-gradient(135deg, var(--sprout) 18%, var(--background) 50%, var(--gold) 12%)',
            }
      }
    >
      <div className="w-full max-w-lg bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 text-white shadow-2xl">
        <div className="mb-4">
          <h1 className="text-xl sm:text-2xl font-bold drop-shadow">
            {poll.title}
          </h1>
          {poll.description && (
            <p className="mt-2 text-sm opacity-90 leading-relaxed">
              {poll.description}
            </p>
          )}
        </div>

        {status === 'done' ? (
          <div className="py-8 text-center space-y-3">
            <div className="flex justify-center">
              <CheckCircle2 className="w-16 h-16 text-sprout drop-shadow" />
            </div>
            <h2 className="text-xl font-bold">از مشارکت شما متشکریم</h2>
            <p className="text-sm opacity-90">
              پاسخ شما با موفقیت ثبت شد.
            </p>
            <Button asChild variant="secondary" className="mt-2">
              <Link href="/">
                <Home className="w-4 h-4 ml-2" />
                بازگشت به خانه
              </Link>
            </Button>
          </div>
        ) : status === 'already' ? (
          <div className="py-8 text-center space-y-3">
            <div className="flex justify-center">
              <AlertCircle className="w-14 h-14 text-amber-300" />
            </div>
            <h2 className="text-lg font-bold">
              {errorMsg || 'شما قبلا شرکت کرده‌اید.'}
            </h2>
          </div>
        ) : (
          <>
            {/* حالت تشریحی - textarea */}
            {isDescriptive ? (
              <div className="space-y-2">
                <textarea
                  value={textResponse}
                  onChange={(e) => setTextResponse(e.target.value)}
                  placeholder="پاسخ خود را اینجا بنویسید..."
                  rows={6}
                  className="w-full rounded-xl p-3 bg-white/15 border border-white/30 text-white placeholder:text-white/60 focus:outline-none focus:ring-2 focus:ring-white resize-y"
                  style={{ minHeight: '150px' }}
                />
                <p className="text-xs opacity-70">
                  پاسخ شما به صورت تشریحی ثبت می‌شود.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {poll.options.map((opt) => {
                  const isSel = selected === opt.id
                  return (
                    <label
                      key={opt.id}
                      className={`flex items-center gap-3 rounded-xl p-3 cursor-pointer transition-all ${
                        isSel
                          ? 'bg-white/30 ring-2 ring-white'
                          : 'bg-white/15 hover:bg-white/25'
                      }`}
                    >
                      <input
                        type="radio"
                        name="poll-option"
                        value={opt.id}
                        checked={isSel}
                        onChange={() => setSelected(opt.id)}
                        className="w-4 h-4 accent-white"
                      />
                      {opt.imageUrl && (
                      <img
                        src={opt.imageUrl}
                        alt=""
                        className="w-10 h-10 rounded-lg object-cover"
                      />
                    )}
                    <span className="flex-1 text-sm font-medium">
                      {opt.text}
                    </span>
                  </label>
                )
              })}
              </div>
            )}

            {/* بخش آپلود فایل */}
            {poll.allowFileUpload && (
              <div className="mt-4 p-3 rounded-xl bg-white/15 border border-white/20">
                <div className="flex items-center gap-2 mb-2">
                  <Upload className="w-4 h-4" />
                  <span className="text-sm font-semibold">
                    {poll.fileUploadLabel || 'بارگذاری فایل'}
                  </span>
                  {poll.fileUploadRequired && (
                    <span className="text-xs text-red-300">*</span>
                  )}
                </div>
                {file ? (
                  <div className="flex items-center gap-2 bg-white/10 rounded-lg p-2">
                    <FileText className="w-5 h-5 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate">
                        {file.name}
                      </p>
                      <p className="text-xs opacity-70">
                        {formatFileSize(file.size)}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setFile(null)
                        if (fileInputRef.current) fileInputRef.current.value = ''
                      }}
                      className="p-1 rounded hover:bg-white/20"
                      aria-label="حذف فایل"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-3 rounded-lg border-2 border-dashed border-white/40 hover:bg-white/10 transition-colors text-sm"
                  >
                    <Upload className="w-5 h-5 mx-auto mb-1" />
                    کلیک کنید تا فایل انتخاب شود
                  </button>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0]
                    if (f) setFile(f)
                  }}
                />
              </div>
            )}

            {status === 'error' && errorMsg && (
              <p className="mt-3 text-xs text-red-200 bg-red-500/20 rounded-lg p-2 text-center">
                {errorMsg}
              </p>
            )}

            <button
              type="button"
              onClick={submit}
              disabled={status === 'submitting' || (isDescriptive ? !textResponse.trim() : !selected) || (poll.allowFileUpload && poll.fileUploadRequired && !file)}
              className={`mt-4 w-full py-3 font-bold text-white shadow-md transition-all disabled:opacity-50 ${shapeClass}`}
              style={{ backgroundColor: poll.buttonColor }}
            >
              {status === 'submitting' ? (
                <span className="inline-flex items-center justify-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  در حال ثبت...
                </span>
              ) : (
                poll.buttonText || 'ثبت پاسخ'
              )}
            </button>

            <div className="mt-3 text-center">
              <Link
                href="/"
                className="text-xs text-white/70 hover:text-white underline"
              >
                موسسه رویش‌های پیشران
              </Link>
            </div>
          </>
        )}
      </div>
    </main>
  )
}
