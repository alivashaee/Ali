import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { FileAudio, ChevronLeft, Clock, CheckCircle2, Loader2, AlertCircle } from 'lucide-react'
import { formatJalaliDate } from '@/lib/format-jalali'

export const dynamic = 'force-dynamic'

export default async function CoachSummariesPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect('/login?callbackUrl=/coach/summaries')
  const role = (session.user as any).role as string
  if (role !== 'COACH' && role !== 'SUPER_ADMIN') redirect('/member?forbidden=1')

  const userId = (session.user as any).id as string
  const isAdmin = role === 'SUPER_ADMIN'

  const summaries = await db.meetingSummary.findMany({
    where: isAdmin ? {} : { group: { coachId: userId } },
    select: {
      id: true,
      audioUrl: true,
      status: true,
      createdAt: true,
      summary: true,
      transcript: true,
      group: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 100,
  })

  return (
    <div className="space-y-5">
      <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-primary">خلاصه جلسات</h1>
          <p className="text-sm text-muted-foreground mt-1">
            تمام خلاصه‌های تولید شده با هوش مصنوعی از فایل‌های صوتی جلسات.
          </p>
        </div>
        <Button asChild size="sm" variant="outline" className="rounded-full">
          <Link href="/coach">
            <FileAudio className="w-4 h-4" />
            رفتن به داشبورد
          </Link>
        </Button>
      </header>

      {summaries.length === 0 ? (
        <Card className="border-dashed border-accent/30">
          <CardContent className="py-12 flex flex-col items-center text-center gap-3">
            <div className="w-14 h-14 rounded-full bg-accent/15 flex items-center justify-center">
              <FileAudio className="w-7 h-7 text-accent-foreground" />
            </div>
            <div>
              <h3 className="font-semibold text-base">هنوز خلاصه‌ای وجود ندارد</h3>
              <p className="text-sm text-muted-foreground mt-1 max-w-md">
                برای شروع، از داشبورد گروه خود فایل صوتی اولین جلسه را آپلود کنید.
              </p>
            </div>
            <Button asChild size="sm" className="rounded-full">
              <Link href="/coach">رفتن به داشبورد گروه</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {summaries.map((s) => (
            <Card key={s.id} className="hover:shadow-md transition-shadow border-accent/20">
              <CardContent className="pt-5 pb-5 px-5 flex flex-col gap-2">
                <div className="flex items-center justify-between gap-2">
                  <Link href={`/coach/summaries/${s.id}`} className="min-w-0 flex-1">
                    <h3 className="font-bold text-sm text-foreground hover:text-primary transition-colors truncate">
                      {s.group.name}
                    </h3>
                  </Link>
                  <StatusChip status={s.status} />
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock className="w-3.5 h-3.5" />
                  {formatJalaliDate(s.createdAt)}
                </div>
                {s.summary && (
                  <p className="text-xs text-muted-foreground line-clamp-3 mt-1">
                    {s.summary.replace(/[#*>`]/g, '').slice(0, 200)}
                  </p>
                )}
                <div className="pt-2 border-t border-border/30 flex items-center justify-between">
                  <audio controls src={s.audioUrl} className="h-8 max-w-[60%]" />
                  <Button asChild size="sm" variant="outline" className="rounded-full">
                    <Link href={`/coach/summaries/${s.id}`}>
                      مشاهده جزئیات
                      <ChevronLeft className="w-4 h-4" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function StatusChip({ status }: { status: string }) {
  if (status === 'completed') {
    return (
      <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-sprout/15 text-sprout">
        <CheckCircle2 className="w-3 h-3" />
        تکمیل شده
      </span>
    )
  }
  if (status === 'processing') {
    return (
      <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-gold/20 text-gold">
        <Loader2 className="w-3 h-3 animate-spin" />
        در حال پردازش
      </span>
    )
  }
  if (status === 'pending') {
    return (
      <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-gold/20 text-gold">
        <Clock className="w-3 h-3" />
        در انتظار
      </span>
    )
  }
  return (
    <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-destructive/15 text-destructive">
      <AlertCircle className="w-3 h-3" />
      ناموفق
    </span>
  )
}
