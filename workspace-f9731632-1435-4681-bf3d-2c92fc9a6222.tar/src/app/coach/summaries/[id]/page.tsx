import { notFound, redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ChevronRight } from 'lucide-react'
import { SummaryDetail } from '@/components/coach/summary-detail'

export const dynamic = 'force-dynamic'

type Params = { params: Promise<{ id: string }> }

export default async function CoachSummaryDetailPage({ params }: Params) {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect('/login')
  const role = (session.user as any).role as string
  if (role !== 'COACH' && role !== 'SUPER_ADMIN') redirect('/member?forbidden=1')

  const userId = (session.user as any).id as string
  const { id } = await params

  const summary = await db.meetingSummary.findUnique({
    where: { id },
    select: {
      id: true,
      audioUrl: true,
      transcript: true,
      summary: true,
      status: true,
      createdAt: true,
      updatedAt: true,
      group: { select: { id: true, name: true } },
    },
  })

  if (!summary) notFound()

  const isAdmin = role === 'SUPER_ADMIN'
  if (!isAdmin) {
    const group = await db.group.findUnique({
      where: { id: summary.group.id },
      select: { coachId: true },
    })
    if (!group || group.coachId !== userId) {
      redirect('/coach/summaries?forbidden=1')
    }
  }

  return (
    <div className="space-y-5">
      <nav className="flex items-center gap-1 text-sm text-muted-foreground">
        <Link href="/coach" className="hover:text-primary transition-colors">پنل مربی</Link>
        <ChevronRight className="w-4 h-4" />
        <Link href="/coach/summaries" className="hover:text-primary transition-colors">خلاصه‌ها</Link>
        <ChevronRight className="w-4 h-4" />
        <span className="text-foreground truncate">{summary.group.name}</span>
      </nav>

      <SummaryDetail summaryId={summary.id} initial={summary} />

      <div className="pt-2">
        <Button asChild variant="link" size="sm">
          <Link href="/coach/summaries">بازگشت به فهرست خلاصه‌ها</Link>
        </Button>
      </div>
    </div>
  )
}
