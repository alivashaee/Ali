import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ArrowRight } from 'lucide-react'
import { PollBuilderClient } from '@/app/admin/polls/new/poll-builder-client'

export const dynamic = 'force-dynamic'

export default async function CoachNewPollPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect('/login?callbackUrl=/coach/polls/new')
  const role = (session.user as any).role as string
  if (role !== 'COACH' && role !== 'SUPER_ADMIN') redirect('/member?forbidden=1')

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Button asChild variant="ghost" size="sm">
          <Link href="/coach/polls">
            <ArrowRight className="w-4 h-4 ml-1" />
            بازگشت
          </Link>
        </Button>
      </div>
      <div>
        <h1 className="text-2xl font-bold text-primary">نظرسنجی جدید</h1>
        <p className="text-sm text-muted-foreground mt-1">
          نظرسنجی خود را بسازید و لینک اشتراک‌گذاری آن را با اعضای گروه خود به اشتراک بگذارید.
        </p>
      </div>
      <PollBuilderClient />
    </div>
  )
}
