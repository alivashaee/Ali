import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { BarChart3, Users, ChevronLeft, Vote } from 'lucide-react'
import { formatJalaliDate } from '@/lib/format-jalali'

export const dynamic = 'force-dynamic'

export default async function CoachPollsPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect('/login?callbackUrl=/coach/polls')
  const role = (session.user as any).role as string
  if (role !== 'COACH' && role !== 'SUPER_ADMIN') redirect('/member?forbidden=1')

  const userId = (session.user as any).id as string

  const polls = await db.poll.findMany({
    where: {
      OR: [{ isPublic: true }, { createdBy: userId }],
    },
    select: {
      id: true,
      title: true,
      description: true,
      isPublic: true,
      createdAt: true,
      _count: { select: { responses: true } },
      options: {
        select: { id: true, text: true, _count: { select: { responses: true } } },
      },
    },
    orderBy: { createdAt: 'desc' },
  })

  const userResponses = await db.pollResponse.findMany({
    where: { userId, pollId: { in: polls.map((p) => p.id) } },
    select: { pollId: true, optionId: true },
  })
  const voted = new Map(userResponses.map((r) => [r.pollId, r.optionId]))

  return (
    <div className="space-y-5">
      <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-primary">نظرسنجی‌ها</h1>
          <p className="text-sm text-muted-foreground mt-1">
            می‌توانید نظرسنجی جدید بسازید یا در نظرسنجی‌های موجود شرکت کنید.
          </p>
        </div>
        <div className="flex gap-2">
          <Button asChild size="sm" className="rounded-full">
            <Link href="/coach/polls/new">
              <Vote className="w-4 h-4 ml-1" />
              نظرسنجی جدید
            </Link>
          </Button>
          <Button asChild size="sm" variant="outline" className="rounded-full">
            <Link href="/coach">
              <BarChart3 className="w-4 h-4" />
              بازگشت
            </Link>
          </Button>
        </div>
      </header>

      {polls.length === 0 ? (
        <Card className="border-dashed border-accent/30">
          <CardContent className="py-12 flex flex-col items-center text-center gap-3">
            <div className="w-14 h-14 rounded-full bg-accent/15 flex items-center justify-center">
              <BarChart3 className="w-7 h-7 text-accent-foreground" />
            </div>
            <div>
              <h3 className="font-semibold text-base">هنوز نظرسنجی نساخته‌اید</h3>
              <p className="text-sm text-muted-foreground mt-1">
                با ساخت اولین نظرسنجی، می‌توانید نظر اعضای گروه‌های خود را جویا شوید.
              </p>
            </div>
            <Button asChild size="sm" className="rounded-full mt-2">
              <Link href="/coach/polls/new">
                <Vote className="w-4 h-4 ml-1" />
                ساخت نظرسنجی
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {polls.map((p) => {
            const totalResponses = p._count.responses
            const userVote = voted.get(p.id)
            return (
              <Card key={p.id} className="hover:shadow-md transition-shadow border-accent/20">
                <CardContent className="pt-5 pb-5 px-5 flex flex-col gap-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="font-bold text-base text-foreground">{p.title}</h3>
                      {p.description && (
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                          {p.description}
                        </p>
                      )}
                    </div>
                    {p.isPublic ? (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-sprout/15 text-sprout shrink-0">
                        عمومی
                      </span>
                    ) : (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground shrink-0">
                        خصوصی
                      </span>
                    )}
                  </div>

                  <div className="space-y-2">
                    {p.options.map((o) => {
                      const count = o._count.responses
                      const pct = totalResponses > 0 ? Math.round((count / totalResponses) * 100) : 0
                      const isUserVote = userVote === o.id
                      return (
                        <div key={o.id} className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className={isUserVote ? 'font-bold text-primary' : 'text-foreground/80'}>
                              {isUserVote && '✓ '}{o.text}
                            </span>
                            <span className="text-muted-foreground">
                              {count.toLocaleString('fa-IR')} ({pct.toLocaleString('fa-IR')}٪)
                            </span>
                          </div>
                          <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                            <div className="h-full bg-primary/70 rounded-full" style={{ width: `${pct}%` }} />
                          </div>
                        </div>
                      )
                    })}
                  </div>

                  <div className="pt-2 border-t border-border/30 flex items-center justify-between text-xs">
                    <span className="text-muted-foreground inline-flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" />
                      {totalResponses.toLocaleString('fa-IR')} شرکت‌کننده
                    </span>
                    <span className="text-muted-foreground">{formatJalaliDate(p.createdAt)}</span>
                  </div>

                  <Button asChild size="sm" variant="outline" className="rounded-full mt-1">
                    <Link href={`/polls/${p.id}`}>
                      <Vote className="w-4 h-4" />
                      {userVote ? 'مشاهده نتیجه' : 'شرکت در نظرسنجی'}
                      <ChevronLeft className="w-4 h-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
