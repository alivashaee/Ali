import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { Card, CardContent } from '@/components/ui/card'
import { Users, MessageSquare, FileAudio, Sparkles } from 'lucide-react'
import { formatJalaliDate } from '@/lib/format-jalali'
import { CreateGroupForm } from '@/components/coach/create-group-form'
import { CoachDashboard } from '@/components/coach/coach-dashboard'

export const dynamic = 'force-dynamic'

export default async function CoachDashboardPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect('/login?callbackUrl=/coach')
  const role = (session.user as any).role as string
  if (role !== 'COACH' && role !== 'SUPER_ADMIN') redirect('/member?forbidden=1')

  const userId = (session.user as any).id as string

  // Single-group architecture: this coach owns AT MOST one group.
  const group = await db.group.findFirst({
    where: { coachId: userId },
    select: {
      id: true,
      name: true,
      description: true,
      createdAt: true,
      coach: { select: { id: true, name: true } },
      _count: { select: { members: true, messages: true, summaries: true } },
    },
  })

  // No group yet — show inline create form (this IS the dashboard).
  if (!group) {
    return (
      <div className="space-y-6">
        <header className="text-center md:text-right">
          <h1 className="text-2xl font-bold text-primary">
            سلام {(session.user as any).name} 👋
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            به پنل مربی موسسه رویش‌های پیشران خوش آمدید. برای شروع، گروه تربیتی خود را بسازید.
          </p>
        </header>
        <CreateGroupForm />
      </div>
    )
  }

  const stats = [
    {
      label: 'اعضای گروه',
      value: group._count.members,
      icon: Users,
      tone: 'text-sprout',
    },
    {
      label: 'پیام‌ها',
      value: group._count.messages,
      icon: MessageSquare,
      tone: 'text-gold',
    },
    {
      label: 'خلاصه جلسات',
      value: group._count.summaries,
      icon: FileAudio,
      tone: 'text-navy',
    },
  ]

  return (
    <div className="space-y-5">
      <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div className="min-w-0">
          <div className="inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full bg-accent/15 text-primary mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            گروه تربیتی شما
          </div>
          <h1 className="text-2xl font-bold text-primary truncate">{group.name}</h1>
          {group.description && (
            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{group.description}</p>
          )}
          <div className="text-xs text-muted-foreground mt-2">
            ساخته شده در {formatJalaliDate(group.createdAt)}
          </div>
        </div>
      </header>

      <section className="grid grid-cols-3 gap-2 md:gap-3">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.label} className="border-accent/20">
              <CardContent className="pt-4 pb-4 px-3 md:px-4 flex flex-col gap-1.5">
                <span className={`p-1.5 rounded-xl bg-accent/20 w-fit ${stat.tone}`}>
                  <Icon className="w-4 h-4" />
                </span>
                <div className="text-xl md:text-2xl font-bold text-foreground leading-none mt-1">
                  {stat.value.toLocaleString('fa-IR')}
                </div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          )
        })}
      </section>

      <CoachDashboard groupId={group.id} groupName={group.name} />
    </div>
  )
}
