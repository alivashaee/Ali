import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { getSiteSettings } from '@/lib/site-settings'
import { PanelSidebar, coachNavLinks } from '@/components/panel/panel-sidebar'

export default async function CoachLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect('/login?callbackUrl=/coach')
  }

  const role = (session.user as any).role as string
  if (role !== 'COACH' && role !== 'SUPER_ADMIN') {
    redirect('/member?forbidden=1')
  }

  const settings = await getSiteSettings()
  const isAdmin = role === 'SUPER_ADMIN'
  const title = isAdmin ? 'پنل مدیریت — بخش مربی' : 'پنل مربی'
  const subtitle = (session.user as any).name as string

  return (
    <div className="min-h-screen flex flex-col gradient-spiritual">
      <SiteHeader
        session={session}
        logo={settings.logo}
        siteName={settings.siteName}
      />
      <div className="flex-1 pt-24 pb-12 px-4 md:px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-6">
          <PanelSidebar
            links={coachNavLinks}
            title={title}
            subtitle={subtitle}
            adminLink={isAdmin}
          />
          <main className="flex-1 min-w-0">{children}</main>
        </div>
      </div>
      <SiteFooter siteName={settings.siteName} contactInfo={settings.contactInfo} />
    </div>
  )
}
