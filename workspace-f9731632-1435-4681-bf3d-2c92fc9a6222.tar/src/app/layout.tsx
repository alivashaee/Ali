import type { Metadata } from "next";
import "./globals.css";
import { Providers } from "@/components/providers";

export const metadata: Metadata = {
  title: "موسسه رویش‌های پیشران",
  description:
    "موسسه تربیتی رویش‌های پیشران، وابسته به مسجد فاطمه معصومه(سلام الله علیها)، فضایی برای رویش نوجوانان در سایه آموزه‌های دینی.",
  keywords: ["رویش‌های پیشران", "موسسه تربیتی", "مسجد فاطمه معصومه", "نوجوانان", "مدرسه علمیه معصومیه"],
  authors: [{ name: "موسسه رویش‌های پیشران" }],
  icons: {
    icon: "/institute-logo-final.png",
  },
  openGraph: {
    title: "موسسه رویش‌های پیشران",
    description: "فضایی برای رویش نوجوانان در سایه آموزه‌های دینی",
    siteName: "رویش‌های پیشران",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body className="font-sans antialiased bg-background text-foreground min-h-screen flex flex-col">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
