import { NextRequest, NextResponse } from 'next/server'
import { getToken } from 'next-auth/jwt'

const protectedPaths = [
  { pattern: /^\/admin(\/.*)?$/, roles: ['SUPER_ADMIN'] },
  { pattern: /^\/coach(\/.*)?$/, roles: ['SUPER_ADMIN', 'COACH'] },
  { pattern: /^\/member(\/.*)?$/, roles: ['SUPER_ADMIN', 'COACH', 'MEMBER'] },
  { pattern: /^\/profile(\/.*)?$/, roles: ['SUPER_ADMIN', 'COACH', 'MEMBER'] },
  // /api/admin/polls اجازه دسترسی به هر دو نقش ادمین و مربی (برای ساخت نظرسنجی)
  { pattern: /^\/api\/admin\/polls(\/.*)?$/, roles: ['SUPER_ADMIN', 'COACH'] },
  { pattern: /^\/api\/admin(\/.*)?$/, roles: ['SUPER_ADMIN'] },
  { pattern: /^\/api\/coach(\/.*)?$/, roles: ['SUPER_ADMIN', 'COACH'] },
  { pattern: /^\/api\/member(\/.*)?$/, roles: ['SUPER_ADMIN', 'COACH', 'MEMBER'] },
]

export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl

  const match = protectedPaths.find((p) => p.pattern.test(pathname))
  if (!match) return NextResponse.next()

  const token = await getToken({
    req: request,
    secret: process.env.NEXTAUTH_SECRET || 'rooyesh-pishrun-secret-key-2024-very-long',
  })

  if (!token) {
    const loginUrl = new URL('/login', request.url)
    loginUrl.searchParams.set('callbackUrl', pathname)
    return NextResponse.redirect(loginUrl)
  }

  if (!match.roles.includes(token.role as string)) {
    // Redirect to user's own dashboard
    const target =
      token.role === 'SUPER_ADMIN' ? '/admin' : token.role === 'COACH' ? '/coach' : '/member'
    const url = new URL(target, request.url)
    url.searchParams.set('forbidden', '1')
    return NextResponse.redirect(url)
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    '/admin/:path*',
    '/coach/:path*',
    '/member/:path*',
    '/profile/:path*',
    '/api/admin/:path*',
    '/api/coach/:path*',
    '/api/member/:path*',
  ],
}
