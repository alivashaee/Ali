# Worklog — موسسه رویش‌های پیشران

---
Task ID: 1
Agent: main
Task: استخراج محتوای کانال ایتا (rooyesh_pishrun) و تولید لوگوی موسسه

Work Log:
- استفاده از web-reader skill برای استخراج https://eitaa.org/rooyesh_pishrun
- استخراج نام کانال: «رویش‌های پیشران» (@rooyesh_pishrun)
- استخراج توضیحات: مسجد فاطمه معصومه(سلام الله علیها)، طلاب و اساتید فارغ التحصیل دانشگاه، مدرسه علمیه معصومیه
- آدرس: بلوار امین، حدفاصل بلوار جمهوری و خیابان گلستان، مدرسه علمیه معصومیه
- آمار: 658 دنبال‌کننده، 4.6هزار عکس، 1هزار ویدیو، 44 فایل
- تولید لوگوی موسسه با image-generation skill → /public/institute-logo.png
- تولید تصویر هیرو → /public/hero-bg.jpg
- تولید تصویر وبلاگ 1 → /public/blog-1.jpg

Stage Summary:
- اطلاعات کانال استخراج شد و در seed دیتابیس استفاده خواهد شد
- لوگو و تصاویر اولیه آماده هستند
- متن توضیحات موسسه برای استفاده در صفحه معرفی:
  «موسسه تربیتی رویش‌های پیشران، وابسته به مسجد فاطمه معصومه(سلام الله علیها)، با همکاری طلاب و اساتید فارغ‌التحصیل دانشگاه و مدرسه علمیه معصومیه، فضایی برای رویش نوجوانان در سایه آموزه‌های دینی فراهم می‌آورد.»

---
Task ID: 2
Agent: main
Task: راه‌اندازی فونداسیون پروژه - schema، seed، auth، تم RTL فارسی، صفحه اصلی

Work Log:
- به‌روزرسانی prisma/schema.prisma با مدل‌های کامل: User, Group, GroupMember, Message, MeetingSummary, Poll, PollOption, PollResponse, BlogPost, SiteSettings, OtpCode
- اجرای db:push و همگام‌سازی schema با SQLite
- نصب bcryptjs برای هش کردن رمز عبور
- ساخت prisma/seed.ts و اجرای آن: adminro/rooyeshp با نقش SUPER_ADMIN، coach1/coach123 با نقش COACH، ۳ پست وبلاگ نمونه، تنظیمات سایت، یک نظرسنجی نمونه
- ساخت src/lib/auth.ts با NextAuth و CredentialsProvider (شناسایی با username/phone/email)
- ساخت src/app/api/auth/[...nextauth]/route.ts
- ساخت src/lib/auth-utils.ts با helperهای requireAdmin/Coach/Member و بررسی دسترسی گروه
- ساخت src/lib/site-settings.ts برای دریافت تنظیمات singleton
- ساخت src/lib/socket-client.ts برای اتصال به سرور Socket.IO روی پورت 3003
- به‌روزرسانی src/app/globals.css: فونت Vazirmatn از CDN، پالت گرم معنوی (سبز تیره، طلایی، کرم، آبی نفتی)، کلاس‌های glass/glass-strong/bubble/gradient-spiritual، RTL
- به‌روزرسانی src/app/layout.tsx: lang=fa dir=rtl، Vazirmatn، Providers (SessionProvider)
- ساخت src/proxy.ts (در Next.js 16 middleware به proxy تغییر نام داده) برای محافظت از مسیرها
- ساخت کامپوننت‌ها: providers.tsx، splash-screen.tsx (چرخش ۳۶۰ لوگو با Framer Motion)، site-header.tsx (glassmorphism حبابی چسبان با جمع شدن هنگام اسکرول)، site-footer.tsx (sticky)، landing-page-client.tsx
- ساخت صفحه اصلی src/app/page.tsx: هیرو با لوگو و دکمه، آمار، درباره موسسه، ویژگی‌ها، وبلاگ، CTA
- ساخت صفحه ورود src/app/login/page.tsx با فرم username/password و نمایش حساب‌های آزمایشی
- ساخت صفحه blog/[id] برای نمایش پست با ReactMarkdown

Stage Summary:
- صفحه اصلی http://localhost:3000 با موفقیت بارگذاری می‌شود (200)
- اسپلش اسکرین، هدر glassmorphism، فوتر sticky همگی کار می‌کنند
- تأیید VLM: چیدمان RTL فارسی صحیح، پالت رنگی گرم، تایپوگرافی Vazirmatn درست است
- فقط warningهای کوچک next/image (نبود sizes) که غیربحرانی هستند
- ادمین آماده: adminro / rooyeshp با نقش SUPER_ADMIN
- مربی آماده: coach1 / coach123 با نقش COACH
- پورت 3000 فعال برای فرانت‌اند، پورت 3003 برای Socket.IO آزاد است
- TODO: ساخت پنل ادمین، پنل مربی، پنل عضو، مینی‌سرویس Socket.IO، API خلاصه‌سازی AI، سیستم نظرسنجی

---
Task ID: 5-b
Agent: full-stack-developer (chat service)
Task: ساخت مینی‌سرویس Socket.IO + کامپوننت‌های چت گروهی + API آپلود

Work Log:
- ساخت `mini-services/chat-service/package.json` — پروژه Bun با `bun --hot index.ts` و وابستگی `socket.io` (+ `socket.io-client` برای تست)
- ساخت `mini-services/chat-service/index.ts` — سرور Socket.IO روی پورت ۳۰۰۳ با path `/` و CORS `*`. با `bun:sqlite` مستقیماً از همان SQLite اصلی پروژه می‌خواند/می‌نویسد. Event ها: `join-group`, `leave-group`, `send-message`, `typing`, `reaction`, `disconnect`. حضور آنلاین در Map درون حافظه. تأیید کاربر از DB و عضویت در گروه در هر join. ارسال message-history (۵۰ پیام آخر) + online-users + user-online به‌محض join.
- شروع مینی‌سرویس با `setsid bash -c 'exec bun --hot index.ts'` (PPID=1، detached) — PID 4791 و فعال
- ساخت `src/app/api/coach/upload/route.ts` — POST FormData، require `requireCoachOrAdmin()`. ذخیره در `public/uploads/<uuid>_<safe>.<ext>`. بازگشت `{ url, fileName, fileType, size }`. تأیید MIME و حداکثر ۲۵MB. هندل صحیح Response throw از auth-utils.
- ساخت `src/app/api/member/upload/route.ts` — همان منطق با `requireAuth()`.
- ساخت `src/app/api/groups/[groupId]/messages/route.ts` — GET پیج‌بندی‌شده (limit 1..200, cursor `before`). با `canAccessGroup` بررسی دسترسی. بازگشت messages با sender info و reactions پارس‌شده.
- ساخت `src/components/chat/group-chat.tsx` — کامپوننت اصلی `<GroupChat groupId={...} />`. اتصال با `getSocket()` از `@/lib/socket-client`. گوش دادن به `message-history`, `new-message`, `user-typing`, `user-online`, `user-offline`, `online-users`, `message-reaction`, `chat-error`. چیدمان RTL تم-spotter Telegram: پیام‌های خودمان راست، دیگران چپ. اسکرول خودکار + دکمه رفتن به آخر. نوار ورودی: دکمه آپلود + Textarea + Send (Enter برای ارسال). typing throttled (1.5s) با auto-stop 3s. پاکسازی typing های قدیمی هر 2s.
- ساخت `src/components/chat/message-bubble.tsx` — بابل پیام. آواتار (initials fallback)، نام فرستنده، زمان، markdown content (react-markdown)، پیش‌نمایش فایل (تصویر/ویدیو/صوت/لینک دانلود)، انتخابگر ایموجی (👍 ❤️ 😂 🙏 🔥) با Popover، ردیف واکنش‌ها با toggle. برجسته‌سازی واکنش‌های خود کاربر.
- ساخت `src/components/chat/typing-indicator.tsx` — سه نقطه متحرک با برچسب فارسی (۱ یا ۲+ نفر در حال نوشتن).
- ساخت `src/components/chat/file-upload-button.tsx` — دکمه آپلود با XHR progress. خروجی `UploadedFile` از طریق callback.
- اجرای lint: همه فایل‌های من تمیز. یک error پیش‌موجود در `src/components/splash-screen.tsx` (کد Task ۲) باقی مانده که خارج از حوزه مجاز من است.
- تست دودویی end-to-end: ساخت گروه تست موقت، join با coach1، send-message، دریافت broadcast `new-message`، reaction toggle، دریافت `message-reaction`. همه چیز کار کرد. پاک‌سازی گروه تست پس از اتمام.

Stage Summary:
- مینی‌سرویس چت روی پورت ۳۰۰۳ فعال و آماده استفاده (PID 4791، nohup-style با setsid)
- Caddy مسیر `?XTransformPort=3003` را به localhost:3003 هدایت می‌کند — فرانت با `getSocket()` از `src/lib/socket-client.ts` بدون تغییر متصل می‌شود
- API های آپلود و تاریخچه پیام با auth و بررسی دسترسی گروه فعال هستند
- کامپوننت‌های چت RTL آماده‌ی استفاده در هر صفحه‌ای که `<GroupChat groupId={...} />` را import کند (مثلاً پنل مربی که در Task 5-a ساخته می‌شود)
- اعتبارسنجی: با پاسخ socket.io polling، با تست دودویی socket.io-client، و با curl روی API ها همگی موفق
- فایل کارِ این agent: `/home/z/my-project/agent-ctx/5-b-chat-service.md`
- نکته برای agent های بعدی: هیچ گروهی در DB وجود ندارد (`SELECT COUNT(*) FROM "Group"` = 0) — چت در مرورگر تا زمانی که پنل مربی/ادمی نگیره گروه نسازد قابل تست کامل نیست اما کلاینت + سرور به‌صورت programmatic تست شده‌اند.


---
Task ID: 5-a
Agent: full-stack-developer (admin panel)
Task: ساخت پنل ادمین اصلی - مدیریت کاربران، محتوا، گروه‌ها، نظرسنجی‌ساز، تنظیمات + APIها

Work Log:
- src/components/admin/admin-sidebar.tsx — sidebar آفلاین (right-RTL) + نوار موبایل افقی
- src/components/admin/file-upload.tsx — کامپوننت بارگذاری فایل به /api/admin/upload با پیش‌نمایش تصویر
- src/app/admin/layout.tsx — لایوت ادمین با تأیید نشست SUPER_ADMIN، هدر چسبان + سایدبار + نوار موبایل
- src/app/admin/page.tsx — داشبورد آماری: شمارش کاربران/مربیان/گروه‌ها/نظرسنجی‌ها/وبلاگ‌ها/پاسخ‌ها + آخرین فعالیت‌ها
- src/app/admin/users/page.tsx + users-client.tsx — جدول کاربران + دیالوگ افزودن/ویرایش + مسدودسازی + حذف + بازنشانی رمز
- src/app/admin/content/page.tsx + content-client.tsx — تب‌ها: وبلاگ (جدول پست‌ها با ویرایش/حذف/انتشار)، تنظیمات صفحه (نام، هیرو، توضیحات، تماس، لوگو، ویدیو)، معرفی موسسه
- src/app/admin/groups/page.tsx — جدول همه گروه‌ها با نام مربی، تعداد اعضا، تعداد پیام، تاریخ
- src/app/admin/polls/page.tsx — فهرست نظرسنجی‌ها (نوع، تعداد گزینه، تعداد پاسخ، مشاهده نتایج)
- src/app/admin/polls/new/page.tsx + poll-builder-client.tsx — نظرسنجی‌ساز با عنوان، توضیح، پس‌زمینه، رنگ دکمه (color picker)، شکل دکمه، متن دکمه، toggle عمومی/خصوصی، گزینه‌های پویا، پیش‌نمایش زنده، تولید لینک اشتراک
- src/app/admin/polls/[id]/page.tsx + poll-results-client.tsx — صفحه نتایج با نمودار میله‌ای (BarChart) و دایره‌ای (PieChart) Recharts + جدول جزئیات + دکمه‌های خروجی CSV / کپی لینک / باز کردن صفحه عمومی
- src/app/admin/settings/page.tsx + settings-client.tsx — فرم تنظیمات سامانه (نام، ویدیو، هیرو، توضیح، تماس، بارگذاری لوگو)
- src/app/polls/[token]/page.tsx + poll-vote-client.tsx — صفحه رای‌گیری عمومی بدون نیاز به ورود، با دکمه و پس‌زمینه سفارشی، کوکی/localStorage برای جلوگیری از دو بار رای دادن
- src/app/api/admin/users/route.ts — GET (فهرست صفحه‌بندی‌شده + جستجو/فیلتر نقش) و POST (ایجاد کاربر با هش bcrypt)
- src/app/api/admin/users/[id]/route.ts — GET / PATCH (نام، نقش، مسدودسازی، رمز عبور جدید) / DELETE
- src/app/api/admin/blog/route.ts — GET و POST پست‌های وبلاگ
- src/app/api/admin/blog/[id]/route.ts — GET / PATCH / DELETE پست
- src/app/api/admin/settings/route.ts — GET و PUT singleton تنظیمات
- src/app/api/admin/polls/route.ts — GET (با shareUrl) و POST (با autoShare و shareToken)
- src/app/api/admin/polls/[id]/route.ts — GET (با _count و creator) / PATCH (با بازسازی گزینه‌ها) / DELETE
- src/app/api/admin/polls/[id]/share/route.ts — POST (ساخت shareToken) و DELETE (پاک‌سازی)
- src/app/api/admin/polls/[id]/csv/route.ts — GET خروجی CSV با BOM برای Excel فارسی
- src/app/api/admin/upload/route.ts — POST با formData، اعتبارسنجی نوع و اندازه (۲۰MB)، ذخیره در public/uploads با نام uuid
- src/app/api/polls/public/[token]/route.ts — GET عمومی (بدون تعداد پاسخ) + POST رای‌گیری با بررسی unique روی (pollId, anonymousToken) + کوکی poll_anon
- src/app/api/polls/[id]/results/route.ts — GET نتایج با درصد هر گزینه

Stage Summary:
- همه صفحات ادمین (داشبورد، کاربران، محتوا، گروه‌ها، نظرسنجی‌ها، نظرسنجی‌ساز، نتایج، تنظیمات) با موفقیت رندر می‌شوند (HTTP 200)
- همه APIهای ادمین به‌درستی با requireAdmin محافظت شده‌اند و پاسخ‌های JSON صحیح برمی‌گردانند
- جریان کامل نظرسنجی کار می‌کند: ایجاد → اشتراک‌گذاری → رای‌گیری عمومی → نمایش نتایج با نمودار Recharts → خروجی CSV
- جلوگیری از رای‌دهی دوگانه با unique constraint روی (pollId, anonymousToken) و کوکی + localStorage
- آپلود فایل به public/uploads با نام UUID و اعتبارسنجی نوع و اندازه (با fallback 413 برای لیمیت 10MB خود Next.js)
- RTL، فونت Vazirmatn، پالت گرم معنوی (سبز تیره/طلایی/کرم) و کامپوننت‌های shadcn/ui به‌صورت سازگار استفاده شده
- تست با مرورگر: ادمین با adminro/rooyeshp لاگین شد، داشبورد و تمام صفحات واجد داده‌ها بارگذاری شدند
- نکته: برای تست مرورگری نیاز به پاک‌سازی کوکی‌های NextAuth از سشن قبلی مربی بود
- نکته: در Next.js 16 پارامتر params در مسیرهای داینامیک به Promise تبدیل شده — همه route handlers و page components با await params به‌روز شدند
- نکته: مدل PollOption فیلد createdAt ندارد — orderBy روی id (نه createdAt) تنظیم شد
- نصب socket.io-client@4.8.4 چون کد پنل مربی (از agent دیگر) به آن وابسته بود و بدون آن بیلد سرور شکست می‌خورد
- هیچ خطای ESLint در فایل‌های ساخته‌شده نیست (خطای موجود در splash-screen.tsx و chat/message-bubble.tsx از کار agent دیگر است)

---
Task ID: 8
Agent: main
Task: تست نهایی و رفع خطاها

Work Log:
- تست کامل همه بخش‌ها با Agent Browser از طریق Caddy gateway (پورت 81)
- رفع مشکل: نصب socket.io-client (نبود کتابخانه کلاینت)
- رفع مشکل: سرویس chat-service با setsid -f اجرا شد تا از SIGTERM زنده بماند (PID 17811)
- رفع مشکل: اضافه کردن QueryClientProvider به providers.tsx (نبود context برای TanStack Query)
- رفع مشکل: splash-screen useState synchronously (lint error fixed)
- تأیید: صفحه اصلی با موفقیت رندر می‌شود (HTTP 200) با اسپلش چرخش لوگو ۳۶۰ درجه
- تأیید: هدر glassmorphism حبابی چسبان و جمع‌شونده هنگام اسکرول کار می‌کند
- تأیید: فوتر sticky در پایین قرار دارد
- تأیید: صفحه ورود با adminro/rooyeshp و coach1/coach123 کار می‌کند
- تأیید: پنل ادمین - داشبورد، کاربران، محتوا (وبلاگ+تنظیمات+معرفی)، گروه‌ها، نظرسنجی‌ها، نظرسنجی‌ساز (با color picker و پیش‌نمایش)، نتایج با Recharts و خروجی CSV، تنظیمات - همه کار می‌کنند
- تأیید: پنل مربی - داشبورد، گروه‌ها، تب‌های چت/اعضا/خلاصه‌ها، آپلود فایل صوتی و تولید خلاصه با AI - همه کار می‌کنند
- تأیید: چت گروهی Socket.IO واقعی - اتصال از طریق Caddy به پورت 3003، ارسال پیام، نمایش در زمان واقعی - کار می‌کند
- تأیید: AI Summary - فایل صوتی آپلود می‌شود، با Whisper به متن تبدیل می‌شود، با GPT خلاصه ساختاریافته فارسی تولید می‌شود، در دیتابیس ذخیره می‌شود، در UI نمایش داده می‌شود با audio player و دکمه‌های دانلود PDF و Markdown
- تأیید: نظرسنجی عمومی - صفحه پاسخ‌دهی بدون نیاز به ورود، جلوگیری از رای دوگانه با cookie/localStorage، نمایش نتایج با نمودار میله‌ای و دایره‌ای، خروجی CSV
- تأیید: ESLint بدون خطا
- تأیید: chat-service روی پورت 3003 از طریق Caddy gateway (?XTransformPort=3003) قابل دسترسی است
- تأیید: VLM تأیید کرد چیدمان RTL فارسی، پالت رنگی گرم معنوی، تایپوگرافی Vazirmatn همه درست هستند

Stage Summary:
- پروژه کامل و قابل اجراست
- ۳ نقش دسترسی: SUPER_ADMIN (adminro/rooyeshp)، COACH (coach1/coach123)، MEMBER (member1/member123)
- صفحه اصلی با اسپلش، هدر glassmorphism، هیرو، درباره، وبلاگ، CTA، فوتر sticky
- پنل ادمین کامل: مدیریت کاربران، محتوا، گروه‌ها، نظرسنجی‌ساز سفارشی، تنظیمات
- پنل مربی: زیرگروه‌ها، چت بلادرنگ، اعضا، خلاصه جلسات با AI
- پنل عضو: دسترسی به گروه‌ها، چت، خلاصه‌ها
- چت Socket.IO روی مینی‌سرویس جداگانه (پورت 3003)
- AI Summary با Whisper + GPT از طریق z-ai-web-dev-sdk
- نظرسنجی پویا با Recharts و خروجی CSV
- همه از طریق پورت 81 (Caddy gateway) قابل دسترسی است

---
Task ID: 9
Agent: main
Task: رفع دو مشکل - استخراج لوگوی واقعی از کانال ایتا + برطرف کردن toast box

Work Log:
- استخراج مجدد HTML کانال ایتا با page_reader
- یافتن URL واقعی لوگوی پروفایل کانال: `/download_a93323ffdfaec18e2033a43f32e44bbe?token=...`
- دانلود لوگوی اصلی (1280x1280 JPEG, 67KB)
- تأیید VLM: لوگو شامل پرچم ایران + متن «سامانه اطلاع رسانی» است (لوگوی اصلی کانال ایتا)
- ذخیره در `/public/institute-logo-real.jpg`
- به‌روزرسانی SiteSettings در دیتابیس برای استفاده از `/institute-logo-real.jpg`
- به‌روزرسانی آیکون در metadata صفحه به `/institute-logo-real.jpg`
- رفع مشکل toast box (Sonner):
  - مشکل اصلی: useToast اصلی شادکن از radix-toast استفاده می‌کرد که ToastViewport را در DOM رندر نمی‌کرد
  - جایگزینی useToast با delegate به sonner (toast و toast.error)
  - جایگزینی `<Toaster />` از radix به `<Toaster />` از sonner در layout.tsx
  - اضافه کردن Toaster داخل Providers (نه به عنوان خواهر)
  - حذف وابستگی به next-themes در sonner.tsx (که نصب نشده)
  - تنظیم position="top-center" richColors closeButton dir="rtl"
- تأیید VLM: کادر اعلان خطا «عنوان نظرسنجی الزامی است» با پس‌زمینه صورتی در بالای صفحه دیده می‌شود
- تأیید VLM: لوگوی اصلی کانال ایتا (پرچم ایران + متن) در صفحه‌ی اصلی نمایش داده می‌شود

Stage Summary:
- لوگوی واقعی موسسه از پروفایل کانال ایتا استخراج و جایگزین لوگوی AI تولیدشده شد
- سیستم toast اکنون به‌طور کامل کار می‌کند (Sonner با position top-center و richColors)
- همه‌ی toast notifications حالا در جای مناسب نمایش داده می‌شوند (اعلان موفق، خطا، information)
- ESLint بدون خطا

---
Task ID: 10
Agent: main
Task: تست کامل بخش لاگین از ابتدا تا انتها و رفع خطاها

Work Log:
- بررسی وضعیت سرور: Next.js dev server متوقف شده بود، با setsid -f راه‌اندازی مجدد شد
- تست ۱: ورود مدیر (adminro/rooyeshp) — موفق، به /admin منتقل شد
- تست ۲: ورود مربی (coach1/coach123) — موفق، به /coach منتقل شد
- تست ۳: ورود عضو (member1/member123) — خطای module-not-found در /member/layout.tsx
- رفع خطا: ایمپورت `next/auth` (اشتباه) به `next-auth` (درست) اصلاح شد
- تست ۳ (پس از رفع): ورود عضو موفق، به /member منتقل شد
- تست ۴: ورود با credentials اشتباه — موفق، پیام خطای "نام کاربری یا رمز عبور اشتباه است" نمایش داده شد
- تست ۵: ارسال فرم خالی — دکمه ورود به‌درستی disabled است (محافظت HTML5)
- تست ۶: دسترسی به مسیر محافظت‌شده بدون لاگین — به /login?callbackUrl=/admin منتقل شد
- تست ۷: ورود با callbackUrl — پس از ورود به /admin منتقل شد
- بهبود لاگین: اضافه کردن onClick مستقیم روی دکمه (به‌علاوه form onSubmit) برای reliability بیشتر
- بهبود لاگین: اضافه کردن Suspense boundary به useSearchParams (الزام Next.js 16)
- رفع مشکل logout: استفاده از window.location.origin برای callbackUrl (به جای '/' که به پورت 3000 هدایت می‌کرد)
- اضافه کردن trustHost: true به auth config برای تشخیص صحیح URL از طریق Caddy gateway
- به‌روزرسانی لوگوی صفحه ورود به /institute-logo-real.jpg (لوگوی واقعی کانال ایتا)

Stage Summary:
- بخش لاگین کامل و کارآمد است
- ۳ نقش دسترسی همگی کار می‌کنند: SUPER_ADMIN → /admin، COACH → /coach، MEMBER → /member
- خطای module-not-found در member/layout.tsx رفع شد
- logout اکنون به‌درستی به همان host (پورت 81 از طریق Caddy) منتقل می‌کند
- لوگوی صفحه ورود همان لوگوی واقعی موسسه (پرچم ایران + متن) است
- VLM تأیید کرد: "ترکیبی از پرچم ملی ایران و نام موسسه به صورت گرافیکی و آبی‌رنگ در داخل یک قاب دایره‌ای"
- ESLint بدون خطا
- ۷ تست مختلف لاگین همگی موفق بودند

---
Task ID: 11
Agent: main
Task: رفع مشکل عدم نمایش سایت در سندباکس — پاک‌سازی نمونه‌های تکراری و راه‌اندازی watchdog

Work Log:
- تشخیص مشکل: چندین نمونه‌ی تکراری از `bun run dev` همزمان اجرا می‌شدند که باعث تداخل و Crash شدن می‌شد
- پاک‌سازی همه‌ی فرآیندها با pkill -9
- پاک‌سازی .next cache برای build تازه
- راه‌اندازی watchdog خودکار (/tmp/dev-watchdog.sh) که با setsid -f اجرا شده و در صورت crash خودکار restart می‌کند
- راه‌اندازی مجدد چت سرویس روی پورت 3003
- ایجاد اسکریپت health-check برای پایش وضعیت سرویس‌ها

Stage Summary:
- سرور Next.js روی پورت 3000 فعال (200)
- Caddy Gateway روی پورت 81 فعال (200)
- چت سرویس Socket.IO روی پورت 3003 فعال
- عنوان صفحه: «موسسه رویش‌های پیشران»
- صفحه اصلی در مرورگر agent-browser کامل بارگذاری می‌شود (هدر، هیرو، وبلاگ، CTA، فوتر)
- watchdog خودکار سرور را زنده نگه می‌دارد

---
Task ID: 12
Agent: main
Task: رفع مشکل عدم نمایش سایت در سندباکس — استفاده از production build با watchdog دائمی

Work Log:
- تشخیص مشکل: سرور dev بارها crash می‌کرد و باعث 502 Bad Gateway از Caddy می‌شد
- کشف production build در /tmp/build_fullstack_1791825200/next-service-dist/server.js
- ساخت اسکریپت start-sandbox.sh که:
  - از production build (نه dev) استفاده می‌کند
  - با setsid -f اجرا می‌شود تا از shell جدا بماند
  - watchdog داخلی دارد که در صورت crash خودکار restart می‌کند
  - Next.js روی پورت 3000
  - چت سرویس روی پورت 3003
  - Caddy روی پورت 81 (از قبل فعال بود)
- راه‌اندازی watchdog در PID 4170 با ۳ فرآیند فرزند:
  - PID 4181: Next.js production server
  - PID 4182: Chat service production
  - PID 4183: Watchdog loop
- تأیید پایداری پس از ۳۰ ثانیه: همه سرویس‌ها همچنان فعال بودند
- تست ورود مدیر (adminro/rooyeshp) در مرورگر: موفق، به /admin منتقل شد
- VLM تأیید کرد: داشبورد ادمین با آمار، منوی کناری، و بخش‌های آخرین فعالیت‌ها نمایش داده می‌شود

Stage Summary:
- سایت production اکنون پایدار است
- watchdog خودکار هر ۶۰ ثانیه بررسی می‌کند و در صورت نیاز restart می‌کند
- همه مسیرها کار می‌کنند: / (صفحه اصلی)، /login، /admin، /coach، /member
- عنوان صفحه: «موسسه رویش‌های پیشران»
- لوگوی اصلی موسسه (پرچم ایران + متن) در همه صفحات

---
Task ID: 13
Agent: main
Task: رفع چند مورد - آپلود فایل در نظرسنجی، ساخت نظرسنجی برای مربی، حذف حساب‌های آزمایشی، لوگوی واقعی، اتصال چت

Work Log:
- اتصال چت: اطمینان از فعالیت چت سرویس روی پورت 3003 و route شدن صحیح از Caddy
- لوگوی واقعی: به‌روزرسانی splash-screen.tsx برای استفاده از institute-logo-real.jpg
- حذف حساب‌های آزمایشی: حذف بخش نمایش رمز adminro/rooyeshp و coach1/coach123 از صفحه ورود
  - جایگزینی با متن «برای دریافت حساب کاربری، با مربی گروه خود تماس بگیرید»
- افزودن قابلیت آپلود فایل در نظرسنجی:
  - به‌روزرسانی schema.prisma: اضافه شدن allowFileUpload, fileUploadLabel, fileUploadRequired به Poll
  - اضافه شدن fileUrl, fileName, fileType به PollResponse
  - به‌روزرسانی /api/admin/polls POST برای پذیرش فیلدهای جدید
  - به‌روزرسانی /api/polls/public/[token] POST برای پذیرش multipart/form-data با فایل
  - اضافه شدن UI در poll-vote-client.tsx: نمایش فیلد آپلود با برچسب سفارشی و حالت required
  - اضافه شدن section در نتایج ادمین (poll-results-client.tsx) با نمایش grid از فایل‌های آپلودشده
- فعال‌سازی ساخت نظرسنجی برای مربی‌ها:
  - به‌روزرسانی proxy.ts: مسیر /api/admin/polls اجازه دسترسی به SUPER_ADMIN و COACH
  - ساخت /api/coach/polls/route.ts با re-export از admin
  - ساخت /api/coach/polls/[id]/share و /api/coach/polls/[id]/csv
  - ساخت /coach/polls/new/page.tsx برای نمایش فرم ساخت نظرسنجی
  - به‌روزرسانی poll-builder-client.tsx برای تشخیص مسیر (admin یا coach) و انتخاب API درست
  - به‌روزرسانی /coach/polls/page.tsx برای نمایش دکمه «نظرسنجی جدید» و لینک ساخت

Stage Summary:
- چت سرویس متصل می‌شود: کاربر می‌تواند به گروه بپیوندد و پیام بفرستد
- splash screen از لوگوی واقعی موسسه استفاده می‌کند
- صفحه ورود دیگر رمزهای آزمایشی را نمایش نمی‌دهد
- در فرم ساخت نظرسنجی: تیک «اجازه آپلود فایل توسط مخاطب» با برچسب و گزینه required
- مخاطب می‌تواند فایل را آپلود کند هنگام پاسخ‌دهی
- نتایج در صفحه ادمین شامل بخش «فایل‌های آپلودشده توسط مخاطبان» با grid gallery
- مربی‌ها اکنون می‌توانند نظرسنجی بسازند (همان قابلیت‌های ادمین)
- همه تغییرات با موفقیت تست شدند (نظرسنجی ساخته شد، vote ثبت شد، نتایج نمایش داده شد)

---
Task ID: 14
Agent: main
Task: رفع دو مشکل - سایت بدون فیلترشکن بالا بیاید + گزینه پاسخ تشریحی در نظرسنجی

Work Log:
- علت مشکل ۱: فونت Vazirmatn از CDN خارجی (cdn.jsdelivr.net) بارگذاری می‌شد که در ایران مسدود است
- دانلود ۹ فایل woff2 فونت Vazirmatn (Thin تا Black) به مسیر /public/fonts/
- اضافه کردن ۹ @font-face declaration مستقیماً در globals.css (بدون @import خارجی)
- پاک‌سازی .next cache و restart dev server برای اعمال تغییرات
- تأیید: هیچ درخواست خارجی به CDN در مرورگر ارسال نمی‌شود
- علت مشکل ۲: فقط چندگزینه‌ای (radio) پشتیبانی می‌شد
- به‌روزرسانی schema.prisma: اضافه شدن pollType (multiple/descriptive) به Poll، textResponse به PollResponse، optionId اختیاری شد
- به‌روزرسانی /api/admin/polls POST: پذیرش pollType، validation متفاوت برای حالت تشریحی
- به‌روزرسانی /api/polls/public/[token]: پذیرش textResponse در JSON و FormData
- به‌روزرسانی poll-vote-client.tsx: نمایش textarea به جای radio در حالت تشریحی، ارسال textResponse
- به‌روزرسانی poll-builder-client.tsx: اضافه شدن UI انتخاب نوع نظرسنجی (radio بین multiple و descriptive)
- پنهان کردن بخش گزینه‌ها در حالت تشریحی
- به‌روزرسانی /admin/polls/[id]/page.tsx: query پاسخ‌های تشریحی (optionId: null)
- به‌روزرسانی poll-results-client.tsx: نمایش section «پاسخ‌های تشریحی» با متن، فایل، نام فرستنده، تاریخ

Stage Summary:
- سایت بدون فیلترشکن بالا می‌آید (هیچ منبع خارجی بارگذاری نمی‌شود)
- در فرم ساخت نظرسنجی: انتخاب بین «چندگزینه‌ای» و «تشریحی (متن آزاد)»
- در حالت تشریحی: گزینه‌ها پنهان می‌شوند و یک textarea نمایش داده می‌شود
- مخاطب می‌تواند متن آزاد بنویسد (می‌تواند همراه با فایل آپلودی باشد)
- در صفحه نتایج ادمین: بخش «پاسخ‌های تشریحی» با نمایش متن + فایل + نام + تاریخ
- ESLint بدون خطا
- تست کامل: ساخت نظرسنجی تشریحی، vote مخاطب، نمایش نتایج در ادمین - همه موفق
- VLM تأیید کرد: «بخش پاسخ‌های تشریحی دیده می‌شود و پاسخ تستی نمایش داده شده»

---
Task ID: 15
Agent: main
Task: رفع مشکل عدم نمایش بدون فیلترشکن - سوییچ به production mode

Work Log:
- بررسی دقیق: هیچ منبع خارجی در کد وجود ندارد (هیچ CDN، analytics، یا external script)
- علت احتمالی: در حالت dev، Next.js یک WebSocket برای HMR (Hot Module Replacement) باز می‌کند
  - این WebSocket در ایران ممکن است مسدود یا کند شود
  - همچنین dev server هر بار صفحه را on-the-fly compile می‌کند که کند است
- راه‌حل: سوییچ به production mode
  - اجرای `bun run build` برای تولید production build
  - production mode ویژگی‌های زیر را دارد:
    • بدون HMR WebSocket (هیچ اتصال WebSocket اضافی برای dev)
    • صفحات pre-compile شده (بدون on-the-fly compilation)
    • پاسخ بسیار سریع‌تر
- ساخت start-sandbox.sh جدید که production server را اجرا می‌کند
  - run_next: `bun run start` به جای `bun run dev`
  - watchdog خودکار برای restart در صورت crash
- تأیید سرعت:
  - صفحه ورود: 13ms (قبلاً 500ms+ در dev)
  - داشبورد ادمین: 18ms (قبلاً 2s+ در dev)
- تأیید: هیچ درخواست خارجی در network requests نیست
- تأیید: هیچ HMR/WebSocket connection در console نیست
- چت سرویس همچنان فعال روی پورت 3003

Stage Summary:
- سایت اکنون در production mode اجرا می‌شود
- سرعت پاسخ بسیار بالا (۱۳-۱۸ میلی‌ثانیه)
- بدون HMR WebSocket (که ممکن است بدون فیلترشکن مشکل ایجاد کند)
- بدون هیچ منبع خارجی
- چت سرویس همچنان فعال
- watchdog خودکار سرور را زنده نگه می‌دارد

---
Task ID: 11
Agent: full-stack-developer (coach/member panel redesign)
Task: بازطراحی پنل مربی و عضو - گروه واحد + داشبورد یکپارچه

Work Log:
- `src/app/api/coach/groups/route.ts` — بازنویسی کامل: GET فقط اولین گروه مربی را برمی‌گرداند (یا null)، POST قبل از ساخت چک می‌کند که مربی گروهی نداشته باشد و در غیر این صورت 400 با پیام «شما قبلاً یک گروه ساخته‌اید» می‌دهد.
- `src/app/api/member/groups/route.ts` — بازنویسی: GET فقط یک گروه (گروه مالک‌شده برای مربی، یا اولین عضویت برای عضو) برمی‌گرداند یا null.
- `src/components/coach/create-group-form.tsx` — کامپوننت جدید: فرم inline (نه dialog) برای ساخت گروه، با toast و router.refresh.
- `src/components/coach/coach-dashboard.tsx` — کامپوننت جدید: داشبورد یکپارچه با ۳ تب (چت/اعضا/خلاصه‌ها) که `<GroupChat>` + `<GroupMembersManager>` + `<GroupSummariesManager>` را در یک صفحه می‌چیند.
- `src/components/member/member-dashboard.tsx` — کامپوننت جدید: نسخه عضو با ۲ تب (چت/خلاصه‌ها - فقط خواندنی، بدون آپلود).
- `src/app/coach/page.tsx` — بازنویسی کامل: اگر مربی گروه ندارد، فرم ساخت inline نشان داده می‌شود؛ اگر دارد، هدر گروه + ۳ کارت آماری + `<CoachDashboard>` با تب‌ها.
- `src/app/member/page.tsx` — بازنویسی کامل: اگر عضو گروهی ندارد، پیام «شما هنوز به گروهی اضافه نشده‌اید»؛ اگر دارد، هدر گروه + آمار + `<MemberDashboard>` با ۲ تب.
- `src/components/panel/panel-sidebar.tsx` — حذف لینک «گروه‌های من» از هر دو coachNavLinks و memberNavLinks و حذف import بلااستفاده Users.
- `src/app/coach/summaries/page.tsx` — به‌روزرسانی لینک‌های «گروه‌ها» به «داشبورد».
- حذف `src/app/coach/groups/page.tsx` و `src/app/coach/groups/[id]/page.tsx`.
- حذف `src/app/member/groups/page.tsx` و `src/app/member/groups/[id]/page.tsx`.
- راه‌اندازی مجدد مینی‌سرویس Socket.IO روی پورت 3003 (قبلاً متوقف شده بود — نصب وابستگی‌ها و اجرای setsid bun --hot).
- نگه‌داشتن API های `/api/coach/groups/[id]/*` (members management) برای استفاده در `<GroupMembersManager>`.

Stage Summary:
- پنل مربی: هر مربی فقط یک گروه دارد. وقتی coach1/coach123 وارد می‌شود، داشبورد یکپارچه با ۳ تب (چت/اعضا/خلاصه‌ها) نمایش داده می‌شود. وقتی مربی بدون گروه وارد می‌شود (تست با coach2 موقت)، فرم inline ساخت گروه نمایش داده می‌شود و پس از ساخت گروه، داشبورد تب‌دار ظاهر می‌شود.
- پنل عضو: عضو گروه (member1/member123) داشبورد با ۲ تب (چت/خلاصه‌ها - فقط خواندنی) می‌بیند. عضو بدون گروه پیام «شما هنوز به گروهی اضافه نشده‌اید» می‌بیند (تست با member2 موقت).
- سایدبار هر دو پنل ساده شد: فقط «داشبورد»، «نظرسنجی‌ها»، «خلاصه جلسات» — بدون «گروه‌های من».
- مسیرهای /coach/groups و /member/groups حذف شدند (دیگر لازم نیستند).
- API های groups با احترام به قانون single-group بازنویسی شدند.
- چت Socket.IO روی پورت 3003 فعال شد (از طریق Caddy gateway با ?XTransformPort=3003).
- تست با agent-browser:
  - coach1/coach123 → /coach: گروه «حلقه نوجوانان پیشران» + ۳ تب کار می‌کنند (چت متصل، اعضا با ۱ عضو نمایش داده شد، خلاصه‌ها خالی).
  - member1/member123 → /member: همان گروه + ۲ تب (چت + خلاصه‌ها) کار می‌کنند.
  - coach2 (آزمایشی بدون گروه) → /coach: فرم ساخت گروه نمایش داده شد، پس از ساخت گروه داشبورد تب‌دار ظاهر شد.
  - member2 (آزمایشی بدون گروه) → /member: پیام «شما هنوز به گروهی اضافه نشده‌اید» نمایش داده شد.
  - تب‌ها با mousedown کار می‌کنند (Radix از mousedown استفاده می‌کند، نه click).
- ESLint بدون خطا.
- HTTP 200 برای /coach و /member.
- تست‌های موقت (coach2، member2، گروه آزمایشی) پس از تأیید پاک‌سازی شدند.
- فایل کار این agent: `/home/z/my-project/agent-ctx/11-coach-member-redesign.md`

---
Task ID: 12
Agent: main
Task: بازطراحی بزرگ - لوگو، هدر، موبایل، آپلود، گروه واحد

Work Log:
- تولید لوگوی جدید سه‌بعدی فیروزه‌ای/آبی با متن «رویش‌های پیشران» (بر اساس تصویر ارسالی کاربر)
- حذف پس‌زمینه با sharp (تبدیل به PNG شفاف)
- به‌روزرسانی SiteSettings و همه ارجاعات لوگو به /institute-logo-transparent.png
- بازطراحی کامل هدر: حذف dropdown پروفایل، همه چیز در منوی کشویی هامبرگر (slide-in drawer با framer-motion)
- منوی کشویی شامل: لوگو+نام، اطلاعات کاربر (اگر وارد شده)، لینک‌های ناوبری، پیشخان/پروفایل/خروج
- اصلاح واکنش‌گرایی موبایل در globals.css:
  - overflow-x: hidden روی html و body
  - text-size-adjust: 100% برای جلوگیری از زوم خودکار
  - font-size: 16px برای inputها در موبایل (جلوگیری از زوم iOS)
  - min-height: 100dvh (اصلاح مشکل 100vh در مرورگرهای موبایل)
  - touch-action: manipulation برای دکمه‌ها
  - breakpoint جدید برای گوشی‌های خیلی کوچک (max-width: 380px)
- ساخت مسیرهای API آپلود که اصلاً وجود نداشتند:
  - /api/admin/upload/route.ts
  - /api/coach/upload/route.ts
  - /api/member/upload/route.ts
  - همه با اعتبارسنجی نوع فایل، محدودیت ۵۰MB، نام فایل UUID
- اصلاح کامپوننت FileUpload: استفاده از input بومی به جای shadcn Input (مشکل ref forwarding)
- استفاده از sr-only به جای hidden (display:none می‌تواند جلوی انتخاب فایل را بگیرد)
- افزودن endpoint prop به FileUpload برای پشتیبانی از مسیرهای آپلود مختلف
- ذخیره schema.postgresql.prisma برای استقرار production (تغییر schema اصلی به SQLite برای dev محلی)
- راه‌اندازی مجدد دیتابیس و seed
- تست کامل با agent-browser روی viewport موبایل (375px - iPhone SE):
  - صفحه اصلی: بدون اسکرول افقی ✓
  - صفحه ورود: بدون اسکرول افقی ✓
  - داشبورد مربی: بدون اسکرول افقی ✓
  - منوی هامبرگر باز و بسته می‌شود ✓

Stage Summary:
- لوگوی جدید سه‌بعدی فیروزه‌ای بدون پس‌زمینه جایگزین لوگوی قبلی شد
- هدر فقط لوگو + آیکون منوی سه خط دارد (بدون dropdown پروفایل)
- منوی کشویی slide-in با همه گزینه‌ها (ناوبری + پیشخان + پروفایل + خروج)
- آپلود فایل در همه بخش‌ها کار می‌کند (API routes + کامپوننت اصلاح‌شده)
- واکنش‌گرایی موبایل اصلاح شد (بدون اسکرول افقی، اندازه فونت درست، touch targets مناسب)
- هر مربی فقط یک گروه دارد (داشبورد یکپارچه با تب‌های چت/اعضا/خلاصه)
- ESLint بدون خطا

---
Task ID: 13
Agent: main
Task: استفاده از لوگوی اصلی کاربر (نه AI تولیدشده) - رفع اشتباه

Work Log:
- بررسی فایل آپلود شده کاربر: /home/z/my-project/upload/file_000000000c9472469f8c4173da6b5ffa.png
- کشف اینکه فایل کاربر از قبل پس‌زمینه شفاف دارد (690K transparent pixels, 545K opaque, گوشه‌ها alpha=0)
- کپی فایل کاربر به /home/z/my-project/public/institute-logo-final.png
- به‌روزرسانی SiteSettings در دیتابیس به /institute-logo-final.png
- جایگزینی همه ارجاعات لوگو در کد:
  - src/app/layout.tsx (favicon)
  - src/components/splash-screen.tsx
  - src/app/login/page.tsx
  - src/components/landing-page-client.tsx
- حذف فایل‌های لوگوی AI تولیدشده (institute-logo-3d, transparent, v2, real)
- اصلاح CSS نمایش لوگو:
  - صفحه ورود: حذف rounded-full و ring-4 (مخصوص آواتار بود)، استفاده از w-48 + object-contain
  - هیرو: حذف rounded-full و ring، افزایش اندازه به 240x160، حفظ نسبت تصویر
  - هدر: h-10/h-12 w-auto (به جای w-11 h-11 که مربعی می‌کرد)
  - منوی کشویی: h-10 w-auto
  - اسپلش: w-48 h-32 (به جای w-32 h-32 مربعی)
- تأیید VLM: لوگو با متن خوانا، رنگ آبی فیروزه‌ای سه‌بعدی، بدون کادر سفید، پس‌زمینه شفاف روی پس‌زمینه کرم/سبز سایت

Stage Summary:
- لوگوی اصلی کاربر (تصویر آپلود شده) حالا در همه صفحات استفاده می‌شود
- پس‌زمینه شفاف است (فایل کاربر از قبل transparent بود)
- هیچ کادر سفیدی اطراف لوگو نیست
- اندازه لوگو بزرگ‌تر و متناسب با نسبت تصویر (1536x1024)
- ESLint بدون خطا
