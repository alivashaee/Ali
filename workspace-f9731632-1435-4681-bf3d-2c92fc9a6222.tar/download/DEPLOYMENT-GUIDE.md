# 📦 راهنمای استقرار سایت موسسه رویش‌های پیشران

## ⚠️ نکته‌ی مهم درباره‌ی InfinityFree

**InfinityFree برای این پروژه کار نمی‌کند!**

InfinityFree یک هاست رایگان **PHP/HTML** است. اما سایت ما با **Next.js 16** ساخته شده که به موارد زیر نیاز دارد:
- ❌ Node.js runtime (InfinityFree فقط PHP دارد)
- ❌ PostgreSQL یا SQLite (InfinityFree فقط MySQL با محدودیت دارد)
- ❌ WebSocket برای چت بلادرنگ (InfinityFree پشتیبانی نمی‌کند)
- ❌ اجرای پراسس‌های پس‌زمینه (برای AI summary)

بنابراین **امکان‌پذیر نیست** سایت روی InfinityFree بالا بیاید.

---

## ✅ گزینه‌های رایگان مناسب برای Next.js

### ۱. Render (پیشنهاد اول - رایگان و کامل) ✅
**بهترین گزینه** - پشتیبانی کامل از:
- ✅ Node.js runtime
- ✅ PostgreSQL رایگان (۵۰۰MB)
- ✅ WebSocket برای چت
- ✅ Background processes
- ✅ اتصال دامنه‌ی سفارشی رايگان

آموزش راه‌اندازی:
1. ثبت‌نام در https://render.com با GitHub
2. Push کد پروژه به GitHub
3. New → PostgreSQL Database (رایگان)
4. New → Web Service → از GitHub
5. Environment Variables:
   - DATABASE_URL = postgresql://...
   - NEXTAUTH_SECRET = رشته‌ی ۳۲ کاراکتری تصادفی
6. Build Command: `bun install && bun run build`
7. Start Command: `bun run start`

### ۲. Railway (رایگان با محدودیت) ✅
1. ثبت‌نام در https://railway.app با GitHub
2. New Project → از GitHub
3. اضافه کردن PostgreSQL
4. اضافه کردن Environment Variables
5. Deploy خودکار

### ۳. Vercel (فقط فرانت‌اند) ⚠️
**محدودیت**: Vercel از WebSocket پشتیبانی نمی‌کند.
- فرانت‌اند روی Vercel (رایگان)
- چت سرویس جدا روی Render
- دیتابیس روی Neon (رایگان)

### ۴. Fly.io (رایگان) ✅
- پشتیبانی کامل از Node.js و WebSocket
- دیتابیس PostgreSQL رایگان

---

## 🚀 آموزش کامل استقرار روی Render (پیشنهادی)

### مرحله ۱: آماده‌سازی کد

```bash
# فایل پروژه را از حالت فشرده خارج کنید
tar -xzf rooyesh-pishran-website.tar.gz

# ویرایش prisma/schema.prisma — تغییر SQLite به PostgreSQL
# (به جای provider = "sqlite" → provider = "postgresql")

# ایجاد فایل .env با محتواهای زیر:
DATABASE_URL=postgresql://user:pass@host:5432/dbname
NEXTAUTH_SECRET=یک-رشته-تصادفی-۳۲-کاراکتری
NEXTAUTH_URL=https://rooyeshpishran.onrender.com
```

### مرحله ۲: Push به GitHub

```bash
git init
git add .
git commit -m "Initial commit - Rooyesh Pishran website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/rooyesh-pishran.git
git push -u origin main
```

### مرحله ۳: ساخت PostgreSQL در Render

1. به https://dashboard.render.com بروید
2. **New +** → **PostgreSQL**
3. Name: `rooyesh-db`
4. Plan: **Free**
5. **Create Database**
6. اطلاعات اتصال را کپی کنید (DATABASE_URL)

### مرحله ۴: ساخت Web Service در Render

1. **New +** → **Web Service**
2. اتصال به GitHub repository
3. تنظیمات:
   - **Name**: `rooyesh-pishran`
   - **Runtime**: Node.js
   - **Build Command**: `npm install && npx prisma generate && npx prisma db push && npm run build`
   - **Start Command**: `npm run start`
   - **Plan**: Free
4. Environment Variables:
   ```
   DATABASE_URL=<از مرحله ۳>
   NEXTAUTH_SECRET=<رشته تصادفی>
   NEXTAUTH_URL=https://rooyesh-pishran.onrender.com
   ```
5. **Create Web Service**

### مرحله ۵: ساخت Chat Service جدا در Render

1. **New +** → **Web Service** (دومی)
2. تنظیمات:
   - **Root Directory**: `mini-services/chat-service`
   - **Build Command**: `npm install`
   - **Start Command**: `node index.js`
   - **Plan**: Free
3. Environment Variables:
   ```
   DATABASE_URL=<همان مقدار>
   ```

### مرحله ۶: اتصال دامنه‌ی سفارشی (رایگان)

#### گزینه‌ی الف: استفاده از دامنه‌ی رایگان Render
- پس از deploy، آدرس شما چیزی مثل `https://rooyesh-pishran.onrender.com` خواهد بود
- این دامنه‌ی رایگان است و همیشه فعال می‌ماند

#### گزینه‌ی ب: دامنه‌ی رایگان از Freenom
1. به https://freenom.com بروید
2. یک دامنه‌ی رایگان پیدا کنید (مثل `rooyeshpishran.tk`)
3. ثبت دامنه
4. در تنظیمات DNS دامنه:
   - رکورد A → IP سرور Render
   - یا رکورد CNAME → `rooyesh-pishran.onrender.com`
5. در Render: Settings → Custom Domain → اضافه کردن دامنه

#### گزینه‌ی ج: دامنه‌ی رایگان از InfinityFree (فقط DNS)
می‌توانید از InfinityFree فقط به عنوان **DNS و CDN** استفاده کنید:
1. در InfinityFree دامنه را ثبت کنید
2. در کنترل پنل دامنه:
   - Cloudflare DNS → رکورد CNAME → `rooyesh-pishran.onrender.com`
3. حالا `rooyeshpishran.web1337.net` به سایت شما در Render اشاره می‌کند

---

## 📁 ساختار فایل‌های پروژه

```
rooyesh-pishran-website/
├── src/                    # کد اصلی Next.js
│   ├── app/
│   │   ├── admin/          # پنل ادمین
│   │   ├── coach/          # پنل مربی
│   │   ├── member/         # پنل عضو
│   │   ├── api/            # API routes
│   │   ├── login/          # صفحه ورود
│   │   └── page.tsx        # صفحه اصلی
│   ├── components/         # کامپوننت‌های React
│   └── lib/                # تنظیمات auth, db, etc.
├── prisma/
│   ├── schema.prisma       # مدل دیتابیس
│   └── seed.ts             # داده‌های اولیه (adminro/rooyeshp)
├── public/
│   ├── institute-logo-real.jpg  # لوگوی واقعی موسسه
│   └── hero-bg.jpg
├── mini-services/
│   └── chat-service/       # سرویس Socket.IO جدا
├── package.json
└── .env                    # متغیرهای محیطی

## حساب‌های آماده (seed شده)
- مدیر اصلی: adminro / rooyeshp
- مربی نمونه: coach1 / coach123
- عضو نمونه: member1 / member123
```

---

## 🔧 تغییرات مورد نیاز برای Production

### ۱. تغییر دیتابیس از SQLite به PostgreSQL

در فایل `prisma/schema.prisma`:

```prisma
datasource db {
  provider = "postgresql"  // به جای sqlite
  url      = env("DATABASE_URL")
}
```

### ۲. تغییر Caddyfile (برای Render نیازی نیست - خود Render HTTPS دارد)

### ۳. فعال کردن production mode

```bash
# نصب dependencies
npm install --production

# build
npm run build

# start
npm run start
```

---

## ❓ چرا InfinityFree کار نمی‌کند؟

| نیازمندی پروژه | InfinityFree | سایتی که ما ساختیم |
|----------------|-------------|-------------------|
| Node.js runtime | ❌ PHP فقط | ✅ Next.js 16 |
| PostgreSQL/SQLite | ❌ MySQL محدود | ✅ Prisma ORM |
| WebSocket | ❌ غیرفعال | ✅ Socket.IO |
| Background jobs | ❌ نه | ✅ AI Summary |
| npm/bun | ❌ نه | ✅ نیاز است |
| File persistence | ❌ موقت | ✅ نیاز دائمی |

## 📞 پشتیبانی

اگر کمک لازم دارید:
- GitHub Issues: ایجاد issue در repository
- Render Docs: https://render.com/docs
- Next.js Docs: https://nextjs.org/docs

---

## 💡 خلاصه

1. **InfinityFree برای این پروژه مناسب نیست** (PHP host، نه Node.js)
2. **بهترین گزینه‌ی رایگان: Render.com** (پشتیبانی کامل)
3. فایل پروژه در `rooyesh-pishran-website.tar.gz` آماده است
4. با راهنمای بالا می‌توانید سایت را در ۳۰ دقیقه بالا بیاورید

موفق باشید! 🌱
