<?php
/**
 * وب پروکسی موسسه رویش‌های پیشران
 * 
 * این فایل را روی هاست InfinityFree خود آپلود کنید
 * سایت از طریق دامنه‌ی شما قابل دسترسی خواهد بود (بدون فیلترشکن)
 * 
 * راه‌اندازی:
 * 1. این فایل را در public_html آپلود کنید
 * 2. آدرس preview سندباکس را در متغیر TARGET_URL زیر قرار دهید
 *    (آدرسی که وقتی در پنل پیش‌نمایش روی "Open in New Tab" کلیک می‌کنید باز می‌شود)
 * 3. فایل .htaccess را کنار این فایل آپلود کنید
 * 4. سایت از طریق: http://rooyeshpishran.web1337.net/ قابل دسترسی است
 */

// =====================================
// تنظیمات - اینجا را ویرایش کنید
// =====================================

// آدرس preview سندباکس را اینجا بگذارید
// این همان آدرسی است که در پنل پیش‌نمایش بعد از کلیک روی "Open in New Tab" در نوار آدرس مرورگر می‌بینید
// مثال: https://abc123.preview.z.ai  یا  http://something.z.ai
$TARGET_URL = 'https://PREVIEW_URL_HERE'; // ← این را با آدرس واقعی جایگزین کنید

// =====================================
// پایان تنظیمات - کد زیر را تغییر ندهید
// =====================================

// حذش اسلش آخر
$TARGET_URL = rtrim($TARGET_URL, '/');

// گرفتن مسیر درخواست
$uri = $_SERVER['REQUEST_URI'];
// حذف نام فایل proxy.php از ابتدا اگر وجود دارد
$uri = preg_replace('#^/proxy\.php#', '', $uri);
// اگر مسیر خالی است، از / استفاده کن
if (empty($uri) || $uri === '/') {
    $uri = '/';
}

// ساخت URL کامل
$full_url = $TARGET_URL . $uri;

// دریافت query string
if (!empty($_SERVER['QUERY_STRING'])) {
    // حذف پارامترهای داخلی proxy
    parse_str($_SERVER['QUERY_STRING'], $query_params);
    // اگر query string فقط paramهای داخلی نبود
    $full_url .= '?' . $_SERVER['QUERY_STRING'];
}

// روش درخواست
$method = $_SERVER['REQUEST_METHOD'];

// آماده‌سازی هدرها برای ارسال
$request_headers = array();
$request_headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36';
$content_type = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
if ($content_type) {
    $request_headers[] = 'Content-Type: ' . $content_type;
}
// ارسال کوکی‌ها
if (!empty($_SERVER['HTTP_COOKIE'])) {
    $request_headers[] = 'Cookie: ' . $_SERVER['HTTP_COOKIE'];
}
// ارسال Accept headers
if (!empty($_SERVER['HTTP_ACCEPT'])) {
    $request_headers[] = 'Accept: ' . $_SERVER['HTTP_ACCEPT'];
}
if (!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
    $request_headers[] = 'Accept-Language: ' . $_SERVER['HTTP_ACCEPT_LANGUAGE'];
}

// دریافت body درخواست
$body = '';
if ($method === 'POST' || $method === 'PUT' || $method === 'PATCH') {
    $body = file_get_contents('php://input');
}

// اگر multipart/form-data است، فایل‌ها را هم پاس بده
$post_fields = null;
if ($method === 'POST' && strpos($content_type, 'multipart/form-data') !== false) {
    $post_fields = $_POST;
    // فایل‌ها را هم اضافه کن
    if (!empty($_FILES)) {
        foreach ($_FILES as $key => $file) {
            if ($file['error'] === UPLOAD_ERR_OK) {
                $post_fields[$key] = new CURLFile($file['tmp_name'], $file['type'], $file['name']);
            }
        }
    }
}

// راه‌اندازی cURL
$ch = curl_init($full_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
curl_setopt($ch, CURLOPT_HTTPHEADER, $request_headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false); // خودمان redirect می‌کنیم
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);

// ارسال body
if ($method === 'POST' && $post_fields !== null) {
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
} elseif ($body) {
    curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
}

// ذخیره هدرهای پاسخ
$response_headers = array();
curl_setopt($ch, CURLOPT_HEADERFUNCTION, function($curl, $header) use (&$response_headers) {
    $len = strlen($header);
    $parts = explode(':', $header, 2);
    if (count($parts) === 2) {
        $key = trim($parts[0]);
        $value = trim($parts[1]);
        $response_headers[$key] = $value;
    }
    return $len;
});

// اجرای درخواست
$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
$content_type_response = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$error = curl_error($ch);
curl_close($ch);

// اگر خطا داشت
if ($error) {
    http_response_code(502);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><title>خطا</title></head><body style="font-family:Tahoma,sans-serif;padding:40px;text-align:center"><h1>خطا در اتصال</h1><p>نمی‌توان به سرور وصل شد. لطفاً:</p><ol style="text-align:right;direction:rtl;display:inline-block"><li>آدرس PREVIEW_URL را در proxy.php بررسی کنید</li><li>مطمئن شوید سرور سندباکس فعال است</li></ol><p style="color:red;margin-top:20px">' . htmlspecialchars($error) . '</p></body></html>';
    exit;
}

// ارسال هدرهای پاسخ (به جز Location و Set-Cookie که نیاز به بازنویسی دارند)
foreach ($response_headers as $key => $value) {
    $key_lower = strtolower($key);
    // بازنویسی Location برای redirect
    if ($key_lower === 'location') {
        // اگر مسیر نسبی است، به مسیر proxy تبدیل کن
        if (strpos($value, '/') === 0) {
            $value = $value; // مسیر نسبی خودش کار می‌کند چون htaccess همه چیز را به proxy.php می‌فرستد
        } elseif (strpos($value, $TARGET_URL) === 0) {
            $value = str_replace($TARGET_URL, '', $value);
        }
        header("$key: $value");
        continue;
    }
    // بازنویسی Set-Cookie
    if ($key_lower === 'set-cookie') {
        // کوکی را همانطور که هست پاس می‌دهیم
        header("$key: $value", false);
        continue;
    }
    // هدرهای دیگر
    if ($key_lower !== 'transfer-encoding' && $key_lower !== 'content-encoding') {
        header("$key: $value");
    }
}

// بازنویسی URL در محتوای HTML و CSS
$is_html = strpos($content_type_response, 'text/html') !== false || strpos($content_type_response, 'application/javascript') !== false;
$is_css = strpos($content_type_response, 'text/css') !== false;
$is_js = strpos($content_type_response, 'javascript') !== false;

if ($is_html || $is_css || $is_js) {
    // بازنویسی URL های مطلق به نسبی
    $response = str_replace($TARGET_URL, '', $response);
    // بازنویسی href و src که به /_next/ اشاره می‌کنند - این‌ها نسبی هستند و خودکار کار می‌کنند
}

// ارسال محتوا
echo $response;
