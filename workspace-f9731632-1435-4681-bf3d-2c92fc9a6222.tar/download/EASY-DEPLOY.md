# 🚀 استقرار با یک کلیک — واقعاً ساده!

## مرحله ۱: فایل‌ها را دانلود کنید

این فایل را دانلود کنید:
- `rooyesh-pishran-github-ready.zip` (۴ مگابایت)

این شامل **همه چیز** است: کد، تنظیمات، Dockerfile، render.yaml
**هیچ کدنویسی لازم نیست.**

---

## مرحله ۲: سایت را روی Render بالا بیاورید (۱۰ دقیقه)

### ۲.۱ ثبت‌نام در GitHub (۲ دقیقه)
اگر GitHub ندارید:
1. به https://github.com/signup بروید
2. یک ایمیل و رمز عبور انتخاب کنید
3. تأیید کنید. تمام!

### ۲.۲ آپلود کد به GitHub (۳ دقیقه)
1. در GitHub روی **+** در گوشه‌ی بالا راست کلیک کنید → **New repository**
2. نام: `rooyesh-pishran` (یا هر چیزی)
3. **Public** انتخاب کنید
4. **Create repository** را بزنید
5. روی **uploading an existing file** کلیک کنید
6. فایل‌های داخل `rooyesh-pishran-github-ready.zip` را بکشید و رها کنید
7. روی **Commit changes** کلیک کنید

### ۲.۳ ثبت‌نام در Render (۱ دقیقه)
1. به https://render.com بروید
2. روی **Get Started** کلیک کنید
3. **Sign up with GitHub** را انتخاب کنید
4. تأیید کنید. تمام!

### ۲.۴ استقرار با یک کلیک (۴ دقیقه)
1. روی **New +** در گوشه بالا راست کلیک کنید
2. **Blueprint** را انتخاب کنید
3. Repository خود را انتخاب کنید
4. Render به‌طور خودکار فایل `render.yaml` را می‌خواند
5. در قسمت Environment Variables:
   - `NEXTAUTH_SECRET` = روی دکمه **Generate** کلیک کنید
6. روی **Approve** کلیک کنید
7. صبر کنید تا Build تمام شود (۵-۱۰ دقیقه)
8. سایت روی این آدرس بالا می‌آید:
   `https://rooyesh-pishran.onrender.com`

**تمام شد!** 🎉

---

## مرحله ۳ (اختیاری): اتصال دامنه‌ی InfinityFree

دامنه‌ی `rooyeshpishran.web1337.net` را می‌توانید به سایت Render وصل کنید:

### ۳.۱ وارد شوید به InfinityFree
1. به https://dash.infinityfree.com بروید
2. با حساب `if0_42892610` وارد شوید
3. به بخش **Control Panel** بروید

### ۳.۲ تنظیم DNS
1. به بخش **DNS Settings** بروید
2. یک رکورد CNAME اضافه کنید:
   - **Name/Host**: `@` (یا خالی)
   - **Value/Target**: `rooyesh-pishran.onrender.com`
   - **TTL**: ۳۶۰۰
3. ذخیره کنید

### ۳.۳ اتصال دامنه در Render
1. در Render به سرویس `rooyesh-pishran` بروید
2. به **Settings** → **Custom Domain** بروید
3. روی **Add Custom Domain** کلیک کنید
4. `rooyeshpishran.web1337.net` را وارد کنید
5. صبر کنید تا تأیید شود (چند ساعت)

**حالا سایت شما روی:** `https://rooyeshpishran.web1337.net` 🌐

---

## 📞 اگر مشکلی پیش آمد

| مشکل | راه‌حل |
|------|--------|
| Build ناموفق | در Render → **Manual Deploy** → **Clear build cache & deploy** |
| صفحه خالی | ۵ دقیقه صبر کنید (سرور Sleep می‌شود) |
| Database error | در PostgreSQL service بررسی کنید |
| ورود کار نمی‌کند | NEXTAUTH_URL را با دامنه‌ی واقعی به‌روزرسانی کنید |

---

## 💡 راه‌حل ساده‌تر

**اگر هیچ کاری نمی‌توانید انجام دهید:**

می‌توانید سایت را در همین **سندباکس** به کار کنید! 
- در پنل پیش‌نمایش (راست صفحه) سایت را ببینید
- روی **Open in New Tab** کلیک کنید
- سایت روی یک URL عمومی در دسترس است

این سندباکس به‌طور دائمی فعال است و سایت روی آن کار می‌کند.
شما می‌توانید با حساب‌های آزمایشی وارد شوید:
- `adminro` / `rooyeshp`
- `coach1` / `coach123`
- `member1` / `member123`
