# موسسه رویش‌های پیشران — وب‌سایت فول‌استک

## فایل‌های موجود

1. **`rooyesh-pishran-website.tar.gz`** (۲ مگابایت) — آرشیو کامل پروژه
2. **`DEPLOYMENT-GUIDE.md`** — راهنمای استقرار گام‌به‌گام

## راه‌اندازی محلی

```bash
tar -xzf rooyesh-pishran-website.tar.gz
cd website
npm install
# ساخت فایل .env با محتوای:
#   DATABASE_URL=file:./db/custom.db
#   NEXTAUTH_SECRET=any-long-random-string
npx prisma generate
npx prisma db push
npx prisma db seed   # یا: bun prisma/seed.ts
npm run dev
# سایت روی http://localhost:3000
```

## حساب‌های آماده

- مدیر اصلی: `adminro` / `rooyeshp`
- مربی: `coach1` / `coach123`
- عضو: `member1` / `member123`

## ⚠️ درباره‌ی InfinityFree

InfinityFree هاست **PHP** است و برای سایت Next.js ما کار نمی‌کند.
گزینه‌ی رایگان بهتر: **Render.com** — راهنمای کامل در `DEPLOYMENT-GUIDE.md`.
