# راهنمای استقرار موسسه رویش‌های پیشران

این راهنما به شما کمک می‌کند سایت را روی هاست‌های رایگان بالا بیاورید.

> ⚠️ **نکته مهم**: این پروژه با Next.js (Node.js) ساخته شده و روی هاست‌های اشتراکی PHP مثل InfinityFree کار نمی‌کند. باید از هاست‌های Node.js استفاده کنید. تمام گزینه‌های زیر رایگان هستند.

## معماری استقرار

```
کاربر
  ↓
Vercel (فرانت‌اند + APIها)
  ↓
Neon (دیتابیس PostgreSQL)  ←  Railway (سرور چت Socket.IO)
```

## مرحله ۱: انتقال کد به GitHub

1. یک حساب در [github.com](https://github.com) بسازید (رایگان)
2. کد پروژه را آپلود کنید. می‌توانید از GitHub Desktop یا دستورات git استفاده کنید:

```bash
cd /home/z/my-project
git init
git add -A
git commit -m "موسسه رویش‌های پیشران - نسخه اولیه"
git branch -M main
git remote add origin https://github.com/USERNAME/rooyesh-pishrun.git
git push -u origin main
```

> **مهم**: قبل از push مطمئن شوید فایل‌های حساس مثل `.env` در `.gitignore` هستند.

## مرحله ۲: ساخت دیتابیس PostgreSQL رایگان (Neon)

1. به [neon.tech](https://neon.tech) بروید و با GitHub وارد شوید
2. روی **"Create New Project"** کلیک کنید
3. نام پروژه: `rooyesh-pishrun`
4. Region: نزدیک‌ترین به کاربران (مثلاً `Frankfurt` برای ایران)
5. روی **Create** کلیک کنید
6. رشته‌ی اتصال (Connection String) را کپی کنید (شبیه `postgresql://...`)
7. این رشته را برای بعد ذخیره کنید

## مرحله ۳: استقرار روی Vercel

1. به [vercel.com](https://vercel.com) بروید و با GitHub وارد شوید
2. روی **"Add New Project"** کلیک کنید
3. مخزن GitHub پروژه را انتخاب کنید
4. تنظیمات:
   - **Framework Preset**: Next.js (خودکار تشخیص داده می‌شود)
   - **Root Directory**: `./` (پیش‌فرض)
   - **Build Command**: `prisma generate && next build`
   - **Output Directory**: `.next`
5. روی **"Environment Variables"** کلیک کنید و این موارد را اضافه کنید:

| نام | مقدار |
|-----|-------|
| `DATABASE_URL` | رشته اتصال Neon |
| `DIRECT_URL` | همان رشته Neon (برای migrations) |
| `NEXTAUTH_SECRET` | یک رشته 32 کاراکتری تصادفی (از [jwt.io](https://jwt.io) یا `openssl rand -base64 32` تولید کنید) |
| `NEXTAUTH_URL` | `https://your-project.vercel.app` (بعد از اولین deploy آن را تنظیم کنید) |
| `NEXT_PUBLIC_SOCKET_URL` | آدرس سرویس چت (مرحله ۴) |

6. روی **Deploy** کلیک کنید
7. بعد از اتمام deploy، آدرس سایت شما شبیه `https://rooyesh-pishrun.vercel.app` خواهد بود
8. این آدرس را در `NEXTAUTH_URL` قرار دهید و دوباره deploy کنید

## مرحله ۴: استقرار سرور چت روی Railway

چون Vercel از WebSocket پشتیبانی نمی‌کند، سرویس چت Socket.IO را روی Railway بالا بیاورید:

1. به [railway.app](https://railway.app) بروید و با GitHub وارد شوید
2. **"New Project"** → **"Deploy from GitHub repo"**
3. مخزن خود را انتخاب کنید و **Root Directory** را روی `mini-services/chat-service` تنظیم کنید
4. متغیرهای محیطی:
   - `DATABASE_URL`: همان رشته Neon
   - `PORT`: `3003` (یا هر پورت دلخواه)
5. روی **Deploy** کلیک کنید
6. آدرس عمومی Railway را کپی کنید (مثل `https://rooyesh-pishrun-chat.up.railway.app`)
7. این آدرس را در `NEXT_PUBLIC_SOCKET_URL` در Vercel تنظیم کنید

### تغییر کوچک در کد چت سرویس

فایل `mini-services/chat-service/index.ts` را باز کنید و بخشی که آدرس دیتابیس را hard-code کرده، به متغیر محیطی تغییر دهید:

```typescript
// قبل:
const DB_PATH = '/home/z/my-project/db/custom.db'

// بعد:
const DB_PATH = process.env.DATABASE_URL || '/home/z/my-project/db/custom.db'
```

> اما این فقط برای SQLite است. برای PostgreSQL، باید چت سرویس را هم با Prisma بازنویسی کنید یا از یک ORM دیگر استفاده کنید. جایگزین ساده‌تر: **دیتابیس PostgreSQL با `pg` library مستقیم**.

## مرحله ۵: seed دیتابیس

بعد از استقرار، باید جداول دیتابیس را بسازید و کاربر ادمین را seed کنید:

### ساخت جداول (Migration)

در Vercel این کار را نمی‌توانید انجام دهید. باید محلی انجام شود با اتصال به دیتابیس Neon:

```bash
# در کامپیوتر خودتان، با اتصال به دیتابیس Neon:
cd /home/z/my-project
# فایل .env.local بسازید و DATABASE_URL و DIRECT_URL را از Neon بگذارید
bun run db:push
bun prisma/seed.ts
```

این کار:
- همه‌ی جداول را در Neon می‌سازد
- کاربر ادمین (adminro/rooyeshp) را اضافه می‌کند
- کاربر مربی نمونه (coach1/coach123) را اضافه می‌کند
- ۳ پست وبلاگ نمونه اضافه می‌کند
- یک نظرسنجی نمونه می‌سازد
- تنظیمات اولیه سایت را ذخیره می‌کند

## مرحله ۶: تست

1. آدرس سایت Vercel را در مرورگر باز کنید: `https://your-project.vercel.app`
2. روی **"ورود به حساب"** کلیک کنید
3. با `adminro / rooyeshp` وارد شوید
4. پنل ادمین را تست کنید
5. با `coach1 / coach123` وارد شوید و چت را تست کنید

---

## تنظیمات اضافی برای تولید

### 1. آپلود فایل

روی Vercel فایل‌سیستم read-only است. باید از یک سرویس ذخیره‌سازی ابری استفاده کنید:

- **Cloudinary** (رایگان، آپلود نامحدود با محدودیت حجم)
- **Uploadthing** (مخصوص Next.js، رایگان تا 2GB)
- **AWS S3** (رایگان 12 ماه)

برای Cloudinary:
1. به [cloudinary.com](https://cloudinary.com) بروید و حساب رایگان بسازید
2. Cloud Name و API Key و API Secret را دریافت کنید
3. در `.env` اضافه کنید: `CLOUDINARY_URL=cloudinary://...`
4. در API آپلود، فایل‌ها را به Cloudinary بفرستید

### 2. متغیرهای لازم در Vercel

```
DATABASE_URL=postgresql://... (Neon)
DIRECT_URL=postgresql://... (Neon)
NEXTAUTH_SECRET=... (رشته تصادفی)
NEXTAUTH_URL=https://your-project.vercel.app
NEXT_PUBLIC_SOCKET_URL=https://your-chat-service.railway.app
```

### 3. مشکل آپلود فایل روی Vercel

روی Vercel فایل‌سیستم read-only است. باید فایل `src/app/api/admin/upload/route.ts` (و مشابه آن برای coach/member) را برای استفاده از Cloudinary یا Uploadthing تغییر دهید. این کار را می‌توانم برایتان انجام دهم اگر بخواهید.

---

## خلاصه‌ی هاست‌های رایگان پیشنهادی

| سرویس | کاربرد | محدودیت رایگان |
|-------|--------|----------------|
| [Vercel](https://vercel.com) ⭐ | فرانت‌اند + API Next.js | 100GB bandwidth/ماه، 1000 build min/ماه |
| [Neon](https://neon.tech) ⭐ | دیتابیس PostgreSQL | 0.5GB storage، 100 compute hours/ماه |
| [Railway](https://railway.app) | سرور چت Socket.IO | 500 hours/ماه یا $5 credit/ماه |
| [Cloudinary](https://cloudinary.com) | ذخیره‌ی فایل‌ها | 25GB storage، 25GB bandwidth/ماه |
| [Render](https://render.com) | جایگزین Railway | 750 hours/ماه (با sleep بعد 15 دقیقه idle) |
| [Supabase](https://supabase.com) | جایگزین Neon (PostgreSQL + Auth + Storage) | 500MB دیتابیس، 1GB فایل |

---

## مشکل‌های احتمالی و راه‌حل

### مشکل: "Module not found" بعد از deploy
**راه‌حل**: مطمئن شوید `prisma generate` در Build Command اجرا می‌شود.

### مشکل: اتصال به دیتابیس برقرار نمی‌شود
**راه‌حل**: 
- بررسی کنید `DATABASE_URL` با `?sslmode=require` تمام شده باشد
- در Neon، مطمئن شوید IP‌های Vercel مجاز باشند (به‌صورت پیش‌فرض همه مجازند)

### مشکل: چت کار نمی‌کند
**راه‌حل**: 
- مطمئن شوید `NEXT_PUBLIC_SOCKET_URL` به آدرس Railway تنظیم شده باشد
- CORS در سرور چت فعال باشد

### مشکل: آپلود فایل ناموفق
**راه‌حل**: از Cloudinary یا Uploadthing استفاده کنید (روی Vercel filesystem read-only است)

---

## اگر می‌خواهید برایتان تنظیم کنم

اگر بخواهید، می‌توانم:
1. ✅ فایل‌های لازم برای استقرار را آماده کنم
2. ✅ کد آپلود فایل را به Cloudinary تغییر دهم
3. ✅ چت سرویس را برای PostgreSQL بازنویسی کنم
4. ✅ یک README کامل با دستورالعمل گام‌به‌گام بنویسم

کافی است بگویید کدام بخش را می‌خواهید.

---

## ⚠️ چرا InfinityFree مناسب نیست؟

اگر اصرار دارید از InfinityFree استفاده کنید، باید:

1. **کل پروژه را با PHP بازنویسی کنید** (هفته‌ها کار)
2. **از MySQL به جای PostgreSQL استفاده کنید** (نیاز به تغییر schema)
3. **چت بلادرنگ را حذف کنید** (یا به polling تبدیل کنید)
4. **احراز هویت را با PHP sessions بازنویسی کنید**
5. **AI Summary را حذف کنید** (یا به یک API خارجی وابسته کنید)

به‌جای این کار، **Vercel** راحت‌تر، سریع‌تر و رایگان‌تر است.
