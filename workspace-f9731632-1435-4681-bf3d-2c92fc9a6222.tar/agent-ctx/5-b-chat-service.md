# Task 5-b — Chat Service Agent Work Record

Task ID: 5-b
Agent: full-stack-developer (chat service)
Task: ساخت مینی‌سرویس Socket.IO + کامپوننت‌های چت گروهی + API آپلود

## What was built

### 1. Mini-service (`mini-services/chat-service/`)
- **package.json** — Bun project, dev script `bun --hot index.ts`, depends on `socket.io` and (dev) `socket.io-client` for testing.
- **index.ts** — Socket.IO server on port 3003, path `/`, CORS `*`:
  - Reads the main project's SQLite DB (`/home/z/my-project/db/custom.db`) directly via `bun:sqlite` (no Prisma setup needed — uses WAL mode).
  - Events handled:
    - `join-group { groupId, userId, userName }` — verifies user exists in DB, verifies group membership (coach / GroupMember / SUPER_ADMIN), joins socket to `group:${groupId}` room, leaves any previously-joined group first, sends back `message-history` (last 50 messages enriched with sender info) + `online-users` + `user-online` broadcast.
    - `leave-group { groupId }` — leaves the room and updates presence.
    - `send-message { groupId, content?, fileUrl?, fileType?, fileName? }` — saves to DB, broadcasts `new-message` with full enriched payload.
    - `typing { groupId, isTyping }` — broadcasts `user-typing` to room.
    - `reaction { messageId, emoji }` — toggles the user's reaction in DB (JSON-serialized `reactions` column), broadcasts `message-reaction` with the new reactions map.
    - `disconnect` — removes socket from in-memory presence Map, broadcasts `user-offline` if the user has no other sockets.
  - In-memory presence tracking: `onlineUsers` Map (userId → { userName, avatar, socketIds Set, groups Set }) and `userSocketMap` (socketId → userId).
  - Validates the user from DB on every `join-group` — never trusts the client-sent `userName`/`avatar`; the server always uses the DB values.

### 2. Upload APIs
- **`src/app/api/coach/upload/route.ts`** — POST multipart, requires `requireCoachOrAdmin()`. Saves to `public/uploads/<uuid>_<safe-name>.<ext>`. Returns `{ url, fileName, fileType, size }`. Validates MIME type and 25 MB max size.
- **`src/app/api/member/upload/route.ts`** — Same logic, requires `requireAuth()`.
- Both handle Response throws from auth-utils (return proper 401 JSON, not 500).

### 3. Message History API
- **`src/app/api/groups/[groupId]/messages/route.ts`** — GET, paginated (`limit` 1..200, default 50; `before` ISO cursor). Verifies `canAccessGroup(userId, groupId)`. Returns `{ groupId, messages: [...enriched], nextCursor, hasMore }`.

### 4. Chat Components (`src/components/chat/`)
- **`group-chat.tsx`** — Main `<GroupChat groupId={...} />` component. Connects via `getSocket()` from `@/lib/socket-client`. Emits `join-group` on mount. Listens for `message-history`, `new-message`, `user-typing`, `user-online`, `user-offline`, `online-users`, `message-reaction`, `chat-error`. Auto-scrolls to bottom (with jump-to-bottom button when scrolled up). RTL Telegram-style layout: own messages right, others left. Header shows online count + connection status. Input area: file upload button + textarea + send button (Enter to send). Typing throttled to 1.5 s with 3 s auto-stop. Cleans up stale typing indicators every 2 s.
- **`message-bubble.tsx`** — Single bubble. Avatar (initials fallback), sender name (for others), time, markdown content (react-markdown), file preview (image inline / video / audio / file download link), reaction picker (👍 ❤️ 😂 🙏 🔥) via Popover, reactions row with toggle on click. Highlights reactions the current user has added.
- **`typing-indicator.tsx`** — Animated three-dot typing indicator with Persian label (handles 1 or 2+ users typing).
- **`file-upload-button.tsx`** — Upload button with XHR progress (XMLHttpRequest for `upload.onprogress`). Returns `UploadedFile { url, fileName, fileType, size }` via callback. Shows progress popover.

## Verification

### Mini-service smoke test (passed end-to-end)
Run via inline `bun -e` script against a real test group created in the DB:

```
[setup] created test group: test-group-smoke-1791746124056
[client] connected: Vd4p3SYfQDsg68nYAAAB
[client] user-online: مربی نمونه
[client] online-users: count=1
[client] message-history: count=0
[client] join ack: {"ok":true}
[client] new-message: e5f36318-1704-4d51-bf4a-f4c5123a0294 from: مربی نمونه content: سلام! این یک پیام تست است.
[client] send-message ack: ok=true, msg.id=e5f36318-1704-4d51-bf4a-f4c5123a0294
[client] message-reaction: {"messageId":"...","reactions":{"👍":["cmv46m16t0001pjauk863rpju"]}}
[cleanup] test group + messages removed
```

Server log confirms:
```
[chat-service] socket connected: Vd4p3SYfQDsg68nYAAAB
[chat-service] user "مربی نمونه" joined group test-group-smoke-...
[chat-service] message e5f36318-... from "مربی نمونه"
[chat-service] socket disconnected: Vd4p3SYfQDsg68nYAAAB
```

### Endpoint checks (curl)
- `curl http://localhost:3003/socket.io/?EIO=4&transport=polling` → returns `0{"sid":"...","upgrades":["websocket"],...}` ✓
- `GET /api/groups/test-group/messages` (no auth) → 401 JSON `{"error":"احراز هویت نشده"}` ✓
- `POST /api/coach/upload` (no auth) → 307 redirect to `/login?callbackUrl=/api/coach/upload` (proxy.ts middleware) ✓
- `POST /api/member/upload` (no auth) → 307 redirect to `/login` ✓

### Lint
`bun run lint` is clean for all my files. One pre-existing error in `src/components/splash-screen.tsx` (Task 2 code) remains — outside my allowed scope per task rules.

## Mini-service status
- Process: `bun --hot index.ts` running as PID 4791 (PPID 1, detached via `setsid bash -c 'exec bun --hot index.ts'`).
- Log file: `/tmp/chat-service.log`.
- Port 3003 reachable via `curl http://localhost:3003/socket.io/?EIO=4&transport=polling`.
- Auto-restarts on file changes (bun --hot).

## Notes for downstream agents
- **GroupChat component usage**: `<GroupChat groupId={group.id} />` — pass any group the current user is a member of. The component handles auth via `useSession()` and emits `join-group` automatically.
- **Endpoints expect**: the NextAuth session cookie. The frontend just calls `fetch('/api/coach/upload', ...)` or `/api/member/upload` with FormData — no extra headers needed.
- **Socket events emitted by server** (for any future client implementation): `message-history`, `new-message`, `user-typing`, `user-online`, `user-offline`, `online-users`, `message-reaction`, `chat-error`.
- **Database access**: The mini-service reads/writes the SAME SQLite DB the Next.js app uses. The Prisma schema's `Message.reactions` column is a JSON string (`Record<emoji, userId[]>`).
