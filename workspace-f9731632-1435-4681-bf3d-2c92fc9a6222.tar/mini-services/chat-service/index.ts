/**
 * Chat Service — موسسه رویش‌های پیشران
 *
 * Socket.IO mini-service for real-time group chat.
 * - Listens on port 3003 (hardcoded, NOT from env)
 * - Uses path '/' so that Caddy can route ?XTransformPort=3003 -> localhost:3003
 * - Reads the same SQLite database used by the Next.js app
 * - Authenticates users via the join-group handshake (verifies user exists in DB
 *   and is a member of the group)
 */

import { createServer, type Server as HttpServer } from 'http'
import { Server, type Socket } from 'socket.io'
import { Database } from 'bun:sqlite'

// ─────────────────────────────────────────────────────────────────────────────
// Database setup — same SQLite DB as the Next.js app
// ─────────────────────────────────────────────────────────────────────────────
const DB_PATH = '/home/z/my-project/db/custom.db'

export const sqlite = new Database(DB_PATH, { readonly: false, create: true })
sqlite.exec('PRAGMA journal_mode = WAL;')
sqlite.exec('PRAGMA foreign_keys = ON;')

// Types ──────────────────────────────────────────────────────────────────────
interface UserRow {
  id: string
  name: string
  username: string | null
  avatar: string | null
  role: string
  blocked: number
}

interface MessageRow {
  id: string
  groupId: string
  senderId: string
  content: string | null
  fileUrl: string | null
  fileType: string | null
  fileName: string | null
  reactions: string | null
  createdAt: number
}

interface GroupRow {
  id: string
  name: string
  coachId: string
}

// Helpers ────────────────────────────────────────────────────────────────────
function getUserById(id: string): UserRow | null {
  const row = sqlite
    .query('SELECT id, name, username, avatar, role, blocked FROM User WHERE id = ?')
    .get(id) as UserRow | undefined
  return row ?? null
}

function getGroupById(id: string): GroupRow | null {
  const row = sqlite
    .query('SELECT id, name, coachId FROM `Group` WHERE id = ?')
    .get(id) as GroupRow | undefined
  return row ?? null
}

function isGroupMember(userId: string, groupId: string): boolean {
  const group = getGroupById(groupId)
  if (!group) return false
  if (group.coachId === userId) return true
  // SUPER_ADMIN can access any group
  const user = getUserById(userId)
  if (user?.role === 'SUPER_ADMIN') return true
  const member = sqlite
    .query('SELECT id FROM GroupMember WHERE groupId = ? AND userId = ?')
    .get(groupId, userId)
  return !!member
}

function getMessagesByGroup(groupId: string, limit = 50): MessageRow[] {
  const rows = sqlite
    .query(
      'SELECT id, groupId, senderId, content, fileUrl, fileType, fileName, reactions, createdAt FROM Message WHERE groupId = ? ORDER BY createdAt DESC LIMIT ?',
    )
    .all(groupId, limit) as MessageRow[]
  return rows.reverse()
}

function createMessage(data: {
  groupId: string
  senderId: string
  content: string | null
  fileUrl: string | null
  fileType: string | null
  fileName: string | null
}): MessageRow | null {
  const id = crypto.randomUUID()
  const createdAt = Date.now()
  sqlite
    .query(
      'INSERT INTO Message (id, groupId, senderId, content, fileUrl, fileType, fileName, reactions, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
    )
    .run(id, data.groupId, data.senderId, data.content, data.fileUrl, data.fileType, data.fileName, null, createdAt)
  return getMessageById(id)
}

function getMessageById(id: string): MessageRow | null {
  const row = sqlite
    .query(
      'SELECT id, groupId, senderId, content, fileUrl, fileType, fileName, reactions, createdAt FROM Message WHERE id = ?',
    )
    .get(id) as MessageRow | undefined
  return row ?? null
}

function updateMessageReactions(messageId: string, reactions: string): void {
  sqlite.query('UPDATE Message SET reactions = ? WHERE id = ?').run(reactions, messageId)
}

// Enrich a MessageRow with sender info + ISO timestamp
function enrichMessage(m: MessageRow) {
  const sender = getUserById(m.senderId)
  let reactions: Record<string, string[]> = {}
  if (m.reactions) {
    try {
      const parsed = JSON.parse(m.reactions)
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        reactions = parsed as Record<string, string[]>
      }
    } catch {
      reactions = {}
    }
  }
  return {
    id: m.id,
    groupId: m.groupId,
    senderId: m.senderId,
    senderName: sender?.name ?? 'کاربر حذف‌شده',
    senderAvatar: sender?.avatar ?? null,
    content: m.content,
    fileUrl: m.fileUrl,
    fileType: m.fileType,
    fileName: m.fileName,
    reactions,
    createdAt: new Date(m.createdAt).toISOString(),
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Socket.IO server
// ─────────────────────────────────────────────────────────────────────────────
const httpServer: HttpServer = createServer()

const io = new Server(httpServer, {
  path: '/',
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
  connectTimeout: 10000,
  allowEIO3: true,
})

// Per-socket data we attach
interface SocketData {
  userId?: string
  userName?: string
  avatar?: string | null
  groupId?: string
}

// In-memory presence tracking (userId → info, plus the set of socket ids)
interface OnlineUser {
  userId: string
  userName: string
  avatar: string | null
  socketIds: Set<string>
  groups: Set<string>
}
const onlineUsers = new Map<string, OnlineUser>()
const userSocketMap = new Map<string, string>() // socketId → userId

function broadcastOnlineList(roomName: string, groupId: string) {
  const users: Array<{ userId: string; userName: string; avatar: string | null }> = []
  for (const u of onlineUsers.values()) {
    if (u.groups.has(groupId) && u.socketIds.size > 0) {
      users.push({ userId: u.userId, userName: u.userName, avatar: u.avatar })
    }
  }
  io.to(roomName).emit('online-users', { groupId, users })
}

io.on('connection', (socket: Socket) => {
  console.log(`[chat-service] socket connected: ${socket.id}`)

  // leave-group ───────────────────────────────────────────────────────────
  socket.on('leave-group', (payload: { groupId?: string }) => {
    try {
      const sd = socket.data as SocketData | undefined
      const groupId = payload?.groupId ?? sd?.groupId
      if (!sd?.userId || !groupId) return
      const roomName = `group:${groupId}`
      socket.leave(roomName)
      const online = onlineUsers.get(sd.userId)
      if (online) {
        online.socketIds.delete(socket.id)
        if (online.socketIds.size === 0) {
          onlineUsers.delete(sd.userId)
          io.to(roomName).emit('user-offline', {
            userId: sd.userId,
            userName: sd.userName,
            groupId,
          })
          broadcastOnlineList(roomName, groupId)
        }
      }
      sd.groupId = undefined
      console.log(`[chat-service] socket ${socket.id} left group ${groupId}`)
    } catch (e) {
      console.error('[chat-service] leave-group error:', e)
    }
  })

  // join-group ────────────────────────────────────────────────────────────
  socket.on(
    'join-group',
    (
      payload: { groupId: string; userId: string; userName: string; avatar?: string | null },
      ack?: (data: unknown) => void,
    ) => {
      try {
        if (!payload || !payload.groupId || !payload.userId) {
          socket.emit('chat-error', { message: 'اطلاعات گروه ناقص است' })
          ack?.({ ok: false, error: 'invalid payload' })
          return
        }
        const user = getUserById(payload.userId)
        if (!user || user.blocked) {
          socket.emit('chat-error', { message: 'کاربر نامعتبر است' })
          ack?.({ ok: false, error: 'invalid user' })
          return
        }
        if (!isGroupMember(user.id, payload.groupId)) {
          socket.emit('chat-error', { message: 'شما به این گروه دسترسی ندارید' })
          ack?.({ ok: false, error: 'forbidden' })
          return
        }

        const sd: SocketData = (socket.data = socket.data || {})

        // Leave any previously-joined group room before joining the new one
        if (sd.groupId && sd.groupId !== payload.groupId) {
          const oldRoom = `group:${sd.groupId}`
          socket.leave(oldRoom)
          const prevOnline = onlineUsers.get(sd.userId)
          if (prevOnline) {
            prevOnline.socketIds.delete(socket.id)
            if (prevOnline.socketIds.size === 0) {
              onlineUsers.delete(sd.userId)
              io.to(oldRoom).emit('user-offline', {
                userId: sd.userId,
                userName: sd.userName,
                groupId: sd.groupId,
              })
              broadcastOnlineList(oldRoom, sd.groupId)
            }
          }
        }

        sd.userId = user.id
        sd.userName = user.name
        sd.avatar = user.avatar
        sd.groupId = payload.groupId

        const roomName = `group:${payload.groupId}`
        socket.join(roomName)

        // Update presence
        let online = onlineUsers.get(user.id)
        if (!online) {
          online = {
            userId: user.id,
            userName: user.name,
            avatar: user.avatar,
            socketIds: new Set(),
            groups: new Set(),
          }
          onlineUsers.set(user.id, online)
        }
        online.socketIds.add(socket.id)
        online.groups.add(payload.groupId)
        userSocketMap.set(socket.id, user.id)

        // Notify room that this user is online
        io.to(roomName).emit('user-online', {
          userId: user.id,
          userName: user.name,
          avatar: user.avatar,
          groupId: payload.groupId,
        })

        // Send online users list (only this socket — others have their own state)
        const onlineList: Array<{ userId: string; userName: string; avatar: string | null }> = []
        for (const u of onlineUsers.values()) {
          if (u.groups.has(payload.groupId) && u.socketIds.size > 0) {
            onlineList.push({ userId: u.userId, userName: u.userName, avatar: u.avatar })
          }
        }
        socket.emit('online-users', { groupId: payload.groupId, users: onlineList })

        // Send last 50 messages
        const rows = getMessagesByGroup(payload.groupId, 50)
        const messages = rows.map(enrichMessage)
        socket.emit('message-history', { groupId: payload.groupId, messages })

        ack?.({ ok: true })

        console.log(
          `[chat-service] user "${user.name}" joined group ${payload.groupId} (online in this group: ${onlineList.length})`,
        )
      } catch (e) {
        console.error('[chat-service] join-group error:', e)
        socket.emit('chat-error', { message: 'خطا در پیوستن به گروه' })
        ack?.({ ok: false, error: 'server' })
      }
    },
  )

  // send-message ──────────────────────────────────────────────────────────
  socket.on(
    'send-message',
    (
      payload: {
        groupId: string
        content?: string
        fileUrl?: string
        fileType?: string
        fileName?: string
      },
      ack?: (data: unknown) => void,
    ) => {
      try {
        const sd = socket.data as SocketData | undefined
        if (!sd?.userId) {
          socket.emit('chat-error', { message: 'ابتدا به گروه بپیوندید' })
          ack?.({ ok: false, error: 'not joined' })
          return
        }
        if (sd.groupId !== payload.groupId) {
          socket.emit('chat-error', { message: 'گروه نامعتبر است' })
          ack?.({ ok: false, error: 'group mismatch' })
          return
        }
        const content = payload.content?.trim() || null
        const fileUrl = payload.fileUrl?.trim() || null
        const fileType = payload.fileType?.trim() || null
        const fileName = payload.fileName?.trim() || null
        if (!content && !fileUrl) {
          socket.emit('chat-error', { message: 'پیام خالی است' })
          ack?.({ ok: false, error: 'empty' })
          return
        }

        const row = createMessage({
          groupId: payload.groupId,
          senderId: sd.userId,
          content,
          fileUrl,
          fileType,
          fileName,
        })
        if (!row) {
          socket.emit('chat-error', { message: 'ذخیره پیام ناموفق بود' })
          ack?.({ ok: false, error: 'db' })
          return
        }

        const messageData = enrichMessage(row)
        io.to(`group:${payload.groupId}`).emit('new-message', messageData)
        ack?.({ ok: true, message: messageData })

        console.log(
          `[chat-service] message ${row.id} in group ${payload.groupId} from "${sd.userName}"`,
        )
      } catch (e) {
        console.error('[chat-service] send-message error:', e)
        socket.emit('chat-error', { message: 'خطا در ارسال پیام' })
        ack?.({ ok: false, error: 'server' })
      }
    },
  )

  // typing ────────────────────────────────────────────────────────────────
  socket.on('typing', (payload: { groupId: string; isTyping: boolean }) => {
    try {
      const sd = socket.data as SocketData | undefined
      if (!sd?.userId || !sd.userName) return
      if (sd.groupId !== payload?.groupId) return
      socket.to(`group:${payload.groupId}`).emit('user-typing', {
        userId: sd.userId,
        userName: sd.userName,
        avatar: sd.avatar ?? null,
        groupId: payload.groupId,
        isTyping: !!payload.isTyping,
      })
    } catch (e) {
      console.error('[chat-service] typing error:', e)
    }
  })

  // reaction ──────────────────────────────────────────────────────────────
  socket.on('reaction', (payload: { messageId: string; emoji: string }) => {
    try {
      const sd = socket.data as SocketData | undefined
      if (!sd?.userId) return
      const m = getMessageById(payload?.messageId)
      if (!m) return
      if (sd.groupId !== m.groupId) return

      let reactions: Record<string, string[]> = {}
      if (m.reactions) {
        try {
          const parsed = JSON.parse(m.reactions)
          if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
            reactions = parsed as Record<string, string[]>
          }
        } catch {
          reactions = {}
        }
      }

      const emoji = (payload.emoji || '').trim()
      if (!emoji) return
      if (!reactions[emoji]) reactions[emoji] = []

      if (reactions[emoji].includes(sd.userId)) {
        reactions[emoji] = reactions[emoji].filter((u) => u !== sd.userId)
        if (reactions[emoji].length === 0) delete reactions[emoji]
      } else {
        reactions[emoji].push(sd.userId)
      }

      updateMessageReactions(payload.messageId, JSON.stringify(reactions))
      io.to(`group:${m.groupId}`).emit('message-reaction', {
        messageId: payload.messageId,
        reactions,
      })
    } catch (e) {
      console.error('[chat-service] reaction error:', e)
    }
  })

  // disconnect ────────────────────────────────────────────────────────────
  socket.on('disconnect', () => {
    try {
      const userId = userSocketMap.get(socket.id)
      const sd = socket.data as SocketData | undefined
      const groupId = sd?.groupId
      const userName = sd?.userName

      if (userId) {
        userSocketMap.delete(socket.id)
        const online = onlineUsers.get(userId)
        if (online) {
          online.socketIds.delete(socket.id)
          if (online.socketIds.size === 0) {
            onlineUsers.delete(userId)
            if (groupId) {
              io.to(`group:${groupId}`).emit('user-offline', {
                userId,
                userName,
                groupId,
              })
              // Refresh the online-list broadcast for remaining sockets in the room
              broadcastOnlineList(`group:${groupId}`, groupId)
            }
          }
        }
      }
      console.log(`[chat-service] socket disconnected: ${socket.id}`)
    } catch (e) {
      console.error('[chat-service] disconnect error:', e)
    }
  })

  socket.on('error', (err) => {
    console.error(`[chat-service] socket error (${socket.id}):`, err)
  })
})

// ─────────────────────────────────────────────────────────────────────────────
// Boot
// ─────────────────────────────────────────────────────────────────────────────
const PORT = 3003

httpServer.listen(PORT, () => {
  console.log(`[chat-service] Socket.IO server listening on port ${PORT} (path "/")`)
})

process.on('SIGTERM', () => {
  console.log('[chat-service] SIGTERM received — ignoring (kept alive)')
})

process.on('SIGHUP', () => {
  console.log('[chat-service] SIGHUP received — ignoring (kept alive)')
})

process.on('SIGINT', () => {
  console.log('[chat-service] SIGINT received, shutting down...')
  httpServer.close(() => {
    sqlite.close(false)
    process.exit(0)
  })
})

// Prevent the process from exiting on unhandled errors
process.on('uncaughtException', (err) => {
  console.error('[chat-service] uncaughtException:', err)
})
process.on('unhandledRejection', (reason) => {
  console.error('[chat-service] unhandledRejection:', reason)
})
