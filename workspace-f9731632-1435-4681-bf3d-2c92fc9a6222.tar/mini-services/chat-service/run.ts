import { spawn } from 'bun'

const cmd = ['/usr/local/bin/bun', '/home/z/my-project/mini-services/chat-service/index.ts']

function spawnChild() {
  console.log(`[watchdog] spawning child at ${new Date().toISOString()}`)
  const child = spawn({
    cmd,
    cwd: '/home/z/my-project/mini-services/chat-service',
    stdout: 'inherit',
    stderr: 'inherit',
  })
  child.exited.then((code) => {
    console.log(`[watchdog] child exited with code ${code}, respawning in 2s`)
    setTimeout(spawnChild, 2000)
  })
}
spawnChild()

// Keep process alive forever
setInterval(() => {}, 1 << 30)
