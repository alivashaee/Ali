#!/bin/bash
# Production server starter - no HMR, no WebSocket, fast response

trap '' SIGHUP SIGTERM SIGINT

# پاک‌سازی نمونه‌های قبلی
pkill -9 -f "bun run dev" 2>/dev/null
pkill -9 -f "next-server" 2>/dev/null
pkill -9 -f "bun.*index" 2>/dev/null
pkill -9 -f "mini-service" 2>/dev/null
sleep 2

# تابع راه‌اندازی Next.js production
run_next() {
  while true; do
    cd /home/z/my-project
    export NODE_ENV=production
    export PORT=3000
    export HOSTNAME=0.0.0.0
    export DATABASE_URL="file:/home/z/my-project/db/custom.db"
    /usr/local/bin/bun run start >> /home/z/my-project/dev.log 2>&1
    echo "[$(date)] Next.js production crashed, restarting in 3s..." >> /tmp/next-prod.log
    sleep 3
  done
}

# تابع راه‌اندازی چت سرویس
run_chat() {
  while true; do
    cd /home/z/my-project/mini-services/chat-service
    /usr/local/bin/bun index.ts >> /tmp/chat-prod.log 2>&1
    echo "[$(date)] Chat crashed, restarting in 3s..." >> /tmp/chat-prod.log
    sleep 3
  done
}

# راه‌اندازی در پس‌زمینه
run_next &
run_chat &

# نگه‌داشتن زنده
while true; do
  sleep 60
  if ! pgrep -f "next-server" > /dev/null; then
    run_next &
  fi
  if ! pgrep -f "bun.*index" > /dev/null; then
    run_chat &
  fi
done
